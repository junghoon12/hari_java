package com.board.controller;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.board.action.*;


public class FrontController extends HttpServlet {
	private static final long serialVersionUID = 1L;
	
	protected void service(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {
		
		// 한글 처리 작업 진행.
		request.setCharacterEncoding("UTF-8");
		response.setContentType("text/html; charset=UTF-8");
		
		// getRequestURI() : "/프로젝트명/파일명(*.do)" 라는
		//                   문자열을 반환해 주는 메서드.
		String uri = request.getRequestURI();
		System.out.println("URI >>> " + uri);
		
		// getContextPath() : 현재 프로젝트명을 문자열로
		//                    반환해 주는 메서드.
		String path = request.getContextPath();
		System.out.println("Path >>> " + path);
		
		String command = uri.substring(path.length() + 1);
		System.out.println("Command >>> " + command);
		
		Action action = null;
		
		String viewPage = null;
		
		if(command.equals("board_list.do")) {
			action = new BoardListAction();
			action.execute(request, response);
			viewPage = "board/board_list.jsp";
		}else if(command.equals("board_write_ok.do")) {
			action = new BoardWriteOkAction();
			action.execute(request, response);
		}else if(command.equals("board_content.do")) {
			action = new BoardConentAction();
			action.execute(request, response);
			viewPage = "board/board_content.jsp";
		}else if(command.equals("board_modify.do")) {
			action = new BoardModifyAction();
			action.execute(request, response);
			viewPage = "board/board_modify.jsp";
		}else if(command.equals("board_modify_ok.do")) {
			action = new BoardModifyOkAction();
			action.execute(request, response);
		}else if(command.equals("board_delete.do")) {
			viewPage = "board/board_delete.jsp";
		}else if(command.equals("board_delete_ok.do")) {
			action = new BoardDeleteOkAction();
			action.execute(request, response);
		}else if(command.equals("board_search.do")) {
			action = new BoardSearchAction();
			action.execute(request, response);
			viewPage = "board/board_search.jsp";
		}else if(command.equals("board_search_cont.do")) {
			action = new BoardSearchContAction();
			action.execute(request, response);
			viewPage = "board/board_search_cont.jsp";
		}
		
		RequestDispatcher rd = 
			request.getRequestDispatcher(viewPage);
		
		rd.forward(request, response);
		
	}

}
