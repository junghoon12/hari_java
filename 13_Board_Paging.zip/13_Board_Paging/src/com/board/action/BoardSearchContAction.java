package com.board.action;

import java.io.IOException;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.board.model.BoardDAO;
import com.board.model.BoardDTO;

public class BoardSearchContAction implements Action {

	@Override
	public void execute(HttpServletRequest request, HttpServletResponse response) throws IOException {
		// 검색된 게시물의 게시물 번호에 해당하는 게시물의
		// 상세내역을 조회하는 비지니스 로직.
		
		int board_no = 
			Integer.parseInt(request.getParameter("no").trim());
		
		String field = 
			request.getParameter("field").trim();
		
		String keyword = 
				request.getParameter("keyword").trim();
		
		int nowPage = 
				Integer.parseInt(request.getParameter("page").trim());
		
		BoardDAO dao = BoardDAO.getInstance();
		
		dao.getBoardHit(board_no);
		
		BoardDTO content = 
					dao.getSearchBoardCont(board_no);
		
		request.setAttribute("searchCont", content);
		request.setAttribute("field", field);
		request.setAttribute("keyword", keyword);
		request.setAttribute("Page", nowPage);
		
	}

}
