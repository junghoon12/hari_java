package com.example.thymeleaf.controller;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

@Controller
public class BeginController {

	@GetMapping("/")
	public String aaa() {
		
		return "index";
	}
	
	@RequestMapping("/{num}")
	public String abc(@PathVariable("num") int no, Model model) {
		
		int result = 0;
		
		for(int i=1; i<=no; i++) {
			
			result = result + i;
		}
		
		model.addAttribute("hap", "total >>> " + result);
		
		return "index";
		
	}
	
	@RequestMapping("form")
	public String abc() {
		
		return "index_01";
	}
	
	@PostMapping("data")
	public ModelAndView bcd(ModelAndView mav,
			@RequestParam("txt1") String name) {
		
		mav.addObject("message", "안녕하세요!! " + name + "님!!!");
		mav.setViewName("index_01");
		
		return mav;
	}
	
	@GetMapping("date")
	public String ccc() {
		
		return "index_02";
	}
	
	@GetMapping("object")
	public String ddd(Model model) {
		
		DataObject obj = new DataObject(100, "sejong", "sejong@gmail.com");
		
		model.addAttribute("Object", obj);
		
		return "index_03";
	}
	
	@GetMapping("data/{num}")
	public String eee(@PathVariable("num") int no, Model model) {
		
		model.addAttribute("No", no)
			 .addAttribute("check", no >= 0)
			 .addAttribute("trueVal", "양수입니다.")
			 .addAttribute("falseVal", "음수입니다.");
		
		return "index_04";
	}
	
}
