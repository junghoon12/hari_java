package com.boot.thymeleaf;

import java.util.ArrayList;
import java.util.List;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;


@Controller
public class BeginController {

	@RequestMapping("/{num}")
	public String abc(@PathVariable("num") int num,
						Model model) {
		
		int result = 0;
		
		for(int i=1; i<=num; i++) {
			
			result += i;    // result = result + i;
		}
		
		model.addAttribute("total", "total >>> " + result);
		
		return "total";
		
	}
	
	
	@RequestMapping("/message")
	public String bbb() {
		
		return "index_01";
	}
	
	
	@GetMapping("/data")
	public String ccc(Model model) {
		
		model.addAttribute("Msg", "방가방가 스프링부트");
		
		DataObject obj = new DataObject(100, "홍길동", "hong@naver.com");
		
		model.addAttribute("Object", obj);
		
		return "index_02";
	}
	
	@GetMapping("/data/{num}")
	public String ddd(@PathVariable("num") int no, Model model) {
		
		model.addAttribute("NO", no)
		     .addAttribute("check", no >= 0)
		     .addAttribute("trueVal", "양수입니다.")
		     .addAttribute("falseVal", "음수입니다.");
		
		return "index_03";
	}
	
	@GetMapping("/data1/{num}")
	public String eee(@PathVariable("num") int no, Model model) {
		
		model.addAttribute("NO", no)
		     .addAttribute("check", no >= 0)
		     .addAttribute("trueVal", "양수입니다.")
		     .addAttribute("falseVal", "음수입니다.");
		
		return "index_04";
	}
	
	
	@GetMapping("/score/{jumsu}")
	public String fff(@PathVariable("jumsu") double avg, 
						Model model) {
		
		model.addAttribute("Score", avg)
		     .addAttribute("Hakjum", Math.floor(avg/10));
		
		return "index_05";
	}
	
	
	@GetMapping("/array")
	public String ggg(Model model) {
		
		List<String[]> data = new ArrayList<>();
		
		data.add(new String[] {"hong", "홍길동", "010-1111-1234", "hong@naver.com"});
		data.add(new String[] {"leess", "이순신", "010-2222-2345", "leess@gmail.com"});
		data.add(new String[] {"yooks", "유관순", "010-3333-3456", "yooks@daum.net"});
		data.add(new String[] {"sejong", "세종대왕", "010-4444-4567", "sejong@naver.com"});
		data.add(new String[] {"shin", "신사임당", "010-5555-5678", "shin@naver.com"});
		
		model.addAttribute("List", data);
		
		return "index_06";
	}
	
	
	@GetMapping("/object")
	public String hhh(Model model) {
		
		List<DataObject> list = new ArrayList<DataObject>();
		
		list.add(new DataObject(100, "홍길동", "hong@naver.com"));
		list.add(new DataObject(101, "이순신", "leess@gmail.com"));
		list.add(new DataObject(102, "유관순", "yooks@daum.net"));
		list.add(new DataObject(103, "세종대왕", "sejong@gmail.com"));
		list.add(new DataObject(104, "신사임당", "shin@naver.com"));
		
		model.addAttribute("Data", list);
		
		return "index_07";
	}
	
	
	@GetMapping("/obj")
	public String iii(Model model) {
		
		List<DataObject> list = new ArrayList<DataObject>();
		
		list.add(new DataObject(100, "홍길동", "hong@naver.com"));
		list.add(new DataObject(101, "이순신", "leess@gmail.com"));
		list.add(new DataObject(102, "유관순", "yooks@daum.net"));
		list.add(new DataObject(103, "세종대왕", "sejong@gmail.com"));
		list.add(new DataObject(104, "신사임당", "shin@naver.com"));
		
		model.addAttribute("Data", list);
		
		return "index_08";
	}
	
	
	@GetMapping("/include")
	public String jjj() {
		
		return "index_09";
	}
	
	
	@GetMapping("/param")
	public String kkk(Model model) {
		
		model.addAttribute("Name", "홍길동")
		     .addAttribute("Email", "hong@naver.com");
		
		return "index_10";
		     
	}
	
}





