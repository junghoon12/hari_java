package com.boot.thymeleaf;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;


@Controller
public class BeginController {

	@GetMapping("/{num}")
	public String abc(@PathVariable("num") int num,
						Model model) {
		
		int result = 0;
		
		for(int i=1; i<=num; i++) {
			
			result += i;    // result = result + i;
		}
		
		model.addAttribute("total", "total >>> " + result);
		
		return "total";
		
	}
}
