package com.boot.member.model;

import java.util.List;
import java.util.Map;

import org.apache.ibatis.annotations.Mapper;

@Mapper
public interface MemberMapper {

	public List<MemberVO> list();
	
	public int add(MemberVO vo);
	
	public MemberVO cont(int num);
	
	public int modify(MemberVO vo);
	
	public int del(int num);
	
	public void seq(int num);
	
	public List<MemberVO> search(Map<String, String> map);
	
	
	
}
