package com.boot.member.controller;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.boot.member.model.Member;
import com.boot.member.model.MemberMapper;

import jakarta.servlet.http.HttpServletResponse;

@Controller
public class MemberController {

	@Autowired
	private MemberMapper mapper;
	
	
	@GetMapping("/")
	public String home() {
		
		return "main";
	}
	
	
	@GetMapping("member_list.go")
	public String list(Model model) {
		
		List<Member> memberList = this.mapper.list();
		
		model.addAttribute("List", memberList);
		
		return "member_list";
	}
	
	@GetMapping("member_insert.go")
	public String insert() {
		
		return "member_insert";
	}
	
	
	@PostMapping("member_insert_ok.go")
	public String insertOk(Member dto) {
		
		int chk = this.mapper.add(dto);
		
		if(chk > 0) {
			
			return "redirect:member_list.go";
		}else {
			
			return "redirect:member_insert.go";
		}
	}
	
	@GetMapping("member_content.go")
	public String cont(@RequestParam("no") int no, Model model) {
		
		Member content = this.mapper.cont(no);
		
		model.addAttribute("Cont", content);
		
		return "member_content";
	}
	
	
	@GetMapping("member_modify.go")
	public String modify(@RequestParam("no") int no, Model model) {
		
		Member content = this.mapper.cont(no);
		
		model.addAttribute("Modify", content);
		
		return "member_modify";
	}
	
	
	@PostMapping("member_modify_ok.go")
	public String modifyOk(Member dto,
					@RequestParam("db_pwd") String db_pwd,
					HttpServletResponse response) throws IOException {
		
		response.setContentType("text/html; charset=UTF-8");
		
		PrintWriter out = response.getWriter();
		
		if(db_pwd.equals(dto.getMempwd())) {
			
			int chk = this.mapper.modify(dto);
			
			if(chk > 0) {
				
				return "redirect:member_content.go?no="+dto.getMemno();
			}else {
				
				return "redirect:member_modify.go?no="+dto.getMemno();
			}
			
		}else {
			
			out.println("<script>");
			out.println("alert('비밀번호가 틀립니다.')");
			out.println("history.back()");
			out.println("</script>");
		}
		
		return null;
	}
	
	
	@GetMapping("member_delete.go")
	public String delete(@RequestParam("no") int no, Model model) {
		
		model.addAttribute("NO", no);
		
		return "member_delete";
	}
	
	@PostMapping("member_delete_ok.go")
	public String deleteOk(@RequestParam("no") int no,
			@RequestParam("pwd") String pwd,
			HttpServletResponse response) throws IOException {
		
		response.setContentType("text/html; charset=UTF-8");
		PrintWriter out = response.getWriter();
		
		Member cont = this.mapper.cont(no);
		
		if(pwd.equals(cont.getMempwd())) {
			
			int chk = this.mapper.del(no);
			
			if(chk > 0) {
				
				// 회원 번호 재작업 하는 메서드 호출.
				this.mapper.seq(no);
				
				return "redirect:member_list.go";
			}else {
				
				return "redirect:member_delete.go?no="+no;
			}
			
		}else {
			out.println("<script>");
			out.println("alert('비밀번호가 틀립니다.')");
			out.println("history.back()");
			out.println("</script>");
		}
		
		return null;
	}
	
	
	@PostMapping("member_search.go")
	public String search(@RequestParam("field") String field,
			@RequestParam("keyword") String keyword, Model model) {
		
		Map<String, String> map = new HashMap<>();
		
		map.put("field", field);
		map.put("keyword", keyword);
		
		List<Member> searchList = this.mapper.search(map);
		
		model.addAttribute("Search", searchList);
		
		
		return "member_search_list";
		
	}
	
	
	
	
	
	
	
}




