package com.goott.board.model;

import java.util.List;

import org.mybatis.spring.SqlSessionTemplate;
import org.springframework.stereotype.Repository;

import lombok.RequiredArgsConstructor;

@Repository
@RequiredArgsConstructor
public class BoardRepository {

	private final SqlSessionTemplate sqlSession;
	
	// board 테이블에서 전체 게시물을 가져오는 메서드.
	public List<Board> list() {
		
		return this.sqlSession.selectList("Board.list");
	}
	
	// board 테이블에 게시글을 추가하는 메서드.
	public int add(Board dto) {
		
		return this.sqlSession.insert("Board.write", dto);
	}
	
	
	// board 테이블의 조회수를 증가시켜 주는 메서드.
	public void readCount(int no) {
		
		this.sqlSession.update("Board.count", no);
	}
	
	// board 테이블의 게시글 번호에 해당하는 게시글의 상세내역을 조회하는 메서드.
	public Board getContent(int no) {
		
		return this.sqlSession.selectOne("Board.cont", no);
	}
	
	// board 테이블의 게시글 번호에 해당하는 게시글을 수정하는 메서드.
	public int modify(Board dto) {
		
		return this.sqlSession.update("Board.modify", dto);
	}
	
	// board 테이블의 게시글 번호에 해당하는 게시글을 삭제하는 메서드.
	public int del(int no) {
		
		return this.sqlSession.delete("Board.del", no);
	}
	
	// board 테이블의 게시글을 삭제 시 게시글 번호를 재작업 하는 메서드. 
	public void sequence(int no) {
		
		this.sqlSession.update("Board.seq", no);
	}
	
	
}
