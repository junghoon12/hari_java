package com.boot.board.model;

import java.util.List;
import java.util.Map;

import org.apache.ibatis.annotations.Mapper;

@Mapper
public interface BoardMapper {

	// 페이징 작업 시 전체 게시물의 수를 조회하는 추상 메서드.
	public int cnt();
	
	// 한 페이지당 보여질 게시물을 조회하는 추상 메서드.
	public List<BoardVO> list(PageVO vo);
	
	// 게시글을 추가하는 추상 메서드.
	public int add(BoardVO vo);
	
	// 게시글을 상세 조회시 조회수를 증가시켜 주는 추상 메서드.
	public void read(int no);
	
	// 글번호에 해당하는 게시글을 조회하는 추상 메서드.
	public BoardVO cont(int no);
	
	// 글번호에 해당하는 게시글을 수정하는 추상 메서드.
	public int edit(BoardVO vo);
	
	// 글번호에 해당하는 게시글을 삭제하는 추상 메서드.
	public int del(int no);
	
	// 글번호에 해당하는 게시글 삭제 시 글번호 재작업하는 추상 메서드.
	public void seq(int no);
	
	// 게시글을 검색 시 검색한 게시글의 수를 확인하는 추상 메서드.
	public int searchCount(Map<String, String> map);
	
	// 검색된 게시글을 페이지당 보여질 게시물의 수만큼 조회하는 추상 메서드.
	public List<BoardVO> search(PageVO vo);
	
	
}
