package com.boot.board.controller;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.boot.board.model.BoardMapper;
import com.boot.board.model.BoardVO;
import com.boot.board.model.PageVO;

import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

@Controller
public class BoardController {

	@Autowired
	private BoardMapper mapper;
	
	// 한 페이지당 보여질 게시물의 수
	private final int rowsize = 3;
	
	// DB 상의 전체 게시물의 수
	private int totalRecord = 0;
	
	@GetMapping("/")
	public String index() {
		
		return "index";
	}
	
	
	@GetMapping("board_list.do")
	public String list(@RequestParam(value = "page", defaultValue = "1") int page,
							Model model) {
		
		// DB 상의 전체 게시물의 수를 확인하는 메서드 호출
		totalRecord = this.mapper.cnt();
		
		PageVO pVo = new PageVO(page, rowsize, totalRecord);
		
		// 현재 페이지에 해당하는 게시물을 가져오는 메서드 호출.
		List<BoardVO> list = this.mapper.list(pVo);
		
		model.addAttribute("List", list)
			 .addAttribute("Paging", pVo);
		
		return "board_list";
		
	}
	
	
	@GetMapping("board_write.do")
	public String write() {
		
		return "board_write";
	}
	
	
	@PostMapping("board_write_ok.do")
	public void writeOk(BoardVO vo,
				HttpServletResponse response) throws IOException {
		
		response.setContentType("text/html; charset=UTF-8");
		
		PrintWriter out = response.getWriter();
		
		// DB에 글쓰기 폼에서 넘어온 정보를 넘겨서 
		// DB에 저장되도록 해 주면 됨.
		int res = this.mapper.add(vo);
		
		if(res > 0) {
			out.println("<script>");
			out.println("alert('게시글 추가 성공!!!')");
			out.println("location.href='board_list.do'");
			out.println("</script>");
		}else {
			out.println("<script>");
			out.println("alert('게시글 추가 실패~~~')");
			out.println("history.back()");
			out.println("</script>");
		}
		
	}
	
	
	@GetMapping("board_content.do")
	public String cont(@RequestParam("no") int no,
			@RequestParam("page") int nowPage, Model model) {
		
		// 게시글의 조회 수를 하나 증가시켜 주는 메서드 호출.
		this.mapper.read(no);
		
		// 게시글의 상세 내역을 조회하는 메서드 호출.
		BoardVO cont = this.mapper.cont(no);
		
		model.addAttribute("Content", cont)
		     .addAttribute("page", nowPage);
		
		return "board_content";
		
	}
	
	
	@GetMapping("board_modify.do")
	public String modify(@RequestParam("no") int no,
			@RequestParam("page") int nowPage, Model model) {
		
		// 게시글의 상세 내역을 조회하는 메서드 호출.
		BoardVO content = this.mapper.cont(no);
		
		model.addAttribute("Modify", content)
			 .addAttribute("page", nowPage);
		
		return "board_modify";
		
	}
	
	
	
	@PostMapping("board_modify_ok.do")
	public void modifyOk(BoardVO vo,
			@RequestParam("db_pwd") String db_pwd,
			@RequestParam("page") int nowPage,
			HttpServletResponse response) throws IOException {
		
		response.setContentType("text/html; charset=UTF-8");
		
		PrintWriter out = response.getWriter();
		
		if(vo.getBoard_pwd().equals(db_pwd)) {
			
			// 게시글을 수정하는 메서드 호출
			int chk = this.mapper.edit(vo);
			
			if(chk > 0) {
				out.println("script>");
				out.println("alert('게시글 수정 성공!!!')");
				out.println("location.href='board_content.do?no="+vo.getBoard_no()+"&page="+nowPage+"'");
				out.println("/script>");
			}else {
				out.println("script>");
				out.println("alert('게시글 수정 실페~~~')");
				out.println("history.back()");
				out.println("/script>");
			}
			
			
		}else {
			out.println("script>");
			out.println("alert('비밀번호가 틀립니다. 확인해 주세요~~~')");
			out.println("history.back()");
			out.println("/script>");
		}
	}
	
	
	@GetMapping("board_delete.do")
	public String delete(@RequestParam("no") int no,
			@RequestParam("page") int nowPage, Model model) {
		
		model.addAttribute("No", no)
		     .addAttribute("page", nowPage);
		
		return "board_delete";
		
	}
	
	
	@PostMapping("board_delete_ok.do")
	public void deleteOk(BoardVO vo,
			@RequestParam("page") int nowPage,
			HttpServletResponse response) throws IOException {
		
		response.setContentType("text/html; charset=UTF-8");
		
		PrintWriter out = response.getWriter();
		
		BoardVO cont = this.mapper.cont(vo.getBoard_no());
		
		if(vo.getBoard_pwd().equals(cont.getBoard_pwd())) {
			
			int res = this.mapper.del(vo.getBoard_no());
			
			if(res > 0) {
				
				this.mapper.seq(vo.getBoard_no());
				
				out.println("<script>");
				out.println("alert('게시글 삭제 성공!!!')");
				out.println("location.href='board_list.do?page="+nowPage+"'");
				out.println("</script>");
			}else {
				out.println("<script>");
				out.println("alert('게시글 삭제 실패~~~')");
				out.println("history.back()");
				out.println("</script>");
			}
			
		}else {
			// 비밀번호가 틀린 경우
			out.println("<script>");
			out.println("alert('비밀번호가 틀려요. 확인해 주세욤~~~')");
			out.println("history.back()");
			out.println("</script>");
		}
	}
	
	
	@RequestMapping("board_search.do")
	public String search(@RequestParam("field") String field,
			@RequestParam("keyword") String keyword,
			HttpServletRequest request, Model model) {
		
		// 검색 시 페이징 처리 작업
		int page;               // 현재 페이지 변수
		if(request.getParameter("page") != null) {
			page = Integer.parseInt(request.getParameter("page"));
		}else {
			page = 1;           // 검색 버튼을 누른 경우
		}
		
		// 검색 분류와 검색어에 해당하는 게시글의 수를
		// DB에서 확인하는 메서드 호출.
		Map<String, String> map = new HashMap<String, String>();
		
		map.put("field", field);
		map.put("keyword", keyword);
		
		totalRecord = this.mapper.searchCount(map);
		
		PageVO pVo = new PageVO(page, rowsize, totalRecord, field, keyword);
		
		// 검색 시 한 페이지당 보여질 게시물의 수만큼
		// 검색한 게시물을 List로 가져오는 메서드 호출.
		List<BoardVO> searchList = this.mapper.search(pVo);
		
		model.addAttribute("SearchList", searchList)
		     .addAttribute("Paging", pVo);
		
		return "board_searchList";
		
	}
	
}
