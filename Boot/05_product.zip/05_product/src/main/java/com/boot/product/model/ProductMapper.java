package com.boot.product.model;

import java.util.List;

import org.apache.ibatis.annotations.Mapper;


@Mapper
public interface ProductMapper {

	List<Product> list();
	
	int add(Product dto);
	
	Product cont(int pnum);
	
	int modify(Product dto);
	
	int delete(int pnum);
	
	void seq(int pnum);
	
	List<Category> category();
	
}
