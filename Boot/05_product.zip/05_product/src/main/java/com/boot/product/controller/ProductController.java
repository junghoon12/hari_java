package com.boot.product.controller;


import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.boot.product.model.Category;
import com.boot.product.model.Product;
import com.boot.product.model.ProductMapper;



@Controller
public class ProductController {

	@Autowired
	private ProductMapper mapper;
	
	
	@GetMapping("/")
	public String home() {
		
		return "main";
	}
	
	@GetMapping("product_list.go")
	public String list(Model model) {
		
		List<Product> productList = this.mapper.list();
		
		model.addAttribute("List", productList);
		
		return "product_list";
	
	}
	
	
	@GetMapping("product_insert.go")
	public String insert(Model model) {
		
		// 카테고리 코드 전체 목록을 조회하는 메서드 호출.
		List<Category> categoryList = this.mapper.category();
		
		model.addAttribute("Category", categoryList);
		
		return "product_insert";
	
	}
	
	
	@PostMapping("product_insert_ok.go")
	public String insertOk(Product dto) {
		
		int chk = this.mapper.add(dto);
		
		if(chk > 0) {
			
			return "redirect:product_list.go";
		}else {
			
			return "refirect:product_insert.go";
		}
		
	}
	
	@GetMapping("product_content.go")
	public String cont(@RequestParam("pnum") int pnum,
							Model model) {
		
		Product content = this.mapper.cont(pnum);
		
		model.addAttribute("Cont", content);
		
		
		return "product_content";
		
	}
	
	
	@GetMapping("product_modify.go")
	public String modify(@RequestParam("pnum") int pnum, 
							Model model) {
		
		Product content = this.mapper.cont(pnum);
		
		model.addAttribute("Modify", content);
		
		
		return "product_modify";
		
	}
	
	
	@PostMapping("product_modify_ok.go")
	public String modifyOk(Product dto) {
		
		int chk = this.mapper.modify(dto);
		
		if(chk > 0) {
			
			return "redirect:product_content.go?pnum="+dto.getPnum();
		}else {
			
			return "redirect:product_modify.go?pnum="+dto.getPnum();
		}
	}
	
	
	@GetMapping("product_delete.go")
	public String delete(@RequestParam("pnum") int pnum) {
		
		int chk = this.mapper.delete(pnum);
		
		if(chk > 0) {
			
			// 삭제 시 제품번호 재작업 하는 메서드 호출.
			this.mapper.seq(pnum);
			
			return "redirect:product_list.go";
		}else {
			
			return "redirect:product_delete.go?pnum="+pnum;
		}
	}
	
}
