package com.nonspring.java02;

public class Main {

	public static void main(String[] args) {
		
		// Service service = new CC();
		Service service = new DD();
		
		service.printMsg();

	}

}
