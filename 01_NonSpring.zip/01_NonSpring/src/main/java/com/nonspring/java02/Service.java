package com.nonspring.java02;

public interface Service {

	void printMsg();
	
}
