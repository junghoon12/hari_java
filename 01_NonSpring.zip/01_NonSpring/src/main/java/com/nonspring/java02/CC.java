package com.nonspring.java02;

public class CC implements Service {

	@Override
	public void printMsg() {
		
		System.out.println("Hello");
		
	}

}
