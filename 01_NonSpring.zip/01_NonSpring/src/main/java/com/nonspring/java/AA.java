package com.nonspring.java;

public class AA {

	void printMsg() {
		
		System.out.println("Hello");
	
	}
}
