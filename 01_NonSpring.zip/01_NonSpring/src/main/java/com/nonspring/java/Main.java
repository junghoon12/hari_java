package com.nonspring.java;

public class Main {

	public static void main(String[] args) {
		
		// AA aa = new AA();
		
		// aa.printMsg();
		
		BB bb = new BB();
		
		bb.printMsg();

	}

}
