package com.nonspring.java;

public class BB {

	void printMsg() {
		System.out.println("안녕하세요!!!");
	}
}
