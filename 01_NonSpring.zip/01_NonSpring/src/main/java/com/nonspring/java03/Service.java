package com.nonspring.java03;

public interface Service {

	void printMsg();
	
}
