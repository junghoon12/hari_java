package com.nonspring.java03;

public class CC implements Service {

	@Override
	public void printMsg() {
		
		System.out.println("Hello");
		
	}

}
