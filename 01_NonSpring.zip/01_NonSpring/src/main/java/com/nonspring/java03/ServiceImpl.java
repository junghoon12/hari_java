package com.nonspring.java03;

public class ServiceImpl {

	private Service service;
	
	public ServiceImpl() {  }  // 기본 생성자
	
	public ServiceImpl(Service service) {
		
		this.service = service;
	}  // 인자 생성자
	
	
	public Service getService() {
		return service;
	}

	public void setService(Service service) {
		this.service = service;
	}

	// 비지니스 로직
	public void biz() {
		
		service.printMsg();
		
	}
	
	
}
