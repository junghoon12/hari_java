package com.nonspring.java03;

public class Main {

	public static void main(String[] args) {
		
		// 1. 인자 생성자를 이용하여 주입.
		ServiceImpl impl = 
				new ServiceImpl(new DD());
		
		impl.biz();
		
		// 2. setter() 메서드를 이용하여 주입.
		ServiceImpl impl2 = 
				new ServiceImpl();
		
		impl2.setService(new CC());
		impl2.biz();

	}

}
