package com.nonspring.java03;

public class DD implements Service {

	@Override
	public void printMsg() {
		
		System.out.println("안녕하세요!!!");
		
	}

}
