package com.khie.controller;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.khie.model.StudentDAO;
import com.khie.model.StudentDTO;


@WebServlet("/updateOk")
public class UpdateOkServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    
    public UpdateOkServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	
	protected void service(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// 수정폼 페이지에서 넘어온 정보들을 DB에
		// 저장하는 비지니스 로직.
		// 한글 인코딩 설정 처리 진행.
		request.setCharacterEncoding("UTF-8");
		response.setContentType("text/html; charset=UTF-8");
		
		// 1단계 : 수정 폼 페이지에서 넘어온 정보들을 받아 주자.
		String student_hakbun = 
				request.getParameter("hakbun").trim();
		String student_name = 
				request.getParameter("name").trim();
		String student_major = 
				request.getParameter("major").trim();
		String student_phone = 
				request.getParameter("phone").trim();
		String student_addr = 
				request.getParameter("addr").trim();
		
		// 2단계 : DTO 객체에 폼 페이지에서 넘어온 데이터들을
		//        저장해 주어야 한다.
		StudentDTO dto = new StudentDTO();
		
		dto.setHakbun(student_hakbun);
		dto.setName(student_name);
		dto.setMajor(student_major);
		dto.setPhone(student_phone);
		dto.setAddr(student_addr);
		
		// 3단계 : DTO 객체를 DB에 전송
		StudentDAO dao = new StudentDAO();
		
		int check = dao.updateStudent(dto);
		
		PrintWriter out = response.getWriter();
		
		if(check > 0) {
			out.println("<script>");
			out.println("alert('학생 정보 수정 성공!!!')");
			out.println("location.href='select'");
			out.println("</script>");
		}else {
			out.println("<script>");
			out.println("alert('학생 정보 수정 실패ㅠㅠㅠ')");
			out.println("history.back()");
			out.println("</script>");
		}
		
	}

}
