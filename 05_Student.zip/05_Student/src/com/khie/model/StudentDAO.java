package com.khie.model;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;



/*
 * DAO(Data Access Object)
 * - 데이터 접근 객체 ==> DB에 접속(연동)하는 객체.
 * - DAO란 데이터베이스에 접속해서 데이터를 추가, 수정,
 *   삭제, 조회 등의 작업을 하는 클래스.
 * - 일반적으로 JSP 또는 Servlet에서 위의 작업들을 같이
 *   사용할 수 있지만, 유지보수, 코드의 모듈화 등을 위해서
 *   DAO 클래스를 따로 만들어서 사용을 함.
 */

public class StudentDAO {

	// DB와 연동하는 객체.
	Connection con = null;            
	
	// DB에 SQL문을 전송하는 객체.
	PreparedStatement pstmt = null;   
	
	// SQL문을 실행한 후에 결과값을 가지고 있는 객체.
	ResultSet rs = null;
	
	// 쿼리문을 저장할 객체.
	String sql = null;
	
	public StudentDAO() {  // 기본 생성자
		
		String driver = 
			"oracle.jdbc.driver.OracleDriver";
		
		String url =
			"jdbc:oracle:thin:@localhost:1521:xe";
		
		String user = "web";
		
		String password = "1234";
		
		try {
			// 1단계 : 오라클 드라이버를 메모리로 로딩
			Class.forName(driver);
			
			// 2단계 : 오라클 데이터베이스와 연결 작업 진행.
			con = DriverManager.getConnection(url, user, password);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	
	}  // 기본 생성자 end
	
	
	// student 테이블에서 학생 전체 목록을 조회하는 메서드.
	public List<StudentDTO> selectList() {
		
		List<StudentDTO> list = 
				new ArrayList<StudentDTO>();  // 다형성
		
		try {
			// 3단계 : 데이터베이스에 전송할 SQL문 작성.
			sql = "select * from student "
					+ " order by hakbun desc";
			
			// 4단계 : SQL문을 데이터베이스에 전송 객체에 저장.
			pstmt = con.prepareStatement(sql);
			
			// 5단계 : SQl문을 데이터베이스에 전송 및 실행.
			rs = pstmt.executeQuery();
			
			while(rs.next()) {
				StudentDTO dto = new StudentDTO();
				
				dto.setHakbun(rs.getString("hakbun"));
				dto.setName(rs.getString("name1"));
				dto.setMajor(rs.getString("major"));
				dto.setPhone(rs.getString("phone"));
				dto.setAddr(rs.getString("addr"));
				dto.setRegdate(rs.getString("regdate"));
				
				list.add(dto);
			}
			
			// 6단계 : DB와 연결되어 있던 자원 종료하기.
			rs.close(); pstmt.close(); con.close();
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		return list;
	}  // selectList() 메서드 end
	
	// student 테이블에 학생을 등록하는 메서드.
	public int insertStudent(StudentDTO dto) {
		int result = 0;
		
		
		try {
			// 3단계 : 데이터베이스에 전송할 SQL문 작성.
			sql = "insert into student "
					+ " values(?, ?, ?, ?, ?, sysdate)";
			
			// 4단계 : SQL문을 데이터베이스에 전송 객체에 저장.
			pstmt = con.prepareStatement(sql);
			
			// 4-1 : ?(플레이스 홀더)에 데이터를 배정
			pstmt.setString(1, dto.getHakbun());
			pstmt.setString(2, dto.getName());
			pstmt.setString(3, dto.getMajor());
			pstmt.setString(4, dto.getPhone());
			pstmt.setString(5, dto.getAddr());
			
			// 5단계 : SQl문을 데이터베이스에 전송 및 실행.
			result = pstmt.executeUpdate();
			
			// 6단계 : DB와 연결되어 있던 자원 종료하기.
			pstmt.close(); con.close();
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		return result;
	}  // insertStudent() 메서드 end
	
	
	// 학번에 해당하는 학생의 정보를 조회하는 메서드.
	public StudentDTO getStudent(String hak) {
		
		StudentDTO dto = null;
		
		try {
			// 3단계 : 데이터베이스에 전송할 SQL문 작성.
			sql = "select * from student "
							+ "	where hakbun = ?";
			
			// 4단계 : SQL문을 데이터베이스에 전송 객체에 저장.
			pstmt = con.prepareStatement(sql);
			
			// 4-1 : ?(플레이스 홀더)에 데이터를 배정.
			pstmt.setString(1, hak);
			
			// 5단계 : SQl문을 데이터베이스에 전송 및 실행.
			rs = pstmt.executeQuery();
			
			while(rs.next()) {
				dto = new StudentDTO();
				
				dto.setHakbun(rs.getString("hakbun"));
				dto.setName(rs.getString("name1"));
				dto.setMajor(rs.getString("major"));
				dto.setPhone(rs.getString("phone"));
				dto.setAddr(rs.getString("addr"));
				dto.setRegdate(rs.getString("regdate"));
				
			}
			
			// 6단계 : DB와 연결되어 있던 자원 종료하기.
			rs.close(); pstmt.close(); con.close();
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	
		return dto;
	}  // getStudent() 메서드 end
	
	
	// 수정된 정보를 저장하는 메서드
	public int updateStudent(StudentDTO dto) {
		
		int result = 0;
		
		
		try {
			// 3단계 : 데이터베이스에 전송할 SQL문 작성.
			sql = "update student set major = ?, "
					+ " phone = ?, addr = ? where hakbun = ?";
			
			// 4단계 : SQL문을 데이터베이스에 전송 객체에 저장.
			pstmt = con.prepareStatement(sql);
			
			// 4-1 : ?(플레이스 홀더)에 데이터를 배정.
			pstmt.setString(1, dto.getMajor());
			pstmt.setString(2, dto.getPhone());
			pstmt.setString(3, dto.getAddr());
			pstmt.setString(4, dto.getHakbun());
			
			// 5단계 : SQl문을 데이터베이스에 전송 및 실행.
			result = pstmt.executeUpdate();
			
			// 6단계 : DB와 연결되어 있던 자원 종료하기.
			pstmt.close(); con.close();
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		return result;
	}  // updateStudent() 메서드 end
	
	
	// 학생의 학번에 해당하는 학생을 삭제하는 메서드.
	public int deleteStudent(String hakbun) {
		
		int result = 0;
		
		try {
			// 3단계 : 데이터베이스에 전송할 SQL문 작성.
			sql = "delete from student "
						+ "	where hakbun = ?";
			
			// 4단계 : SQL문을 데이터베이스에 전송 객체에 저장.
			pstmt = con.prepareStatement(sql);
			
			// 4-1 : ?(플레이스 홀더)에 데이터를 배정.
			pstmt.setString(1, hakbun);
			
			// 5단계 : SQl문을 데이터베이스에 전송 및 실행.
			result = pstmt.executeUpdate();
			
			// 6단계 : DB와 연결되어 있던 자원 종료하기.
			pstmt.close(); con.close();
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		return result;
	}  // deleteStudent() 메서드 end
	
	
	
	
}
