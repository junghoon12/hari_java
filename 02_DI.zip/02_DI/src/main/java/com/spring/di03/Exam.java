package com.spring.di03;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class Exam {

	private String msg;
	
	
	// 비지니스 로직
	public void output() {
		System.out.println("메세지 >>> " + msg);
	}
	
}



