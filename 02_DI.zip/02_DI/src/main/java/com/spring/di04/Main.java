package com.spring.di04;

import org.springframework.context.support.AbstractApplicationContext;
import org.springframework.context.support.GenericXmlApplicationContext;

public class Main {

	public static void main(String[] args) {
		
		String path = "classpath:person.xml";
		
		AbstractApplicationContext ctx = 
				new GenericXmlApplicationContext
						(path);
		
		PersonInfo info = 
				ctx.getBean("info", PersonInfo.class);
		
		info.getPersonInfo();
		
		ctx.close();
		

	}

}
