package com.spring.di02;

import lombok.Data;

@Data
public class ServiceImpl {

	private DAO dao;
	
	
	// 비지니스 로직
	public void biz() {
		
		this.dao.add();
	
	}
}
