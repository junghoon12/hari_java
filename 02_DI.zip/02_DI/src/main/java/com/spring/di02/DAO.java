package com.spring.di02;

public interface DAO {

	void add();     // 추상 메서드

}
