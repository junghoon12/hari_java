package com.spring.di02;

public class MySqlDAO implements DAO {

	@Override
	public void add() {
		System.out.println("MySqlDAO 연동입니다.~~~");
	}

}

