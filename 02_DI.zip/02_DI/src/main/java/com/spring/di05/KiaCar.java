package com.spring.di05;

public class KiaCar implements Car {

	@Override
	public void drive() {
		System.out.println("기아차를 운전합니다.~~~");
	}

}
