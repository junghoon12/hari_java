package com.spring.di05;

public class SamsungCar implements Car {

	@Override
	public void drive() {
		System.out.println("르노 삼성차를 운전합니다.~~~");
	}

}
