package com.spring.di05;

public class HyundaiCar implements Car {

	@Override
	public void drive() {
		System.out.println("현대차를 운전합니다.~~~");
	}

}
