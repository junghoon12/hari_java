package com.spring.di05;

public interface Car {

	void drive();
	
}
