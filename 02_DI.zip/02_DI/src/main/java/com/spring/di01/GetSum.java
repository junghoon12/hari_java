package com.spring.di01;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class GetSum {

	private int su1;
	private int su2;
	
	
	// 비지니스 로직
	public void hap(int su1, int su2) {
		System.out.println("더하기 >>> " + (su1+su2));
	}
}
