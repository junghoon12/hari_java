package com.spring.di01;

import lombok.Data;

@Data
public class MyGetSum {

	private int su1;
	private int su2;
	private GetSum getSum;
	
	
	// 비지니스 로직
	public void sum() {
		
		this.getSum.hap(su1, su2);
	}
	
	
}
