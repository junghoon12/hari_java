import { Route, Routes } from "react-router-dom";
import MemberList from "./components/MemberList";
import MemberDetail from "./components/MemberDetail";

function App() {
  

  return (
    <>
      <Routes>
        <Route path="/" element={<MemberList />} />
        <Route path="/member/:memno" element={<MemberDetail />} />
      </Routes>
    </>
  )
}

export default App
