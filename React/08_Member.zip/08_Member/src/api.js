import axios from "axios";

const BASE_URL = "http://localhost:8585/api/member";

export const getMembers = () => axios.get(`${BASE_URL}/list`);
export const getMember = (id) => axios.get(`${BASE_URL}/${id}`);