import { useState, useEffect } from "react";
import { getMembers } from "../api";
import { Link } from "react-router-dom";


const MemberList = () => {

    const [list, setList] = useState([]);

    useEffect(() => {
        getMembers()
            .then((res) => {
                setList(res.data);
            })
            .catch((err) => {
                console.log("Error Member List >>> ", err);
            })
    }, []);

    console.log(list);
    
    return (
        <div>
            <h2>MEMBER 테이블 전체 회원 목록 페이지</h2>
            <table border={1} width={500}>
                <thead>
                    <tr>
                        <th>회원 No.</th> <th>회원 이름</th>
                        <th>회원 직업</th> <th>회원 등록일</th>
                    </tr>
                </thead>

                <tbody>
                    {list.map((member) => (
                        <tr key={member.memno}>
                            <td> {member.memno} </td>
                            <td> 
                                <Link to={`/member/${member.memno}`}>
                                            {member.memname } </Link></td>
                            <td> {member.job} </td>
                            <td> {member.regdate.substring(0, 10)} </td>
                        </tr>    
                    ))}
                </tbody>
            </table>
        </div>
    );
}

export default MemberList;