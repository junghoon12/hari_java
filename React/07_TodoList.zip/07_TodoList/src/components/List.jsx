import TodoItem from "./TodoItem";
import "../css/list.css";
import { useState } from "react";


const List = ({todos, onDelete}) => {

    const [search, setSearch] = useState("");

    const onChangeSearch = (e) => {
        setSearch(e.target.value);
    }

    // 함수를 하나 만들자.
    const getFileredData = () => {
        if(search === "") {
            return todos;  // 전체 리스트를 반환
        }
        return todos.filter((todo) => 
            todo.content.includes(search));
    }

    const filteredTodos = getFileredData();

    return (
        <div className="list">
            <h4>Todo List🌱`</h4>
            <input placeholder="검색어를 입력하세요"
                value={search}
                onChange={onChangeSearch}
            />
            <div className="todos_wrapper">
                {filteredTodos.map((todo) => {
                    return <TodoItem key={todo.id} {...todo}
                                    onDelete={onDelete} />
                })}                                 
            </div>
        </div>
    );

}

export default List;