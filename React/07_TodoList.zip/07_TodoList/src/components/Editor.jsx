import "../css/editor.css";
import { useState, useRef } from "react";


const Editor = ({onCreate}) => {

    const [content, setContent] = useState("");
    const contentRef = useRef("");

    const onChangeContent = (e) => {
        setContent(e.target.value);
    }


    const onSubmit = () => {
        if(content === "") {
            alert("할 일을 입력하세요...");
            contentRef.current.focus();
            return;
        }
        onCreate(content);
        setContent("");
    }

    const onKeyDown = (e) => {
        if(e.keyCode === 13) {
            onSubmit();
        }
    }

    return (
        <div className="editor">
            <input placeholder="새로운 Todo..."
                   onChange={onChangeContent}
                   value={content}
                   onKeyDown={onKeyDown}
                   ref={contentRef} />
            <button onClick={onSubmit}>추가</button>
        </div>
    );

}

export default Editor;