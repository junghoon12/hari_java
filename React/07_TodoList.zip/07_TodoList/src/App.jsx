import Header from "./components/Header";
import Editor from "./components/Editor";
import List from "./components/List";
import "./App.css";
import { useState, useRef } from "react";

const mokData = [
  {
    id : 0,
    isDone : false,
    content : "React 공부하기",
    date : new Date().getTime(),
  },

  {
    id : 1,
    isDone : false,
    content : "게임하기",
    date : new Date().getTime(),
  },

  {
    id : 2,
    isDone : false,
    content : "여친과 영화보기",
    date : new Date().getTime(),
  },

]


function App() {
  
  const [todos, setTodos] = useState(mokData);
  const idRef = useRef(3);

  const onCreate = (content) => {
    const newTodo = {
      id : idRef.current++,
      isDone : false,
      content : content,  // 매개변수로 받은 content를 받아주면 됨.
      date : new Date().getTime()
    }
    setTodos([newTodo, ...todos]);
  }

  return (
    <div className="app">
      <Header />
      <Editor onCreate={onCreate} />
      <List todos={todos} />
    </div>
  )
}

export default App
