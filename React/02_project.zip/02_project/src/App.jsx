import './App.css';
import Header from "./components/Header.jsx";
import Footer from './components/Footer.jsx';
import Main from './components/Main.jsx';
import Button from './components/Button.jsx';

function App() {

  const bodyProps = {
    name : "홍길동",
    addr : "경기도 파주시",
    // favorFoods : ["족발", "소고기", "치킨"]
  }

  return (
    <>
      <Header />
      <Main {...bodyProps} />
      <Button />
      <Footer />
    </>
  )
}

export default App
