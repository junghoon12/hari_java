import "./main.css";

function Main({name, addr, favorFoods = []}) {

    // const {} = favorFoods;
    
    return (
        <div>
            <h3> {name} 은(는)  {addr} 에 거주합니다. <br />
                 {favorFoods.join(", ")} 음식을 좋아합니다.
            </h3>
        </div>
    );
}

// Main.defaultProps = {
//     favorFoods : [],
// }


export default Main;

/*
  JSX 문법
  1. 모든 태그는 닫는 태그가 반드시 있어야 함.
  2. 변수나 수식을 표현할 경우에는 반드시 중괄호({}) 안에 표시해야 함.
     ==> 숫자, 문자열, 배열만 정상적으로 웹브라우저에 렌더링이 됨.
  3. 반환되는 최상위 태그는 하나 이어야만 한다.
  4. 스타일 적용시에는 인라인 방식과 외부 파일 방식이 있음.
*/