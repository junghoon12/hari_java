function Button() {

    function handleOnClick(e) {
        console.log(e);
        console.log(e.target.name);
    }
    return (
        <div>
            <button name="A버튼" onClick={handleOnClick}>클릭하세요</button>
            <button name="B버튼" onClick={handleOnClick}>클릭하세요</button>
        </div>
    )
}

export default Button;