function Header() {

  return (
    <header>
      <h1>Header 영역</h1>
    </header>
  );
}

export default Header;