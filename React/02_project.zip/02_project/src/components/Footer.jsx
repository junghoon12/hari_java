function Footer() {

    return (
        <footer>
            <h1>하단 footer 영역</h1>
        </footer>
    );
}

export default Footer;