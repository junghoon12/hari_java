import { Table } from "reactstrap";


const ReactstrapTable = () => {

    return (

        <div>
            <Table striped hover>
                <thead>
                    <th>No.</th> <th>책 제목</th> <th>책 가격</th>
                </thead>

                <tbody>
                    <tr>
                        <td scope="row">1</td>
                        <td>생활코딩 React 프로그래밍</td>
                        <td>25,000원</td>
                    </tr>

                    <tr>
                        <td scope="row">2</td>
                        <td>이것이 자바다</td>
                        <td>38,000원</td>
                    </tr>

                    <tr>
                        <td scope="row">3</td>
                        <td>이것이 MySQL이다</td>
                        <td>32,000원</td>
                    </tr>
                </tbody>
            </Table>
        </div>

    );
}

export default ReactstrapTable;