import { Button } from "reactstrap";

const ReactstrapButton = () => {

    return (
        <div>
            <Button color="primary">primary</Button>&nbsp;&nbsp;
            <Button color="info">info</Button>&nbsp;&nbsp;
            <Button color="success">success</Button>&nbsp;&nbsp;
            <Button color="warning">warning</Button>&nbsp;&nbsp;
            <Button color="danger">danger</Button>&nbsp;&nbsp;
            <Button color="dark">dark</Button>&nbsp;&nbsp;
            <Button color="secondary">secondary</Button>&nbsp;&nbsp;
            <Button color="light">light</Button>&nbsp;&nbsp;
        </div>
    );

}

export default ReactstrapButton;