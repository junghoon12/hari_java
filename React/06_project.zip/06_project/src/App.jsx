import "bootstrap/dist/css/bootstrap.css";
import ReactstrapButton from "./components/ReactstrapButton";
import ReactstrapForm from "./components/ReactstrapForm";
import ReactstrapPagination from "./components/ReactstrapPagination";
import ReactstrapTable from "./components/ReactstrapTable";

function App() {
 

  return (
    <>
      <ReactstrapTable />
    </>
  )
}

export default App
