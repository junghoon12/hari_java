import {useState} from "react";

function App() {
 
  const [text, setText] = useState("");
  const [date, setDate] = useState("");

  const handleOnChange = (e) => {
    setDate(e.target.value);
  }

  return (
    <>
      <div>
        <div>
          <input onChange={(e) => {
              setText(e.target.value);
          }}></input> <br />
          <div>{text}</div>
        </div>

        <div>
          <input type="date"
              onChange={handleOnChange}></input> <br />
          <div> 오늘 날짜 : {date}</div>
        </div>
      </div>
    </>
  )
}

export default App
