import Register from "./components/Register";
import Register1 from "./components/Register1";


function App() {
 
  return (
    <>
      {/* <Register />      */}
      <Register1 />
    </>
  )
}

export default App
