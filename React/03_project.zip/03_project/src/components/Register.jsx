import { useState } from "react";
// 간단하게 회원 가입 폼을 만들어 보자.
// 1. 이름
// 2. 생년월일
// 3. 국적
// 4. 자기소개

const Register = () => {

    const [input, setInput] = useState({
        name : "",
        birth : "",
        country : "",
        text : ""
    })

    const onChange = (e) => {
       console.log(e.target.name, e.target.value)
       setInput({
            ...input,
            [e.target.name] : e.target.value,
       }) 
    }


    return (
        <div>
            <div>
                <input name="name" onChange={onChange} placeholder={"이름을 입력하세요"} />
                <span>{input.name}</span>
            </div>

            <div>
                <input type="date" name="birth" onChange={onChange} />
                <span>{input.birth}</span>
            </div>

            <div>
                <select name="country" onChange={onChange}>
                    <option value=""></option>
                    <option value="KR">한국</option>
                    <option value="US">미국</option>
                    <option value="UK">영국</option>
                </select>
                <span>{input.country}</span>
            </div>

            <div>
                <textarea name="text" onChange={onChange} />
                <span>{input.text}</span>
            </div>
        </div>
    );
}

export default Register;