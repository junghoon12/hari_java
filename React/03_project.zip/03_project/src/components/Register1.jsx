import { useState, useRef } from "react";

// 간단하게 회원 가입 폼을 만들어 보자.
// 1. 이름
// 2. 생년월일
// 3. 국적
// 4. 자기소개

const Register1 = () => {

    const [input, setInput] = useState({
        name : "",
        birth : "",
        country : "",
        text : ""
    })

    const countRef = useRef(0);
    const inputRef = useRef(0);
    // console.log("register 렌더링");

    const onChange = (e) => {
       countRef.current++;
       console.log(countRef.current)
       setInput({
            ...input,
            [e.target.name] : e.target.value,
       }) 
    }

    const onSubmit = () => {
        if(input.name === "") {
            alert("이름을 입력하세요~~~");
            inputRef.current.focus();
        }
    }


    return (
        <div>
            <div>
                <input name="name" ref={inputRef} 
                       onChange={onChange} placeholder={"이름을 입력하세요"} />
                <span>{input.name}</span>
            </div>

            <button onClick={onSubmit}>제출</button>
        </div>
    );
}

export default Register1;