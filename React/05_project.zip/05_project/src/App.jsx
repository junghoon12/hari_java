import { useState, useEffect } from "react";
import Viewer from "./components/Viewer";
import Controller from "./components/Controller";

function App() {
  
  const [count, setCount] = useState(0);
  const [input, setInput] = useState("");

  // useEffect(() => {
  //     console.log(`count : ${count} / input : ${input}`);
  // }, [count, input]);

  useEffect( () => {
    console.log("update");
  });

  const onClickButton = (value) => {
    setCount(count + value);
  }

  return (
    <div className="app">
      <h1>Simple Counter</h1>
      <setion>
         <input onChange= {(e) => {
            setInput(e.target.value);
         }} /> <br />
         <span>{input}</span>
      </setion>
      
      <section>
        <Viewer count={count} />
      </section>

      <section>
        <Controller onClickButton={onClickButton} />
      </section>
    </div>
  )
}

export default App
