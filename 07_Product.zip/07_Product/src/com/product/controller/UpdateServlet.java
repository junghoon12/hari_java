package com.product.controller;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.product.model.ProductDAO;
import com.product.model.ProductDTO;


@WebServlet("/update.do")
public class UpdateServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
   
    public UpdateServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	
	protected void service(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// get 방식으로 넘어온 제품번호에 해당하는 제품의
		// 정보를 DB에서 조회 후 수정 폼 페이지로 이동시키는
		// 비지니스 로직.
		
		int product_no = 
			Integer.parseInt(request.getParameter("num").trim());
		
		ProductDAO dao = ProductDAO.getInstance();
		
		ProductDTO cont = 
				dao.getContentProduct(product_no);
		
		request.setAttribute("modify", cont);
		
		RequestDispatcher rd = 
			request.getRequestDispatcher
						("view/product_modify.jsp");
		
		rd.forward(request, response);
		
	}

}
