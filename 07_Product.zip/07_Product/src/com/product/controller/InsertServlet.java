package com.product.controller;

import java.io.IOException;
import java.util.ArrayList;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.product.model.CategoryDTO;
import com.product.model.ProductDAO;


@WebServlet("/insert.do")
public class InsertServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    
    public InsertServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	
	protected void service(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// DB에서 CATEGORY 테이블의 전체 카테고리 코드를
		// 조회하여 카테고리 전체 리스트를 제품 등록 폼 페이지로
		// 이동시키는 비지니스 로직.
		
		ProductDAO dao = ProductDAO.getInstance();
		System.out.println("카테고리 목록 dao >>> " + dao);
		
		ArrayList<CategoryDTO> list = dao.getCategoryList();
		
		request.setAttribute("CList", list);
		
		RequestDispatcher rd =
				request.getRequestDispatcher
					("view/product_insert.jsp");
		
		rd.forward(request, response);
	}

}
