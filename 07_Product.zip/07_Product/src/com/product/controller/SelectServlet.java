package com.product.controller;

import java.io.IOException;
import java.util.ArrayList;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.product.model.ProductDAO;
import com.product.model.ProductDTO;


@WebServlet("/select.do")
public class SelectServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    
    public SelectServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	
	protected void service(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// 제품 전체 목록 요청에 대한 응답을 해 주어야 함.
		// DB에서 PRODUCTS 테이블의 전체 제품 목록을 조회하여
		// 제품 전체 목록을 view page로 이동시키는 비지니스 로직.
		
		// 1단계 : DB와 연결 작업 진행.
		// ProductDAO dao = new ProductDAO();
		ProductDAO dao = ProductDAO.getInstance();
		
		System.out.println("dao 객체 생성 후 >>> " + dao);
		
		ArrayList<ProductDTO> list = dao.getProductList();
		
		// 해당 제품 목록을 view page로 이동시켜야 한다.
		request.setAttribute("List", list);
		
		RequestDispatcher rd = 
			request.getRequestDispatcher("view/product_list.jsp");
		
		rd.forward(request, response);
	}

}
