package com.product.model;

import java.sql.*;
import java.util.ArrayList;


// DAO 객체를 싱글턴 방식으로 만들어서 사용을 해 보자.

public class ProductDAO {

	// DB와 연동하는 객체.
	Connection con = null;
	
	// DB에 SQL문을 전송하는 객체.
	PreparedStatement pstmt = null;
	
	// SQL문을 실행한 후에 결과 값을 가지고 있는 객체.
	ResultSet rs = null;
	
	// 쿼리문을 저장할 변수
	String sql = null;
	
	
	// ProductDAO 클래스를 싱글턴 방식으로 만들어 보자.
	// 1단계 : 싱글턴 방식을 객체를 만들기 위해서는 우선적으로
	//        기본생성자의 접근제어자를 public 이 아니라
	//        private 으로 바꾸어 주어야 한다.
	//        즉, 외부에서는 직접적으로 기본생성자를 호출하지
	//        못하게 하는 방식이다.
	
	// 2단계 : ProductDAO 클래스를 정적(static) 멤버로 
	//        선언을 해 주어야 한다.
	private static ProductDAO instance;
	
	private ProductDAO() {
		
		
	}  // 기본 생성자
	
	// 3단계 : 기본생성자 대신에 싱글턴 객체를 return 해 주는
	//        getInstance() 메서드를 만들어서 해당 
	//        getInstance() 메서드를 외부에서 접근할 수 있도록
	//        해 주면 됨.
	public static ProductDAO getInstance() {
		
		if(instance == null) {
			instance = new ProductDAO();
		}
		
		return instance;
	}  // getInstance() 메서드 end
	
	// DB를 연동하는 작업을 진행하는 메서드.
	public void openConn() {
		String driver = 
				"oracle.jdbc.driver.OracleDriver";
		String url =
				"jdbc:oracle:thin:@localhost:1521:xe";
		String user = "web";
		String password = "1234";
		
		try {
			// 1단계 : 오라클 드라이버를 메모리로 로딩 작업 진행.
			Class.forName(driver);
			
			// 2단계 : 오라클 데이터베이스와 연결 작업 진행.
			con = DriverManager.getConnection(url, user, password);
		
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	// products 테이블에서 전체 제품 리스트를 조회하는 메서드.
	public ArrayList<ProductDTO> getProductList() {
		
		ArrayList<ProductDTO> list = 
				new ArrayList<ProductDTO>();
		
		// 오라클 드라이버 로딩 및 연결 작업 진행
		openConn();
		
		try {
			// 3단계 : DB에 전송할 SQL문 작성.
			sql = "select * from products "
					+ "	order by pnum desc";
			
			// 4단계 : SQL문을 데이터베이스 전송 객체에 저장.
			pstmt = con.prepareStatement(sql);
			
			// 5단계 : SQL문을 데이터베이스에 전송 및 실행
			rs = pstmt.executeQuery();
			
			while(rs.next()) {
				ProductDTO dto = new ProductDTO();
				
				dto.setPnum(rs.getInt("pnum"));
				dto.setCategory_fk(rs.getString("category_fk"));
				dto.setProducts_name(rs.getString("products_name"));
				dto.setEp_code_fk(rs.getString("ep_code_fk"));
				dto.setInput_price(rs.getInt("input_price"));
				dto.setOutput_price(rs.getInt("output_price"));
				dto.setTrans_cost(rs.getInt("trans_cost"));
				dto.setMileage(rs.getInt("mileage"));
				dto.setCompany(rs.getString("company"));
				
				list.add(dto);
			}
			
			// 6단계 : DB에 연결되어 있는 자원 종료하기
			rs.close(); pstmt.close(); con.close();
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		return list;
	}  // getProductList() 메서드 end
	
	
	// category 테이블의 카테고리 전체 리스트를 조회하는 메서드.
	public ArrayList<CategoryDTO> getCategoryList() {
		
		ArrayList<CategoryDTO> list = 
				new ArrayList<CategoryDTO>();
		
		// 1 ~ 2단계 : 오라클 드라이버 로딩 및 연결 작업 진행
		openConn();
		
		
		try {
			// 3단계 : DB에 전송할 SQL문 작성.
			sql = "select * from category "
					+ " order by category_code";
			
			// 4단계 : SQL문을 데이터베이스 전송 객체에 저장.
			pstmt = con.prepareStatement(sql);
			
			// 5단계 : SQL문을 데이터베이스에 전송 및 실행
			rs = pstmt.executeQuery();
			
			while(rs.next()) {
				CategoryDTO dto = new CategoryDTO();
				
				dto.setCnum(rs.getInt("cnum"));
				dto.setCategory_code(rs.getString("category_code"));
				dto.setCategory_name(rs.getString("category_name"));
				
				list.add(dto);
			}
			
			// 6단계 : DB에 연결되어 있는 자원 종료하기
			rs.close(); pstmt.close(); con.close();
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		return list;
	}  // getCategoryList() 메서드 end
	
	
	// products 테이블에 제품을 등록하는 메서드.
	public int insertProduct(ProductDTO dto) {
		
		int result = 0, count = 0;
		
		openConn();
		
		
		try {
			// 3단계 : DB에 전송할 SQL문 작성.
			sql = "select count(*) from products";
			
			// 4단계 : SQL문을 데이터베이스 전송 객체에 저장.
			pstmt = con.prepareStatement(sql);
			
			// 5단계 : SQL문을 데이터베이스에 전송 및 실행.
			rs = pstmt.executeQuery();
			
			if(rs.next()) {
				count = rs.getInt(1) + 1;
			}
			
			// 3단계 : DB에 전송할 SQL문 작성.
			sql = "insert into products "
					+ "	values(?, ?, ?, ?, ?, ?, ?, ?, ?)";
			
			// 4단계 : SQL문을 데이터베이스 전송 객체에 저장.
			pstmt = con.prepareStatement(sql);
			
			// 4-1 : ?(플레이스 홀더)에 데이터 배정.
			pstmt.setInt(1, count);
			pstmt.setString(2, dto.getCategory_fk());
			pstmt.setString(3, dto.getProducts_name());
			pstmt.setString(4, dto.getEp_code_fk());
			pstmt.setInt(5, dto.getInput_price());
			pstmt.setInt(6, dto.getOutput_price());
			pstmt.setInt(7, dto.getTrans_cost());
			pstmt.setInt(8, dto.getMileage());
			pstmt.setString(9, dto.getCompany());
			
			// 5단계 : SQL문을 데이터베이스에 전송 및 실행.
			result = pstmt.executeUpdate();
			
			// 6단계 : DB에 연결되어 있는 자원 종료하기
			rs.close(); pstmt.close(); con.close();
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		return result;
	}  // insertProduct() 메서드 end
	
	
	// 제품번호에 해당하는 제품을 조회하는 메서드.
	public ProductDTO getContentProduct(int no) {
		
		ProductDTO dto = null;
		
		openConn();
		
		
		try {
			// 3단계 : DB에 전송할 SQL문 작성.
			sql = "select * from products "
					+ " where pnum = ?";
			
			// 4단계 : SQL문을 데이터베이스 전송 객체에 저장.
			pstmt = con.prepareStatement(sql);
			
			// 4-1 : ?(플레이스 홀더)에 데이터 배정.
			pstmt.setInt(1, no);
			
			// 5단계 : SQL문을 데이터베이스에 전송 및 실행.
			rs = pstmt.executeQuery();
			
			if(rs.next()) {
				dto = new ProductDTO();
				
				dto.setPnum(rs.getInt("pnum"));
				dto.setCategory_fk(rs.getString("category_fk"));
				dto.setProducts_name(rs.getString("products_name"));
				dto.setEp_code_fk(rs.getString("ep_code_fk"));
				dto.setInput_price(rs.getInt("input_price"));
				dto.setOutput_price(rs.getInt("output_price"));
				dto.setTrans_cost(rs.getInt("trans_cost"));
				dto.setMileage(rs.getInt("mileage"));
				dto.setCompany(rs.getString("company"));
			
			}
			
			// 6단계 : DB에 연결되어 있는 자원 종료하기
			rs.close(); pstmt.close(); con.close();
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		return dto;
	}  // getContentProduct() 메서드 end
	
	
	// products 테이블의 제품번호에 해당하는 제품의
	// 정보를 수정하는 메서드.
	public int updateProduct(ProductDTO dto) {
		
		int result = 0;
		
		openConn();
		
		try {
			sql = "update products set input_price = ?, "
					+ "output_price = ?, trans_cost = ?, "
					+ " mileage = ? where pnum = ?";
			
			pstmt = con.prepareStatement(sql);
			
			pstmt.setInt(1, dto.getInput_price());
			pstmt.setInt(2, dto.getOutput_price());
			pstmt.setInt(3, dto.getTrans_cost());
			pstmt.setInt(4, dto.getMileage());
			pstmt.setInt(5, dto.getPnum());
			
			result = pstmt.executeUpdate();
			
			pstmt.close(); con.close();
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		return result;
	}  // updateProduct() 메서드 end
	
	
	// get 방식으로 받은 제품번호에 해당하는 제품을
	// DB에서 삭제하는 메서드.
	public int deleteProduct(int no) {
		
		int result = 0;
		
		openConn();
		
		try {
			sql = "delete from products "
					+ " where pnum = ?";
			
			pstmt = con.prepareStatement(sql);
			
			pstmt.setInt(1, no);
			
			result = pstmt.executeUpdate();
			
			pstmt.close(); con.close();
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		return result;
	}  // deleteProduct() 메서드 end
	
	
	// 제품 목록 중에 중간에 있는 제품 삭제 시
	// 제품번호를 수정하는 메서드.
	public void updateSequence(int no) {
		
		openConn();
		
		
		try {
			sql = "update products set "
					+ " pnum = pnum - 1 "
					+ " where pnum > ?";
			
			pstmt = con.prepareStatement(sql);
			
			pstmt.setInt(1, no);
			
			pstmt.executeUpdate();
			
			pstmt.close(); con.close();
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}  // updateSequence() 메서드 end
	
	
	
	
	
	
	
}
