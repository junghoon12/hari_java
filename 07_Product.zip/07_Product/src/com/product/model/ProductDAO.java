package com.product.model;

import java.sql.*;
import java.util.ArrayList;


// DAO 객체를 싱글턴 방식으로 만들어서 사용을 해 보자.

public class ProductDAO {

	// DB와 연동하는 객체.
	Connection con = null;
	
	// DB에 SQL문을 전송하는 객체.
	PreparedStatement pstmt = null;
	
	// SQL문을 실행한 후에 결과 값을 가지고 있는 객체.
	ResultSet rs = null;
	
	// 쿼리문을 저장할 변수
	String sql = null;
	
	
	// ProductDAO 클래스를 싱글턴 방식으로 만들어 보자.
	// 1단계 : 싱글턴 방식을 객체를 만들기 위해서는 우선적으로
	//        기본생성자의 접근제어자를 public 이 아니라
	//        private 으로 바꾸어 주어야 한다.
	//        즉, 외부에서는 직접적으로 기본생성자를 호출하지
	//        못하게 하는 방식이다.
	
	// 2단계 : ProductDAO 클래스를 정적(static) 멤버로 
	//        선언을 해 주어야 한다.
	private static ProductDAO instance;
	
	private ProductDAO() {
		
		
	}  // 기본 생성자
	
	// 3단계 : 기본생성자 대신에 싱글턴 객체를 return 해 주는
	//        getInstance() 메서드를 만들어서 해당 
	//        getInstance() 메서드를 외부에서 접근할 수 있도록
	//        해 주면 됨.
	public static ProductDAO getInstance() {
		
		if(instance == null) {
			instance = new ProductDAO();
		}
		
		return instance;
	}  // getInstance() 메서드 end
	
	// DB를 연동하는 작업을 진행하는 메서드.
	public void openConn() {
		String driver = 
				"oracle.jdbc.driver.OracleDriver";
		String url =
				"jdbc:oracle:thin:@localhost:1521:xe";
		String user = "web";
		String password = "1234";
		
		try {
			// 1단계 : 오라클 드라이버를 메모리로 로딩 작업 진행.
			Class.forName(driver);
			
			// 2단계 : 오라클 데이터베이스와 연결 작업 진행.
			con = DriverManager.getConnection(url, user, password);
		
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	// products 테이블에서 전체 제품 리스트를 조회하는 메서드.
	public ArrayList<ProductDTO> getProductList() {
		
		ArrayList<ProductDTO> list = 
				new ArrayList<ProductDTO>();
		
		// 오라클 드라이버 로딩 및 연결 작업 진행
		openConn();
		
		try {
			// 3단계 : DB에 전송할 SQL문 작성.
			sql = "select * from products "
					+ "	order by pnum desc";
			
			// 4단계 : SQL문을 데이터베이스 전송 객체에 저장.
			pstmt = con.prepareStatement(sql);
			
			// 5단계 : SQL문을 데이터베이스에 전송 및 실행
			rs = pstmt.executeQuery();
			
			while(rs.next()) {
				ProductDTO dto = new ProductDTO();
				
				dto.setPnum(rs.getInt("pnum"));
				dto.setCategory_fk(rs.getString("category_fk"));
				dto.setProducts_name(rs.getString("products_name"));
				dto.setEp_code_fk(rs.getString("ep_code_fk"));
				dto.setInput_price(rs.getInt("input_price"));
				dto.setOutput_price(rs.getInt("output_price"));
				dto.setTrans_cost(rs.getInt("trans_cost"));
				dto.setMileage(rs.getInt("mileage"));
				dto.setCompany(rs.getString("company"));
				
				list.add(dto);
			}
			
			// 6단계 : DB에 연결되어 있는 자원 종료하기
			rs.close(); pstmt.close(); con.close();
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		return list;
	}  // getProductList() 메서드 end
}
