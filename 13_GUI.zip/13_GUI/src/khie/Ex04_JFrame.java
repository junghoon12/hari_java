package khie;

import javax.swing.JFrame;

public class Ex04_JFrame {

	public static void main(String[] args) {
		
		JFrame jFrame = new JFrame("네번째 예제");
		
		jFrame.setBounds(100, 100, 300, 300);
		
		jFrame.setVisible(true);

	}

}
