package packages;

import java.util.Scanner;

import model.Member;

/*
 * [문제] 회원 수를 키보드로 입력을 받고, 회원 수만큼
 *       회원의 정보를 객체 배열에 저장을 하여 화면에
 *       회원의 정보를 보여주세요.
 *       예) Member[] members = 
 *       			new Member[sc.nextInt()];
 */

public class Member_02 {

	public static void main(String[] args) {
		
		// 1. 키보드로 회원수를 입력을 받아서 객체배열의
		//    크기로 잡아 주자.
		Scanner sc = new Scanner(System.in);
		
		System.out.print("회원 수 입력 : ");
		
		Member[] members = 
						new Member[sc.nextInt()];
		
		sc.nextLine();
		
		// 2. 반복문을 이용하여 회원 수만큼 회원 객체
		//    생성 후에 회원의 정보를 키보드로 입력을 받자.
		for(int i=0; i<members.length; i++) {
			
			System.out.println
				((i+1) +"번째 회원의 정보를 입력하세요.....");
			
			// Member member = new Member();
			members[i] = new Member();
			
			System.out.print("회원의 아이디 입력 : ");
			members[i].setId(sc.nextLine());
			
			System.out.print("회원의 비밀번호 입력 : ");
			members[i].setPwd(sc.nextLine());
			
			System.out.print("회원의 이름 입력 : ");
			members[i].setName(sc.nextLine());
			
			System.out.print("회원의 나이 입력 : ");
			members[i].setAge(sc.nextInt());
			
			sc.nextLine();
			
			System.out.print("회원의 연락처 입력 : ");
			members[i].setPhone(sc.nextLine());
			
			System.out.print("회원의 주소 입력 : ");
			members[i].setAddress(sc.nextLine());

		}
		
		// 3. 반복문을 이용하여 객체 배열에 저장된 각각의
		//    회원의 정보를 화면에 출력해 보자.
		System.out.println
		  ("아이디\t비밀번호\t이  름\t나  이\t연락처\t주  소");
		
		for(int i=0; i<members.length; i++) {
			
			System.out.println
			  (members[i].getId()+"\t"+
			   members[i].getPwd()+"\t"+
			   members[i].getName()+"\t"+
			   members[i].getAge()+"\t"+
			   members[i].getPhone()+"\t"+
			   members[i].getAddress());
			
			System.out.println("::::::::::::::::::::::::::::::");
		}

		sc.close();
	}

}
