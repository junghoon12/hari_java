package inheritance;

public class Point_04 {

	public static void main(String[] args) {
		
		Point3D point = new Point3D(2, 3, 5);
		
		point.output();

	}

}
