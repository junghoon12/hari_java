package inheritance;

public class Car2_02 {

	public static void main(String[] args) {
		
		Avante avante = new Avante();
		
		avante.cc = 1600;
		
		avante.door = 4;
		
		avante.output();

	}

}
