package inheritance;

public class Person {

	// 멤버변수
	String name;      // 이름
	int age;          // 나이
	String job;       // 직업
	
}
