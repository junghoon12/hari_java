package overriding;

public class Shape {

	void draw() {
		System.out.println("그리다~~~");
	}
	
}
