package polymorphism;

public class Animal_01 {

	public static void main(String[] args) {
		
		// 다형성으로 객체 생성.
		Animal dog = new Dog();
		
		dog.sound();
		
		// dog.output();

	}

}
