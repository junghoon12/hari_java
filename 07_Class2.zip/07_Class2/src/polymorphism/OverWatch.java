package polymorphism;

public interface OverWatch {

	// 추상메서드
	void name();
	void leftClick();
	void rightClick();
	void shiftButton();
	void eButton();
	void qButton();
	
}
