package exam1;

public class Temporary extends Employee {

	private int time;     // 작업 시간
	private int pay;      // 시간당 급여
	
	public Temporary() { }  // 기본 생성자
	
	public Temporary(String name,
						int time, int pay) {
		super(name);
		this.time = time;
		this.pay = pay;
	}  // 인자 생성자
	
	
	public int getTime() {
		return time;
	}

	public int getPay() {
		return pay;
	}

	@Override
	int getPays() {
		
		return time * pay;
	}

	
}
