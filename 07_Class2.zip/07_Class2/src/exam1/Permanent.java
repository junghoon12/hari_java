package exam1;

public class Permanent extends Employee {

	// 멤버변수
	private int salary;
	private int bonus;
	
	public Permanent() {  }  // 기본 생성자
	
	public Permanent(String name,
					int salary, int bonus) {
		super(name);
		this.salary = salary;
		this.bonus = bonus;
	}  // 인자 생성자
	
	
	public int getSalary() {
		return salary;
	}

	public int getBonus() {
		return bonus;
	}

	
	// 부모클래스(추상클래스)의 추상메서드를 재정의.
	@Override
	int getPays() {
		return salary + bonus;
	}

}
