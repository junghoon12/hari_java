package exam1;

public class Rectangle implements Shape {

	int width;      // 가로 변수
	int height;     // 세로 변수
	
	public Rectangle() { }  // 기본 생성자
	
	public Rectangle(int width, int height) {
		this.width = width;
		this.height = height;
	}  // 인자 생성자
	
	
	@Override
	public double findArea() {
		
		return width * height;
		
	}
	
	

}
