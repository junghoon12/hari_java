package exam1;

public interface Shape {

	double findArea();
	
}
