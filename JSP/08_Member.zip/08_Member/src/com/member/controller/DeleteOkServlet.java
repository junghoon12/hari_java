package com.member.controller;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.member.model.MemberDAO;


@WebServlet("/delete_ok.go")
public class DeleteOkServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
   
    public DeleteOkServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	
	protected void service(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// 삭제 폼 페이지에서 넘어온 데이터들을 가지고
		// DB의 member10 테이블에서 회원을 삭제하는 비지니스 로직.
		response.setContentType("text/html; charset=UTF-8");
		
		
		String member_pwd = request.getParameter("mem_pwd").trim();
		
		// type="hidden" 으로 넘어온 데이터들도 받아주어야 한다.
		int member_no = 
				Integer.parseInt(request.getParameter("mem_num").trim());
		
		String db_pwd = request.getParameter("db_pwd").trim();
		
		MemberDAO dao = MemberDAO.getInstance();
		
		PrintWriter out = response.getWriter();
		
		if(db_pwd.equals(member_pwd)) {
			
			int result = dao.deleteMember(member_no);
			
			if(result > 0) {
				dao.updateSequence(member_no);
				out.println("<script>");
				out.println("alert('회원 삭제 성공!!!')");
				out.println("location.href='select.go'");
				out.println("</script>");
			}else {
				out.println("<script>");
				out.println("alert('회원 삭제 실패.~~~')");
				out.println("history.back()");
				out.println("</script>");
			}
			
		}else {
			// 비밀번호가 틀린 경우
			out.println("<script>");
			out.println("alert('비밀번호가 틀립니다. 확인해 주세요.~~~')");
			out.println("history.back()");
			out.println("</script>");
		}
	}

}










