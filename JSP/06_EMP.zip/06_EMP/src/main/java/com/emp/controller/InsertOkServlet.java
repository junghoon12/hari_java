package com.emp.controller;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.io.PrintWriter;

import com.emp.model.EmpDAO;
import com.emp.model.EmpDTO;


@WebServlet("/insert_ok.go")
public class InsertOkServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    
    public InsertOkServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	
	protected void service(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// 사원 등록 폼 페이지에서 넘어온 데이터들을 받아서
		// EMP 테이블에 저장시키는 비지니스 로직.
		
		// 한글 처리 작업.
		request.setCharacterEncoding("UTF-8");
		response.setContentType("text/html; charset=UTF-8");
		
		// 1단계 : 사원등록 폼 페이지에서 넘어온 데이터들을 받아주어야 한다.
		String empno = request.getParameter("num").trim();
		
		String ename = request.getParameter("name").trim();
		
		String job = request.getParameter("job").trim();
		
		String mgr = request.getParameter("mgr").trim();
		
		String sal = request.getParameter("sal").trim();
		
		String comm = request.getParameter("comm").trim();
		
		String deptno = request.getParameter("deptno").trim();
		
		
		// 2단계 : 받은 데이터들을 DTO 객체의 멤버변수로 할당해 주자.
		EmpDTO dto = new EmpDTO();
		
		dto.setEmpno(Integer.parseInt(empno));
		dto.setEname(ename);
		dto.setJob(job);
		dto.setMgr(Integer.parseInt(mgr));
		dto.setSal(Integer.parseInt(sal));
		dto.setComm(Integer.parseInt(comm));
		dto.setDeptno(Integer.parseInt(deptno));
		
		EmpDAO dao = EmpDAO.getInstance();
		
		System.out.println("insert_ok dao >>> " + dao);
		
		int chk = dao.insertEmp(dto);
		
		PrintWriter out = response.getWriter();
		
		if(chk > 0) {
			out.println("<script>");
			out.println("alert('사원 등록 성공!!!')");
			out.println("location.href='select.go'");
			out.println("</script>");
		}else {
			out.println("<script>");
			out.println("alert('사원 등록 실패~~~')");
			out.println("history.back()");
			out.println("</script>");
		}
		
	}

}
