package com.emp.controller;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.io.PrintWriter;

import com.emp.model.EmpDAO;


@WebServlet("/delete.go")
public class DeleteServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
 
    public DeleteServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	
	protected void service(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// 사원 삭제 버튼 클릭 시 get 방식으로 넘어온 사원번호를 받아서
		// EMP 테이블에서 사원번호에 해당하는 사원을 삭제하는 비지니스 로직.
		
		response.setContentType("text/html; charset=UTF-8");
		
		int emp_no = 
			Integer.parseInt(request.getParameter("no").trim());
		
		EmpDAO dao = EmpDAO.getInstance();
		
		int chk = dao.deleteEmp(emp_no);
		
		PrintWriter out = response.getWriter();
		
		if(chk > 0) {
			out.println("<script>");
			out.println("alert('사원 삭제 성공!!!')");
			out.println("location.href='select.go'");
			out.println("</script>");
		}else {
			out.println("<script>");
			out.println("alert('사원 삭제 실패~~~')");
			out.println("history.go(-1)");
			out.println("</script>");
		}
	}

}
