package com.emp.model;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class EmpDAO {

	// 멤버변수
	// 1. 데이터베이스와 연동하는 객체.
	Connection con = null;
	
	// 2. 데이터베이스에 SQL문을 전송하는 객체.
	PreparedStatement pstmt = null;
	
	// 3. SQL문을 실행한 후 결과값을 가지고 있는 객체.
	ResultSet rs = null;
	
	// 4. SQL 문을 저장할 문자열 객체.
	String sql = null;
	
	
	// EmpDAO 클래스를 싱글턴 방식으로 만들어 보자.
	// 1단계 : 싱글턴 방식으로 객체를 만들기 위해서는 우선적으로
	//        기본 생성자의 접근지정자를 private 으로 선언해야 함.
	private EmpDAO() {  }  // 기본 생성자
	
	// 2단계 : EmpDAO 객체를 정적 멤버로 선언해야 함. - static 으로 선언해야 함.
	private static EmpDAO instance = null;
	
	// 3단계 : 기본 생성자 대신에 싱글턴 객체를 return 해 주는
	//        getInstance() 라는 메서드를 만들어서 외부에서는
	//        해당 메서드로 접근할 수 있게 해주면 됨.
	public static EmpDAO getInstance() {
		
		if(instance == null) {
			instance = new EmpDAO();
		}
		
		return instance;
	}
	
	
	// 데이터베이스와 연동하는 작업을 하는 메서드.
	public void openConn() {
		
		String driver = "oracle.jdbc.driver.OracleDriver";
		
		String url = "jdbc:oracle:thin:@localhost:1521:xe";
		
		String user = "kdt";
		
		String password = "1234";
		
		
		try {
			// 1단계 : 오라클 드라이버를 메모리로 로딩.
			Class.forName(driver);
			
			// 2단계 : 오라클 데이터베이스와 연결 시도.
			con = DriverManager.getConnection(url, user, password);
			
			if(con != null) {
				
				System.out.println("데이터베이스 연결 성공!!!");
			}
			
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}  // openConn() 메서드 end
	
	
	// 자원을 종료시키는 메서드.
	public void closeConn(ResultSet rs,
			PreparedStatement pstmt, Connection con) {
		
		try {
			if(rs != null) rs.close();
			if(pstmt != null) pstmt.close();
			if(con != null) con.close();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}
	
	
	// 자원을 종료시키는 메서드.
	public void closeConn(
			PreparedStatement pstmt, Connection con) {
		
		try {
			if(pstmt != null) pstmt.close();
			if(con != null) con.close();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}
	
	
	// EMP 테이블에서 전체 사원 리스트를 조회하는 메서드.
	public List<EmpDTO> getEmpList() {
		
		List<EmpDTO> list = new ArrayList<EmpDTO>();
		
		
		try {
			// 1단계 + 2단계 : 오라클 드라이버 로딩 및 데이터베이스와 연동 작업 진행.
			openConn();
			
			// 3단계 : 데이터베이스에 전송할 SQL문 작성.
			sql = "select * from emp order by hiredate desc";
			
			// 4단계 : SQL 문을 데이터베이스 전송 객체에 저장.
			pstmt = con.prepareStatement(sql);
			
			// 5단계 : 데이터베이스에 SQL문 전송 및 실행.
			rs = pstmt.executeQuery();
			
			// 6단계 : SQL문 실행 결과를 반복하여
			//        DTO 객체에 저장 및 list에 추가.
			while(rs.next()) {
				
				EmpDTO dto = new EmpDTO();
				
				dto.setEmpno(rs.getInt("empno"));
				dto.setEname(rs.getString("ename"));
				dto.setJob(rs.getString("job"));
				dto.setMgr(rs.getInt("mgr"));
				dto.setHiredate(rs.getString("hiredate"));
				dto.setSal(rs.getInt("sal"));
				dto.setComm(rs.getInt("comm"));
				dto.setDeptno(rs.getInt("deptno"));
				
				list.add(dto);
			}
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} finally {
			
			closeConn(rs, pstmt, con);
		}
		
		return list;
	}  // getEmpList() 메서드 end
	
	
	// EMP 테이블에서 담당업무를 조회하는 메서드.
	public List<String> getJobList() {
		
		List<String> jobList = new ArrayList<String>();
		
		
		try {
			// 1 + 2단계 : 오라클 드라이버 로딩 및 DB와 연동 작업 진행.
			openConn();
			
			// 3단계 : 데이터베이스에 전송할 SQL문 작성.
			sql = "select distinct(job) from emp order by job";
			
			// 4단계 : SQL문을 데이터베이스 전송 객체에 저장.
			pstmt = con.prepareStatement(sql);
			
			// 5단계 : 데이터베이스에 SQL문 전송 및 실행.
			rs = pstmt.executeQuery();
			
			// 6단계 : SQL문 실행 결과를 반복하여 
			//        String에 저장 및 list에 추가.
			while(rs.next()) {
				
				String job = rs.getString("job");
				
				jobList.add(job);
				
			}
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} finally {
			
			closeConn(rs, pstmt, con);
		}
		
		return jobList;
	}  // getJobList() 메서드 end
	
	// EMP 테이블에서 관리자 목록을 조회하는 메서드.
	public List<Integer> getMgrList() {
		
		List<Integer> mgrList = new ArrayList<Integer>();
		
		try {
			// 1 + 2단계 : 오라클 드라이버 로딩 및 DB와 연동 작업 진행.
			openConn();
			
			// 3단계 : 데이터베이스에 전송할 SQL문 작성.
			sql = "select distinct(mgr) from emp order by mgr";
			
			// 4단계 : SQL문을 데이터베이스 전송 객체에 저장.
			pstmt = con.prepareStatement(sql);
			
			// 5단계 : 데이터베이스에 SQL문 전송 및 실행.
			rs = pstmt.executeQuery();
			
			// 6단계 : SQL문 실행 결과를 반복하여 
			//        int에 저장 및 list에 추가.
			while(rs.next()) {
				
				int mgr = rs.getInt("mgr");
				
				mgrList.add(mgr);
				
			}
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} finally {
			
			closeConn(rs, pstmt, con);
		}
		
		return mgrList;
	}
	
	
	// DEPT 테이블에서 전체 부서 목록을 조회하는 메서드.
	public List<DeptDTO> getDeptList() {
		
		List<DeptDTO> deptList = new ArrayList<DeptDTO>();
		
		
		try {
			// 1 + 2단계 : 오라클 드라이버 로딩 및 DB와 연동 작업 진행.
			openConn();
			
			// 3단계 : 데이터베이스에 전송할 SQL문 작성.
			sql = "select * from dept order by deptno";
			
			// 4단계 : SQL문을 데이터베이스 전송 객체에 저장.
			pstmt = con.prepareStatement(sql);
			
			// 5단계 : 데이터베이스에 SQL문 전송 및 실행.
			rs = pstmt.executeQuery();
			
			// 6단계 : SQL문 실행 결과를 반복하여
			//        DTO 객체에 저장 및 list에 추가.
			while(rs.next()) {
				
				DeptDTO dto = new DeptDTO();
				
				dto.setDeptno(rs.getInt("deptno"));
				dto.setDname(rs.getString("dname"));
				dto.setLoc(rs.getString("loc"));
				
				deptList.add(dto);
				
			}
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} finally {
			
			closeConn(rs, pstmt, con);
		}
		
		return deptList;
	}  // getDeptList() 메서드 end
	
	
	// EMP 테이블에 사원 등록을 하는 메서드.
	public int insertEmp(EmpDTO dto) {
		
		int result = 0;
		
		
		try {
			openConn();
			
			sql = "insert into emp "
					+ " values(?, ?, ?, ?, sysdate, ?, ?, ?)";
			
			pstmt = con.prepareStatement(sql);
			
			pstmt.setInt(1, dto.getEmpno());
			pstmt.setString(2, dto.getEname());
			pstmt.setString(3, dto.getJob());
			pstmt.setInt(4, dto.getMgr());
			pstmt.setInt(5, dto.getSal());
			pstmt.setInt(6, dto.getComm());
			pstmt.setInt(7, dto.getDeptno());
			
			result = pstmt.executeUpdate();
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} finally {
			
			closeConn(pstmt, con);
		}
		
		return result;
	}  // insertEmp() 메서드 end
	
	
	// EMP 테이블에서 사원번호에 해당하는 사원의 정보를 조회하는 메서드.
	public EmpDTO contentEmp(int no) {
		
		EmpDTO dto = null;
		
		
		try {
			openConn();
			
			sql = "select * from emp where empno = ?";
			
			pstmt = con.prepareStatement(sql);
			
			pstmt.setInt(1, no);
			
			rs = pstmt.executeQuery();
			
			if(rs.next()) {
				
				dto = new EmpDTO();
				
				dto.setEmpno(rs.getInt("empno"));
				dto.setEname(rs.getString("ename"));
				dto.setJob(rs.getString("job"));
				dto.setMgr(rs.getInt("mgr"));
				dto.setHiredate(rs.getString("hiredate"));
				dto.setSal(rs.getInt("sal"));
				dto.setComm(rs.getInt("comm"));
				dto.setDeptno(rs.getInt("deptno"));
				
			}
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} finally {
			
			closeConn(rs, pstmt, con);
		}
		
		return dto;
	}  // contentEmp() 메서드 end
	
	
	// 사원번호에 해당하는 사원의 정보를 수정하는 메서드.
	public int modifyEmp(EmpDTO dto) {
		
		int result = 0;
		
		
		try {
			openConn();
			
			sql = "update emp set job = ?, mgr = ?, "
					+ " sal = ?, comm = ?, deptno = ?  "
					+ " where empno = ?";
			
			pstmt = con.prepareStatement(sql);
			
			pstmt.setString(1, dto.getJob());
			pstmt.setInt(2, dto.getMgr());
			pstmt.setInt(3, dto.getSal());
			pstmt.setInt(4, dto.getComm());
			pstmt.setInt(5, dto.getDeptno());
			pstmt.setInt(6, dto.getEmpno());
			
			result = pstmt.executeUpdate();
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} finally {
			
			closeConn(pstmt, con);
		}
		
		return result;
	}  // modifyEmp() 메서드 end
	
	
	// EMP 테이블에서 사원번호에 해당하는 사원을 삭제하는 메서드.
	public int deleteEmp(int no) {
		
		int result = 0;
		
		
		try {
			openConn();
			
			sql = "delete from emp where empno = ?";
			
			pstmt = con.prepareStatement(sql);
			
			pstmt.setInt(1, no);
			
			result = pstmt.executeUpdate();
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} finally {
			
			closeConn(pstmt, con);
		}
		
		return result;
	}  // deleteEmp() 메서드 end

	
}
