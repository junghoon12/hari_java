package com.himedia.model;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;


/*
 * DAO(Data Access Object : 데이터 접근 객체)
 * - DB에 접속(연동)하는 객체.
 * - DAO 클래스는 데이터베이스에 접속해서 데이터를 추가,
 *   수정, 삭제, 조회 등의 작업을 수행하는 클래스.
 * - 일반적으로 JSP 또는 Servlet에서 위의 작업들을
 *   진행할 수 있지만, 유지보수, 코드의 모듈화 등을 위해서
 *   DAO 클래스를 따로 만들어서 사용하는 것이 좋음.
 */


/*
* JDBC(Java DataBase Connectivity)
* - JDBC는 데이터베이스를 다루기 위한 자바 
*   API(Application Programming Interface)임
* - 자바를 기반으로 하는 프로그램을 작성할 때 프로그래머에게
*   데이터베이스를 쉽게 다룰 수 있도록 해 주는 것임.
* - Driver를 통한 자바와 데이터베이스에 연결 및 작업을
*   하기 위한 것이 주된 목적임.
* - Driver를 통한 JVM과 DBMS의 연결.
*   ==> Driver는 JVM과 DBMS를 연결하는 연결 다리 역할을 함.
* - DBMS의 종류는 다양함. DBMS를 만든 회사들은 내부적으로
*   작동되는 방식이 서로 다름.
*   따라서 이렇게 많은 DBMS에 연동하기 위해서 프로그래머는
*   각각의 DBMS 내부 작동방식을 이해해서 그 방식에 맞게
*   질의문을 던져야 원하는 데이터를 받아올 수 있음.
* - 이러한 방법은 DBMS가 달라질 경우 새롭게 프로그램을 
*   작성해야 함. 또한 특정 DBMS의 내부적인 작동방식을
*   이해해서 그 내부 구조에 맞게 프로그램을 작성하려면
*   너무나 많은 시간과 노력이 필요함.
* - 이런 방법보다 DBMS에 접근하기 위해서 특정한 도구를 만들어 놓고
*   이 도구만 적절히 사용하면 서로 다른 회사에서 나온 DBMS 중애
*   어떤 것이라도 사용할 수 있게 하는 것이 훨씬 빠르고 간편한 일이 됨.
*   이런 경우 프로그래머는 그 도구만 이용하면 각각의 DBMS의 내부까지
*   신경을 쓰지 않아도 되기 때문에 손 쉽게 프로그래밍을 할 수 있게 됨. 
* - JDBC는 자바 표준 인터페이스임. - JDBC API를 사용함.
* - 내부적으로 이 JDBC는 자바 파일들로 작성이 되어 있음. 
*   JDBC 인터페이스와 JDBC 드라이버로 구성이 되어 있음.
* - JDBC는 자바와 데이터베이스 간의 통신 역할을 해 줌.
  
* JDBC 주요 인터페이스
* - java.sql.Driver
*   ==> 데이터베이스에서 사용되는 드라이버 인터페이스.
* - java.sql.Connection
*   ==> 데이터베이스 연결 정보를 가지고 있는 인터페이스.
* - java.sql.PreparedStatement
*   ==> 데이터베이스에 SQL문을 전송하는 인터페이스.
* - java.sql.ResultSet
*   ==> 데이터베이스의 실행 결과를 가지고 있는 인터페이스.
*   
* 1) 드라이버 로딩
* - 라이브러리를 바탕으로 오라클 드라이버를 메모리로
*   업로드 시켜 주어야 함.
* - 드라이버를 메모리로 업로드 시켜 주는 방법은
*   Class.forName(드라이버 파일) 메서드를 이용함.
* - 해당 메서드를 이용하면 자동으로 객체가 생성이 되고,
*   DriverManager 클래스에 등록이 됨.
*   일반적으로 드라이버 클래스들은 로드될 때 자신의
*   인스턴스를 생성하고, 자동적으로 DriverManager 
*   클래스의 메서드를 호출하여 그 인스턴스를 등록을 함.
* - 이 메서드는 Class 라는 클래스에 포함이 되어 있으며, 
*   해당 파일 경로에 위치한 파일을 동적으로 프로그램이
*   실행될 때 메모리 상에 업로드 시키는 역할을 함.
    
* 2) 커넥션 연결
* - 설치된 드라이버를 메모리 상에 업로드 시키면 이제 DB를
*   지금 사용하는 프로그램과 연결시켜 주어야 함. 이러한
*   연결을 시켜 주는 것을 커넥션(connection) 이라고 함.
* - DriverManager 클래스는 데이터 원본에 JDBC 드라이버를
*   통하여 커넥션을 만드는 역할을 함.
* - DriverManager 클래스의 getConnection() 메서드를
*   이용하여 자신이 사용하는 오라클 정보를 인자로 전달하여
*   연결을 수행하게 됨.
* - 오라클에 접속하기 위해서는 오라클의 정보(오라클 서버의 IP,
*   리스너 포트, 오라클 계정, 오라클 비밀번호)를 알아야 함.
    

* 실제 연결 순서
* 1. 오라클 드라이버 로딩.
* 2. 데이터베이스 커넥션 구함.
* 3. 쿼리 실행을 위한 PreparedStatement 객체 생성.
* 4. 쿼리 실행.
* 5. 쿼리 실행 결과를 사용.
* 6. 쿼리 종료.
* 7. PrepareStatement 사용 종료
* 8. 데이터베이스 커넥션 사용 종료.  
 */


public class DeptDAO {

	// DB와 관련된 멤버변수 선언.
	// 1. DB와 연동하는 객체.
	Connection con = null;
	
	// 2. DB에 SQL문을 전송하는 객체.
	PreparedStatement pstmt = null;
	
	// 3. SQL문을 실행한 후에 결과값을 가지고 있는 객체.
	ResultSet rs = null;
	
	// 4. SQL문을 저장할 문자열 객체.
	String sql = null;
	
	
	public DeptDAO() {   // 기본 생성자
		
		String driver = "oracle.jdbc.driver.OracleDriver";
		
		String url = "jdbc:oracle:thin:@localhost:1521:xe";
		
		String user = "kdt";
		
		String password = "1234";
		
		
		
		try {
			// 1단계 : 오라클 드라이버를 메모리로 로딩.
			Class.forName(driver);
			
			// 2단계 : 오라클 데이터베이스와 연결 시도.
			con = DriverManager.getConnection(url, user, password);
			
			if(con != null) {
				
				System.out.println("데이터베이스 연결 성공!!!");
			}
			
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
	} 
	
	
	// DEPT 테이블에서 부서 전체 목록을 조회하는 메서드.
	public List<DeptDTO> selectList() {
		
		List<DeptDTO> list = new ArrayList<DeptDTO>();
		
		
		try {
			// 3단계 : 데이터베이스에 SQL문을 전송하기 위한 쿼리문 작성.
			sql = "select * from dept order by deptno";
			
			// 4단계 : SQL문을 데이터베이스 전송 객체에 저장.
			pstmt = con.prepareStatement(sql);
			
			// 5단계 : SQL문을 데이터베이스에 전송 및 실행.
			rs = pstmt.executeQuery();
			
			// 6단계 : 하나씩 데이터를 가져와서 DTO에 저장
			while(rs.next()) {
				
				DeptDTO dto = new DeptDTO();
				
				dto.setDeptno(rs.getInt("deptno"));
				dto.setDname(rs.getString("dname"));
				dto.setLoc(rs.getString("loc"));
				
				list.add(dto);
				
			}
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} finally {
			try {
				if(rs != null) rs.close();
				if(pstmt != null) pstmt.close();
				if(con != null) con.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		
		return list;
	}  // selectList() 메서드 end
	
	
	// DEPT 테이블에 부서정보를 저장하는 메서드.
	public int insertDept(DeptDTO dto) {
		
		int result = 0;
		
		try {
			// 3단계 : 데이터베이스에 전송할 SQL문을 작성.
			sql = "insert into dept values(?, ?, ?)";
			
			// 4단계 : SQL문을 데이터베이스 전송 객체에 저장.
			pstmt = con.prepareStatement(sql);
			
			pstmt.setInt(1, dto.getDeptno());
			pstmt.setString(2, dto.getDname());
			pstmt.setString(3, dto.getLoc());
			
			// 5단계 : SQL문을 데이터베이스에 전송 및 실행.
			
			// SQL문이 select 쿼리문인 경우 executeQuery() 메서드를 실행.
			// SQL문이 insert, update, delete 쿼리문인 경우에는
			// executeUpdate() 메서드를 실행.
			result = pstmt.executeUpdate();
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} finally {
			try {
				if(pstmt != null) pstmt.close();
				if(con != null) con.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		
		return result;
	}  // insertDept() 메서드 end
	
	
	// 매개변수로 넘어온 부서번호에 해당하는 부서를 삭제하는 메서드.
	public int deleteDept(int no) {
		
		int result = 0;
		
		
		try {
			// 3단계 : 데이터베이스에 전송할 SQL문 작성.
			sql = "delete from dept where deptno = ?";
			
			// 4단계 : SQL문을 데이터베이스 전송 객체에 저장.
			pstmt = con.prepareStatement(sql);
			
			pstmt.setInt(1, no);
			
			// 5단계 : SQL문을 데이터베이스에 전송 및 실행.
			result = pstmt.executeUpdate();
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} finally {
			try {
				if(pstmt != null) pstmt.close();
				if(con != null) con.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		
		return result;
	}  // deleteDept() 메서드 end
	
	
}




