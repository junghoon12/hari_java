package com.board.controller;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.board.action.*;


public class FrontController extends HttpServlet{
	private static final long serialVersionUID = 1L;
	
	protected void service(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {
		
		// 한글 깨짐 방지 작업 설정
		request.setCharacterEncoding("UTF-8");
		response.setContentType("text/html; charset=UTF-8");
		
		// getRequestURI() : "/프로젝트명/파일명(*.go)"를
		//                   문자열로 반환해 주는 메서드.
		String uri = request.getRequestURI();
		System.out.println("URI >>> " + uri);
		
		// getContextPath() : 현재 프로젝트명을 문자열로 반환해 주는 메서드.
		String path = request.getContextPath();
		System.out.println("Path >>> " + path);
		
		String command = uri.substring(path.length() + 1);
		System.out.println("Command >>> " + command);
		
		Action action = null;
		
		if(command.equals("list.go")) {
			action = new BoardListAction();
		}else if(command.equals("write_ok.go")) {
			action = new BoardWriteOkAction();
		}else if(command.equals("content.go")) {
			action = new BoardContentAction();
		}else if(command.equals("modify.go")) {
			action = new BoardModifyAction();
		}else if(command.equals("modify_ok.go")) {
			action = new BoardModifyOkAction();
		}else if(command.equals("delete_ok.go")) {
			action = new BoardDeleteOkAction();
		}else if(command.equals("search.go")) {
			action = new BoardSearchListAction();
		}
		
		String viewPage = action.execute(request, response);
		
		request.getRequestDispatcher(viewPage)
					.forward(request, response);
	}

}
