package com.member.controller;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.io.IOException;


@WebServlet("/delete.go")
public class DeleteServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    
    public DeleteServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	
	protected void service(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// get 방식으로 넘어온 회원번호를 받아서 회원번호에 해당하는
		// 회원의 정보를 삭제 폼 페이지로 이동시키는 비지니스 로직.
		
		int member_no = 
			Integer.parseInt(request.getParameter("num").trim());
		
		request.setAttribute("No", member_no);
		
		
		request.getRequestDispatcher("member_delete.jsp")
			.forward(request, response);
		
	}

}
