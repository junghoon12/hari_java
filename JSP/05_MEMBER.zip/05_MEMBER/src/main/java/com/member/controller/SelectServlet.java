package com.member.controller;

import jakarta.servlet.RequestDispatcher;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.util.List;

import com.member.model.MemberDAO;
import com.member.model.MemberDTO;


@WebServlet("/select.go")
public class SelectServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
   
    public SelectServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	
	protected void service(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// 요청 : 전체 회원 목록을 보여달라고 요청.
		// 응답 : DB에서 Member 테이블의 전체 회원 목록을 조회하여
		//       해당 회원 목록을 view page로 넘겨주는 비지니스 로직.
		
		// 1단계 : 데이터베이스와 연동
		MemberDAO dao = new MemberDAO();
		
		// System.out.println("select dao 주소 >>> " + dao);
		
		// 2단계 : member 테이블의 회원 전체 리스트를 조회해야 함.
		List<MemberDTO> memberList = dao.getMemberList();
		
		System.out.println("servlet memberList >>> " + memberList);
		
		request.setAttribute("Members", memberList);
		
		// 3단계 : 페이지 이동을 진행하자. ==> 요청에 대해서 응답을 하자.
		
		// RequestDispatcher rd = request.getRequestDispatcher("member_list.jsp");
		
		request.getRequestDispatcher("member_list.jsp")
			.forward(request, response);
			
	}

}
