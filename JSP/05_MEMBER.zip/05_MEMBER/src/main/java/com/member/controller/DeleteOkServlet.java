package com.member.controller;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.io.PrintWriter;

import com.member.model.MemberDAO;
import com.member.model.MemberDTO;


@WebServlet("/delete_ok.go")
public class DeleteOkServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    
    public DeleteOkServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	
	protected void service(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// 삭제 폼 페이지에서 넘어온 데이터들을 받아서
		// member 테이블에서 회원번호에 해당하는 회원을 
		// 삭제하는 비지니스 로직.
		response.setContentType("text/html; charset=UTF-8");
		
		
		String member_pwd = request.getParameter("mem_pass").trim();
		
		int mem_no = 
			Integer.parseInt(request.getParameter("mem_no").trim());
		
		MemberDAO dao = new MemberDAO();
		
		MemberDTO cont = dao.contentMember(mem_no);
		
		PrintWriter out = response.getWriter();
		
		if(member_pwd.equals(cont.getMempwd())) {
			
			int chk = dao.deleteMember(mem_no);
			
			if(chk > 0) {
				// 회원 삭제 시 번호 넘버링 작업.
				dao.updateNum(mem_no);
				
				out.println("<script>");
				out.println("alert('회원 삭제 성공!!!')");
				out.println("location.href='select.go'");
				out.println("</script>");
			}else {
				out.println("<script>");
				out.println("alert('회원 삭제 실패~~~')");
				out.println("history.back()");
				out.println("</script>");
			}
			
		}else {
			// 비밀번호가 틀린 경우
			out.println("<script>");
			out.println("alert('비밀번호가 틀립니다. 확인해 주세요~~~')");
			out.println("history.back()");
			out.println("</script>");
		}
		
	}

}
