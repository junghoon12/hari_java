package com.member.controller;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.io.PrintWriter;

import com.member.model.MemberDAO;
import com.member.model.MemberDTO;


@WebServlet("/insert.go")
public class InsertServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
   
    public InsertServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	
	protected void service(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// 회원등록 폼 페이지에서 넘어온 데이터들을 받아서
		// member 테이블에 회원으로 등록하는 비지니스 로직.
		
		// 한글 처리 작업.
		request.setCharacterEncoding("UTF-8");
		response.setContentType("text/html; charset=UTF-8");
		
		// 1단계 : 회원 등록 폼 페이지에서 넘어온 데이터들을 받아주어야 한다.
		String member_id = request.getParameter("mem_id").trim();
		
		String member_name = request.getParameter("mem_name").trim();
		
		String member_pwd = request.getParameter("mem_pwd").trim();
		
		int member_age =
			Integer.parseInt(request.getParameter("mem_age").trim());
		
		int member_mileage = 
			Integer.parseInt(request.getParameter("mem_mileage").trim());
		
		String member_job = request.getParameter("mem_job").trim();
		
		String member_addr = request.getParameter("mem_addr").trim();
		
		
		// 2단계 : 데이터베이스에 전송할 DTO객체에 해당 데이터들을 저장해 주자.
		MemberDTO dto = new MemberDTO();
		
		
		dto.setMemid(member_id);
		
		dto.setMemname(member_name);
		
		dto.setMempwd(member_pwd);
		
		dto.setAge(member_age);
		
		dto.setMileage(member_mileage);
		
		dto.setJob(member_job);
		
		dto.setAddr(member_addr);
		
		
		MemberDAO dao = new MemberDAO();
		
		int check = dao.insertMember(dto);
		
		PrintWriter out = response.getWriter();
		
		if(check > 0) {
			// 회원 등록 추가가 성공한 경우
			out.println("<script>");
			out.println("alert('회원 등록 성공.!!!')");
			out.println("location.href='select.go'");
			out.println("</script>");
		}else {
			// 회원 등록 추가가 실패한 경우
			out.println("<script>");
			out.println("alert('회원 등록 실패~~~')");
			out.println("history.back()");  // 이전 페이지로 이동
			out.println("</script>");
		}
		
	}

}
