package com.member.controller;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.io.IOException;

import com.member.model.MemberDAO;
import com.member.model.MemberDTO;


@WebServlet("/modify.go")
public class ModifyServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
   
    public ModifyServlet() {
        super();
        
    }

	
	protected void service(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// get 방식으로 넘어온 회원번호에 해당하는 회원의 정보를 조회하여
		// 회원의 정보를 수정 폼 페이지(view page)로 이동시키는 비지니스 로직.
		
		int member_no = 
			Integer.parseInt(request.getParameter("num").trim());
		
		// 1단계 : 데이터베이스와 연동 작업 진행.
		MemberDAO dao = new MemberDAO();
		
		// System.out.println("modify dao >>> " + dao);
		
		// 2단계 : member 테이블에서 get 방식으로 받은 회원번호에
	    //        해당하는 회원의 정보를 조회하는 메서드 호출.
		MemberDTO content = dao.contentMember(member_no);
		
		request.setAttribute("Modify", content);
		
		// 3단계 : 페이지를 이동시키자.
		request.getRequestDispatcher("member_modify.jsp")
			.forward(request, response);
		
	}

}
