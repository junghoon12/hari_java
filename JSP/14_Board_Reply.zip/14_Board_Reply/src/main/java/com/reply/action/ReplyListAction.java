package com.reply.action;

import java.io.IOException;
import java.io.PrintWriter;

import com.reply.model.BoardDAO;

import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

public class ReplyListAction implements Action {

	@Override
	public ActionForward execute(HttpServletRequest request, HttpServletResponse response) throws IOException {
		// 글번호(원글 번호)에 해당하는 댓글 전체 리스트를
		// tbl_reply 테이블에서 조회하여 view page로
		// 이동시키는 비지니스 로직.
		
		int reply_no =
			Integer.parseInt(request.getParameter("no").trim());
		
		BoardDAO dao = BoardDAO.getInstance();
		
		String result = dao.getReplyList(reply_no);
		
		response.setContentType("text/html; charset=UTF-8");
		
		PrintWriter out = response.getWriter();
		
		// Ajax 쪽으로 응답을 해 주면 됨.
		out.println(result);
		
		return null;
	}

}
