package com.reply.action;

import java.io.IOException;
import java.util.List;

import com.reply.model.BoardDAO;
import com.reply.model.BoardDTO;

import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

public class BoardListAction implements Action {

	@Override
	public ActionForward execute(HttpServletRequest request, HttpServletResponse response) throws IOException {
		// board 테이블의 전체 게시물 목록을 조회하여
		// view page로 이동시키는 비지니스 로직.
		
		BoardDAO dao = BoardDAO.getInstance();
		
		List<BoardDTO> list = dao.getBoardList();
		
		request.setAttribute("List", list);
		
		ActionForward forward = new ActionForward();
		
		forward.setRedirect(false);
		
		forward.setPath("board_list.jsp");
		
		
		return forward;
	}

}
