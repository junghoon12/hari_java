package com.reply.action;

import java.io.IOException;

import com.reply.model.BoardDAO;
import com.reply.model.BoardDTO;

import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

public class BoardContentAction implements Action {

	@Override
	public ActionForward execute(HttpServletRequest request, HttpServletResponse response) throws IOException {
		// get 방식으로 넘어온 글번호에 해당하는 게시글의 상세 정보를
		// board 테이블에서 조회하여 view page로 이동시키는 비지니스 로직.
		
		int board_no = 
			Integer.parseInt(request.getParameter("no").trim());
		
		BoardDAO dao = BoardDAO.getInstance();
		
		BoardDTO content = dao.getContentBoard(board_no);
		
		request.setAttribute("Cont", content);
		
		ActionForward forward = new ActionForward();
		
		forward.setRedirect(false);
		
		forward.setPath("board_content.jsp");
		
		
		return forward;
	
	}

}
