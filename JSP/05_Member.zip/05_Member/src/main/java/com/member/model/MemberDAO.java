package com.member.model;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class MemberDAO {

	// DB와 연결하는 객체.
	Connection con = null;
	
	// DB에 SQL문을 전송하는 객체.
	PreparedStatement pstmt = null;
	
	// SQL문을 실행한 후에 결과값을 가지고 있는 객체.
	ResultSet rs = null;
	
	// SQL문을 저장할 객체.
	String sql = null;
	
	
	// MemberDAO 객체를 싱글턴 방식으로 만들어 보자.
	// 1단계 : MemberDAO 객체를 정적(static) 멤버로
	//        선언을 해 주어야 한다.
	private static MemberDAO instance = null;
	
	
	// 2단계 : 싱글턴 방식으로 객체를 만들기 위해서는 우선적으로
	//        기본생성자의 접근지정자를 public이 아닌
	//        private으로 변경해 주어야 함.
	//        즉, 외부에서 직접적으로 기본생성자에 접근하여
	//        호출하지 못하도록 하는 방법이다.
	private MemberDAO() {  }  // 기본 생성자
	
	// 3단계 : 기본 생성자 대신에 싱글턴 객체를 return해 주는
	//        getInstance() 메서드를 만들어서 해당
	//        getInstance() 메서드를 외부에서 접근이 가능하도록
	//        해 주면 됨.
	public static MemberDAO getInstance() {
		
		if(instance == null) {
			instance = new MemberDAO();
		}
		
		return instance;
	
	}  // getInstance() 메서드 end
	
	
	// DB 연동 작업을 하는 메서드.
	public void openConn() {
		
		String driver = "oracle.jdbc.driver.OracleDriver";
		String url = "jdbc:oracle:thin:@localhost:1521:xe";
		String user = "goott";
		String password = "99229922";
		
		
		try {
			// 1단계 : 오라클 드라이버를 메모리로 로딩 작업 진행.
			Class.forName(driver);
			
			// 2단계 : 오라클 데이터베이스와 연결 작업 진행.
			con = DriverManager.getConnection(url, user, password);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}  // openConn() 메서드 end
	
	
	// DB에 연결되어 있던 자원을 종료하는 메서드.
	public void closeConn(ResultSet rs,
			PreparedStatement pstmt, Connection con) {
		
		
			try {
				if(rs != null) { rs.close(); }
				if(pstmt != null) { pstmt.close(); }
				if(con != null) { con.close(); }
				
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		
	}  // closeConn() 메서드 end
	
	// DB에 연결되어 있던 자원을 종료하는 메서드.
	public void closeConn(
			PreparedStatement pstmt, Connection con) {
		
			try {
				
				if(pstmt != null) { pstmt.close(); }
				if(con != null) { con.close(); }
				
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		
	}  // closeConn() 메서드 end
	
	
	
	// member 테이블에서 회원 전체 목록을 조회하는 메서드.
	public List<MemberDTO> getMemberList() {
		
		List<MemberDTO> list = new ArrayList<MemberDTO>();
		
		
		try {
			// 1 ~ 2단계 : 오라클 드라이버 로딩 및 데이터베이스와 연결 진행.
			openConn();
			
			// 3단계 : 데이터베이스에 전송할 SQL문 작성.
			sql = "select * from member order by memno desc";
			
			// 4단계 : SQL문을 데이터베이스 전송 객체에 인자로 전달.
			pstmt = con.prepareStatement(sql);
			
			// 5단계 : SQL문을 데이터베이스에 전송 및 실행.
			rs = pstmt.executeQuery();
			
			while(rs.next()) {
				
				MemberDTO dto = new MemberDTO();
				
				dto.setNum(rs.getInt("memno"));
				dto.setMemid(rs.getString("memid"));
				dto.setMemname(rs.getString("memname"));
				dto.setPwd(rs.getString("mempwd"));
				dto.setAge(rs.getInt("age"));
				dto.setMileage(rs.getInt("mileage"));
				dto.setJob(rs.getString("job"));
				dto.setAddr(rs.getString("addr"));
				dto.setRegdate(rs.getString("regdate"));
				
				list.add(dto);
				
			}
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} finally {
			// 6단계 : 데이터베이스와 연결되어 있던 자원 종료.
			closeConn(rs, pstmt, con);
		}
		
		return list;
	}  // getMemberList() 메서드 end
	
	
	// member 테이블에 회원을 추가하는 메서드.
	public int insertMember(MemberDTO dto) {
		
		int result = 0, count = 0;
		
		
		try {
			// 1 ~ 2단계 : 오라클 드라이버 로딩 및 데이터베이스와 연결 진행.
			openConn();
			
			// 3단계 : 데이터베이스에 전송할 SQL문 작성.
			sql = "select max(memno) from member";
			
			// 4단계 : SQL문을 데이터베이스 전송 객체에 인자로 전달.
			pstmt = con.prepareStatement(sql);
			
			// 5단계 : SQL문을 데이터베이스에 전송 및 실행.
			rs = pstmt.executeQuery();
			
			if(rs.next()) {
				count = rs.getInt(1);
			}
			
			// 3단계 : 데이터베이스에 전송할 SQL문 작성.
			sql = "insert into member values(?, ?, ?, ?, ?, ?, ?, ?, sysdate)";
			
			// 4단계 : SQL문을 데이터베이스 전송 객체에 인자로 전달.
			pstmt = con.prepareStatement(sql);
			
			// 4-1단계 : 플레이스 홀더(?)에 데이터를 배정.
			pstmt.setInt(1, count+1);
			pstmt.setString(2, dto.getMemid());
			pstmt.setString(3, dto.getMemname());
			pstmt.setString(4, dto.getPwd());
			pstmt.setInt(5, dto.getAge());
			pstmt.setInt(6, dto.getMileage());
			pstmt.setString(7, dto.getJob());
			pstmt.setString(8, dto.getAddr());
			
			// 5단계 : SQL문을 데이터베이스에 전송 및 실행.
			result = pstmt.executeUpdate();
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} finally {
			// 6단계 : 데이터베이스에 연결되어 있던 자원 종료하기.
			closeConn(rs, pstmt, con);
		}
		
		return result;
	}  // insertMember() 메서드 end
	
	
	// 회원번호에 해당하는 회원의 정보를 조회하는 메서드.
	public MemberDTO getMember(int no) {
		
		MemberDTO dto = null;
		
		
		try {
			// 1 ~ 2단계 : 오라클 드라이버 메모리로 로딩 및 데이터베이스 연결 작업 진행.
			openConn();
			
			// 3단계 : 데이터베이스에 전송할 SQL문 작성.
			sql = "select * from member where memno = ?";
			
			// 4단계 : SQL문을 데이터베이스 전송 객체에 인자로 전달.
			pstmt = con.prepareStatement(sql);
			
			// 4-1단계 : 플레이스 홀더(?)에 데이터를 배정.
			pstmt.setInt(1, no);
			
			// 5단계 : SQL문을 데이터베이스에 전송 및 실행.
			rs = pstmt.executeQuery();
			
			if(rs.next()) {
				
				dto = new MemberDTO();
				
				dto.setNum(rs.getInt("memno"));
				dto.setMemid(rs.getString("memid"));
				dto.setMemname(rs.getString("memname"));
				dto.setPwd(rs.getString("mempwd"));
				dto.setAge(rs.getInt("age"));
				dto.setMileage(rs.getInt("mileage"));
				dto.setJob(rs.getString("job"));
				dto.setAddr(rs.getString("addr"));
				dto.setRegdate(rs.getString("regdate"));
				
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} finally {
			// 6단계 : 데이터베이스에 연결되어 있던 자원 종료하기.
			closeConn(rs, pstmt, con);
		}
		
		return dto;
	}  // getMember() 메서드 end
	
	
	// member 테이블의 회원 정보를 수정하는 메서드.
	public int updateMember(MemberDTO dto) {
		
		int result = 0;
		
		
		try {
			// 1 ~ 2단계 : 오라클 드라이버 메모리로 로딩 및 데이터베이스 연결 작업 진행.
			openConn();
			
			// 3단계 : 데이터베이스에 전송할 SQL문 작성.
			sql = "update member set age = ?,"
					+ " mileage = ?, job = ?, "
					+ " addr = ? where memno = ?";
			
			// 4단계 : SQL문을 데이터베이스 전송 객체에 인자로 전달.
			pstmt = con.prepareStatement(sql);
			
			// 4-1단계 : 플레이스 홀더(?)에 데이터를 배정.
			pstmt.setInt(1, dto.getAge());
			pstmt.setInt(2, dto.getMileage());
			pstmt.setString(3, dto.getJob());
			pstmt.setString(4, dto.getAddr());
			pstmt.setInt(5, dto.getNum());
			
			// 5단계 : SQL문을 데이터베이스에 전송 및 실행.
			result = pstmt.executeUpdate();
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} finally {
			// 6단계 : 데이터베이스에 연결되어 있던 자원 종료하기.
			closeConn(pstmt, con);
		}
		
		return result;
	}  // updateMember() 메서드 end
	
	
	// 회원번호에 해당하는 회원을 member 테이블에서 삭제하는 메서드.
	public int deleteMember(int no) {
		
		int result = 0;
		
		
		try {
			// 1 ~ 2단계 : 오라클 드라이버 로딩 및 데이터베이스 연결 작업 진행.
			openConn();
			
			// 3단계 : 데이터베이스에 전송할 SQL문 작성.
			sql = "delete from member where memno = ?";
			
			// 4단계 : SQL문을 데이터베이스 전송 객체의 인자로 전달.
			pstmt = con.prepareStatement(sql);
			
			// 4-1단계 : 플레이스 홀더(?)에 데이터를 배정.
			pstmt.setInt(1, no);
			
			// 5단계 : SQL문을 데이터베이스에 전송 및 실행.
			result = pstmt.executeUpdate();
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} finally {
			// 6단계 : 데이터베이스에 연결되어 있던 자원 종료하기.
			closeConn(pstmt, con);
		}
		
		return result;
	}  // deleteMember() 메서드 end
	
	
	// 회원 번호 순번 작업 해 주는 메서드.
	public void updateSequence(int no) {
		
		
		try {
			// 1 ~ 2단계 : 오라클 드라이버 로딩 및 데이터베이스 연결 작업 진행.
			openConn();
			
			// 3단계 : 데이터베이스에 전송할 SQL문 작성.
			sql = "update member set memno = memno - 1 where memno > ?";
			
			// 4단계 : SQL문을 데이터베이스 전송 객체의 인자로 전달.
			pstmt = con.prepareStatement(sql);
			
			// 4-1단계 : 플레이스 홀더(?)에 데이터를 배정.
			pstmt.setInt(1, no);
			
			// 5단계 : SQL문을 데이터베이스에 전송 및 실행.
			pstmt.executeUpdate();
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} finally {
			// 6단계 : 데이터베이스에 연결되어 있던 자원 종료하기.
			closeConn(pstmt, con);
		}
		
	}  // updateSequence() 메서드 end
	
	
	// 검색어에 해당하는 회원을 조회하는 메서드.
	public List<MemberDTO> searchMemberList(
							String field, String keyword) {
	
		List<MemberDTO> searchList = new ArrayList<MemberDTO>();
		
		
		try {
			// 1 ~ 2단계 : 오라클 드라이버 로딩 및 데이터베이스 연결 작업 진행.
			openConn();
			
			// 3단계 : 데이터베이스에 전송할 SQL문 작성.
			sql = "select * from member ";
			
			if(field.equals("id")) {
				sql += " where memid like ? ";
			}else if(field.equals("name")) {
				sql += " where memname like ? ";
			}else if(field.equals("job")) {
				sql += " where job like ? ";
			}else {
				sql += " where addr like ? ";
			}
			
			sql += "order by memno desc";
			
			// 4단계 : SQL문을 데이터베이스 전송 객체의 인자로 전달.
			pstmt = con.prepareStatement(sql);
			
			// 4-1단계 : 플레이스 홀더(?)에 데이터를 배정.
			pstmt.setString(1, "%"+keyword+"%");
			
			// 5단계 : SQL문을 데이터베이스에 전송 및 실행.
			rs = pstmt.executeQuery();
			
			while(rs.next()) {
				
				MemberDTO dto = new MemberDTO();
				
				dto.setNum(rs.getInt("memno"));
				dto.setMemid(rs.getString("memid"));
				dto.setMemname(rs.getString("memname"));
				dto.setPwd(rs.getString("mempwd"));
				dto.setAge(rs.getInt("age"));
				dto.setMileage(rs.getInt("mileage"));
				dto.setJob(rs.getString("job"));
				dto.setAddr(rs.getString("addr"));
				dto.setRegdate(rs.getString("regdate"));
				
				searchList.add(dto);
				
			}
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} finally {
			// 6단계 : 데이터베이스에 연결되어 있던 자원 종료하기.
			closeConn(rs, pstmt, con);
		}
		
		return searchList;
	}  // searchMemberList() 메서드 end
	
}




