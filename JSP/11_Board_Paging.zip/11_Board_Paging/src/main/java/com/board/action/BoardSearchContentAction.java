package com.board.action;

import java.io.IOException;

import com.board.model.BoardDAO;
import com.board.model.BoardDTO;

import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

public class BoardSearchContentAction implements Action {

	@Override
	public ActionForward execute(HttpServletRequest request, HttpServletResponse response) throws IOException {
		// 검색 내용 중에 해당 게시글의 제목을 클릭하면 상세 정보를
		// board 테이블에서 가져와서 게시글의 상세 정보를
		// view page로 이동시키는 비지니스 로직.
		
		int board_no = 
			Integer.parseInt(request.getParameter("no").trim());
		
		int nowPage = 
			Integer.parseInt(request.getParameter("page").trim());
		
		String find_field = request.getParameter("field").trim();
		
		String find_keyword = request.getParameter("keyword").trim();
		
		
		BoardDAO dao = BoardDAO.getInstance();
		
		// 글제목을 클릭 시 조회수를 증가시켜 주는 메서드 호출.
		dao.readCount(board_no);
		
		// 글번호에 해당하는 게시글의 상세 정보를 조회하는 메서드 호출.
		BoardDTO content = dao.contentBoard(board_no);
		
		request.setAttribute("SearchCont", content);
		
		request.setAttribute("page", nowPage);
		
		request.setAttribute("field", find_field);
		
		request.setAttribute("keyword", find_keyword);
		
		
		ActionForward forward = new ActionForward();
		
		forward.setRedirect(false);
		
		forward.setPath("board_search_cont.jsp");
		
		
		return forward;
	}

}
