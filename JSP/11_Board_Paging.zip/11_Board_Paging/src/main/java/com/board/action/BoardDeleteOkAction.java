package com.board.action;

import java.io.IOException;
import java.io.PrintWriter;

import com.board.model.BoardDAO;

import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

public class BoardDeleteOkAction implements Action {

	@Override
	public ActionForward execute(HttpServletRequest request, HttpServletResponse response) throws IOException {
		// get 방식으로 넘어온 글번호에 해당하는 게시글을
		// board 테이블에서 삭제하는 비지니스 로직.
		String board_pwd = request.getParameter("pwd").trim();
		
		// type="hidden" 으로 넘어온 데이터들도 받아주어야 한다.
		int board_no = 
			Integer.parseInt(request.getParameter("board_no").trim());
		
		int nowPage = 
			Integer.parseInt(request.getParameter("page").trim());
		
		
		BoardDAO dao = BoardDAO.getInstance();
		
		PrintWriter out = response.getWriter();
		
		int chk = dao.deleteBoard(board_no, board_pwd);
		
		if(chk > 0) {
			
			// 성공한 경우에는 번호 재작업 진행.
			dao.updateSequence(board_no);
			
			out.println("<script>");
			out.println("alert('게시글 삭제 성공!!!')");
			out.println("location.href='board_list.go?page="+nowPage+"'");
			out.println("</script>");
			
		}else if(chk == -1) {
			out.println("<script>");
			out.println("alert('비밀번호가 틀립니다. 확인해 주세요~~~')");
			out.println("history.back()");
			out.println("</script>");
		}else {
			out.println("<script>");
			out.println("alert('게시글 삭제 실패~~~')");
			out.println("history.back()");
			out.println("</script>");
		}
		
		
		return null;


	}

}
