package com.shop.model;

public class CartDTO {

	private int cart_num;
	private int cart_pnum;
	private String cart_userid;
	private String cart_pname;
	private int cart_pqty;
	private int cart_price;
	private String cart_pspec;
	private String cart_pimage;
	
	
	
	public int getCart_num() {
		return cart_num;
	}
	
	public void setCart_num(int cart_num) {
		this.cart_num = cart_num;
	}
	
	public int getCart_pnum() {
		return cart_pnum;
	}
	
	public void setCart_pnum(int cart_pnum) {
		this.cart_pnum = cart_pnum;
	}
	
	public String getCart_userid() {
		return cart_userid;
	}
	
	public void setCart_userid(String cart_userid) {
		this.cart_userid = cart_userid;
	}
	
	public String getCart_pname() {
		return cart_pname;
	}
	
	public void setCart_pname(String cart_pname) {
		this.cart_pname = cart_pname;
	}
	
	public int getCart_pqty() {
		return cart_pqty;
	}
	
	public void setCart_pqty(int cart_pqty) {
		this.cart_pqty = cart_pqty;
	}
	
	public int getCart_price() {
		return cart_price;
	}
	
	public void setCart_price(int cart_price) {
		this.cart_price = cart_price;
	}
	
	public String getCart_pspec() {
		return cart_pspec;
	}
	
	public void setCart_pspec(String cart_pspec) {
		this.cart_pspec = cart_pspec;
	}
	
	public String getCart_pimage() {
		return cart_pimage;
	}
	
	public void setCart_pimage(String cart_pimage) {
		this.cart_pimage = cart_pimage;
	}
	
	
}
