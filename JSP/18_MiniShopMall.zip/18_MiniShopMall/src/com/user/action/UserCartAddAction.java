package com.user.action;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.shop.controller.Action;
import com.shop.controller.ActionForward;
import com.shop.model.CartDAO;
import com.shop.model.CartDTO;

public class UserCartAddAction implements Action {

	@Override
	public ActionForward execute(HttpServletRequest request, HttpServletResponse response) throws IOException {
		// 제품 상세 내역에서 장바구니 버튼을 클릭하면
		// 폼 태그 안에 있는 데이터들을 장바구니 테이블에
		// 저장하는 비지니스 로직.
		
		String product_name = request.getParameter("p_name").trim();
		
		int product_price = 
				Integer.parseInt(request.getParameter("p_price").trim());
		
		int product_pqty = 
				Integer.parseInt(request.getParameter("p_qty").trim());
		
		// 히든으로 넘어온 데이터들도 받아 주어야 한다.
		int product_no = 
				Integer.parseInt(request.getParameter("p_num").trim());
		
		String product_spec = request.getParameter("p_spec").trim();
		
		String product_image = request.getParameter("p_image").trim();
		
		String userId = request.getParameter("userId").trim();
		
		CartDTO dto = new CartDTO();
		
		dto.setCart_pnum(product_no);
		dto.setCart_userid(userId);
		dto.setCart_pname(product_name);
		dto.setCart_pqty(product_pqty);
		dto.setCart_price(product_price);
		dto.setCart_pspec(product_spec);
		dto.setCart_pimage(product_image);
		
		CartDAO dao = CartDAO.getInstance();
		
		int check = dao.insertCart(dto);
		
		PrintWriter out = response.getWriter();
		
		if(check > 0) {
			out.println("<script>");
			out.println("alert('장바구니에 상품 저장 성공!!!')");
			out.println("location.href='user_cart_list.do'");
			out.println("</script>");
		}else {
			out.println("<script>");
			out.println("alert('장바구니에 상품 저장 실패~~~')");
			out.println("history.back()");
			out.println("</script>");
		}
		
		return null;
	}

}
