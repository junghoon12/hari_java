/**
 * 내용 : customer 테이블을 이용한 Ajax 실습
 * 일자 : 2024년 12월 30일
 */

$(function() {
	
	// 여러 Ajax에서 공통적으로 동일하게 사용하는 속성 설정 작업.
	$.ajaxSetup({
		contentType : "application/x-www-form-urlencoded; charset=UTF-8",
		type : "post"
	});
	
	// 모든 데이터를 가져오는 함수.
	// customer 테이블에서 전체 데이터를 가져오는 함수.
	function getData() {
		
		$.ajax({
			url : "/13_Ajax/select.go",
			dataType : "xml",
			success : function(res) {
				// 테이블 태그의 첫번째 행(타이틀 태그)을 제외하고
				// 나머지 모든 행을 삭제하라는 명령어.
				$("#listTable tr:gt(0)").remove();
				
				let table = "";
				
				$(res).find("customer").each(function() {
					
					table += "<tr>";
					
					table += "<td>" + $(this).find("num").text() + "</td>";
					table += "<td>" + $(this).find("id").text() + "</td>";
					table += "<td>" + $(this).find("name").text() + "</td>";
					table += "<td>" + $(this).find("age").text() + "</td>";
					table += "<td>" + $(this).find("phone").text() + "</td>";
					table += "<td>" + $(this).find("addr").text() + "</td>";
					table += "<td> <input type='button' value='삭제' id='del' no='" + $(this).find("num").text() + "'></td>";					
					table += "</tr>";
					
				});
				
				// 테이블의 첫번째 행의 아래에 데이터를 추가해 주면 됨.
				$("#listTable tr:eq(0)").after(table);
			},
			
			error : function() {
				alert("데이터 통신 오류입니다.~~~");
			}
			
		});
	}
	
	
	// 아이디 중복 여부 확인.
	$("#id").keyup(function() {
		
		$.ajax({
			url : "/13_Ajax/idCheck.go",
			data : {id : $("#id").val() },
			dataType : "text",
			success : function(result) {
				
				$("span").html(result);
			},
			
			error : function() {
				
				alert("데이터 통신 오류입니다.~~~");
			}
		});
		
	});
	
	
	// 가입하기 버튼을 클릭했을 때 customer 테이블에 저장하기
	$("#btn").click(function() {
		
		$.ajax({
			url : "/13_Ajax/insert_ok.go",
			data : $("#inForm").serialize(),
			dataType : "text",
			success : function(res) {
				if(res > 0) {
					alert("고객 등록 완료!!!");
					
					// 고객 등록한 후에는 다시 전체
					// 고객 리스트를 받아서 화면에 출력.
					getData();
					
					// input 태그에 입력된 내용을 지워주자.
					$("input[type=text]").each(function() {
						$(this).val("");
					}); 
				}else {
					alert("고객 등록 실패~~~");
				}
			},
			
			error : function() {
				alert("데이터 통신 오류입니다.~~~");
			}
			
		});
		
	});
	
	
	// 삭제 버튼 클릭 시 이벤트 적용.
	// 형식) on.("click" 이나 "change" 같은 이벤트 이름,
    //           "이벤트가 적용될 선택자 또는 태그", 동작함수(콜백함수)
	$("table").on("click", "#del",function() {
		
		$.ajax({
			url : "/13_Ajax/delete_ok.go",
			data : "no="+$(this).attr("no"),
			dataType : "text",
			success : function(res) {
				
				if(res > 0) {
					alert("고객이 삭제 되었습니다.!!!");
					
					getData();
				}else {
					alert("고객 삭제 실패~~~");
				}
			},
			
			error : function() {
				
				alert("데이터 통신 오류입니다.~~~");
			}
		});
	});
	
	
	getData();
	
});