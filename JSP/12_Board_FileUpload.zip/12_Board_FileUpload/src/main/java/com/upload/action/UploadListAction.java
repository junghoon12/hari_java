package com.upload.action;

import java.io.IOException;
import java.util.List;

import com.upload.model.UploadDAO;
import com.upload.model.UploadDTO;

import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

public class UploadListAction implements Action {

	@Override
	public ActionForward execute(HttpServletRequest request, HttpServletResponse response) throws IOException {
		// upload 테이블에 있는 전체 게시물 목록을 조회하여
		// view page로 이동시키는 비지니스 로직.
		
		UploadDAO dao = UploadDAO.getInstance();
		
		// 전체 게시물 목록을 조회하는 메서드 호출.
		List<UploadDTO> list = dao.getUploadList();
		
		request.setAttribute("List", list);
		
		ActionForward forward = new ActionForward();
		
		forward.setRedirect(false);
		
		forward.setPath("upload_list.jsp");
		
		
		return forward;
	}

}
