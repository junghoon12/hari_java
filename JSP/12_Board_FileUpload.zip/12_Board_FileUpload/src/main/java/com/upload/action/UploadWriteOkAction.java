package com.upload.action;

import java.io.File;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.Calendar;

import com.upload.model.UploadDAO;
import com.upload.model.UploadDTO;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.MultipartConfig;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.Part;


public class UploadWriteOkAction implements Action {

	@Override
	public ActionForward execute(HttpServletRequest request, HttpServletResponse response) throws IOException, ServletException {
		// 자료실 폼 페이지에서 넘어온 데이터들을 받아서
		// upload 테이블에 저장시키는 비지니스 로직.
		
		// 1. 파일 저장 경로
		String saveFolder = 
				"D:\\KDT\\workspace(jsp)\\12_Board_FileUpload\\src\\main\\webapp\\upload";
		
		UploadDTO dto = new UploadDTO();
		
		
		// 2. 글쓰기 폼 페이지에서 넘어온 데이터들을 받아 주어야 한다.
		String upload_writer = request.getParameter("writer").trim();
		
		String upload_title = request.getParameter("title").trim();
		
		String upload_content = request.getParameter("content").trim();
		
		String upload_pwd = request.getParameter("pwd").trim();
		
		// 3. 파일 데이터 받기(input type="file" name 속성 값)
		Part filePart = request.getPart("file");
		
		if(filePart != null && filePart.getSize() > 0) {
			// 첨부파일이 글쓰기 폼 창에서 첨부가 되었다면
			String fileName = filePart.getSubmittedFileName();  // 원본 파일명
			
			// 날짜 객체 생성 및 폴더 경로 설정.
			Calendar cal = Calendar.getInstance();
			
			int year = cal.get(Calendar.YEAR);        // 년도
			
			int month = cal.get(Calendar.MONTH) + 1;  // 월
			
			int day = cal.get(Calendar.DAY_OF_MONTH); // 일
			
			
			String homedir =
				saveFolder + "/" + year + "_" + month + "_" + day;
			
			File dir = new File(homedir);
			
			if(!dir.exists()) {
				
				dir.mkdirs();    // 실제로 폴더를 만들어 주는 메서드.
			}
			
			String reFileName = upload_writer + "_" + fileName;
			
			// 파일을 upload 폴더에 저장
			filePart.write(homedir + "/" + reFileName);
			
			// DB(upload)에 저장할 파일 경로.
			String fileDBName =
			"/" + year + "_" + month + "_" + day + "/" + reFileName;
			
			dto.setUpload_file(fileDBName);
		}
		
		dto.setUpload_writer(upload_writer);
		dto.setUpload_title(upload_title);
		dto.setUpload_cont(upload_content);
		dto.setUpload_pwd(upload_pwd);
		
		UploadDAO dao = UploadDAO.getInstance();
		
		int chk = dao.insertUpload(dto);
		
		PrintWriter out = response.getWriter();
		
		if(chk > 0) {
			out.println("<script>");
			out.println("alert('자료실 업로드 게시글 추가 성공!!!')");
			out.println("location.href='upload_list.go'");
			out.println("</script>");
		
		}else {
			out.println("<script>");
			out.println("alert('자료실 업로드 게시글 추가 실패~~~')");
			out.println("history.back()");
			out.println("</script>");
		}
		
		
		return null;
	}

}
