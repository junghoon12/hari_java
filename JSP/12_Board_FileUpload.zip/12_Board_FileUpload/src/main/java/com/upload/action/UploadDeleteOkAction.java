package com.upload.action;

import java.io.File;
import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.upload.model.UploadDAO;

public class UploadDeleteOkAction implements Action {

	@Override
	public ActionForward execute(HttpServletRequest request, HttpServletResponse response) throws IOException {
		// 삭제 폼 페이지에서 남어온 데이터들을 받아서
		// upload 테이블에서 게시글을 삭제하는 비지니스 로직.
		
		String upload_pwd = request.getParameter("pwd").trim();
		
		// type="hidden" 으로 넘어온 데이터들도 받아주어야 한다.
		int upload_no = 
			Integer.parseInt(request.getParameter("no").trim());
		
		String db_pwd = request.getParameter("db_pwd").trim();
		
		String fileName = request.getParameter("file");
		
		// upload 폴더에 업로드된 파일도 삭제를 하자.
		String upload = "D:\\NCS\\workspace(jsp)\\12_Board_FileUpload\\src\\main\\webapp\\upload";
		
		PrintWriter out = response.getWriter();
		
		UploadDAO dao = UploadDAO.getInstance();
		
		if(upload_pwd.equals(db_pwd)) {
			// 비밀번호가 일치하는 경우
			int chk = dao.deleteUpload(upload_no);
			
			// 첨부파일이 존재하는 경우 첨부파일까지 삭제해 보자.
			if(fileName != null) {
				
				File file = new File(upload + fileName);
				
				file.delete();  // 파일을 제거하는 메서드.
			}
			
			if(chk > 0) {
				
				dao.updateSequence(upload_no);
				
				out.println("<script>");
				out.println("alert('자료실 게시판 게시글 삭제 성공!!!')");
				out.println("location.href='upload_list.go'");
				out.println("</script>");
			}else {
				out.println("<script>");
				out.println("alert('자료실 게시판 게시글 삭제 실패~~~')");
				out.println("history.back()");
				out.println("</script>");
			}
			
		}else {
			// 비밀번호가 틀린 경우
			out.println("<script>");
			out.println("alert('비밀번호가 틀려요. 확인해 주세요~~~')");
			out.println("history.back()");
			out.println("</script>");
		}
		
		
		return null;
	}

}
