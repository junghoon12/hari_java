package himedia;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.io.PrintWriter;


@WebServlet("/sungjuk")
public class ScoreServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    
    public ScoreServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
	}

	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		// 한글 처리 작업 진행
		request.setCharacterEncoding("UTF-8");
		response.setContentType("text/html; charset=UTF-8");
		
		// 1단계 : 성적 폼 페이지에서 넘어온 데이터들을 받아주어야 한다.
		String name = request.getParameter("name").trim();
		int kor = Integer.parseInt(request.getParameter("kor").trim());
		int eng = Integer.parseInt(request.getParameter("eng").trim());
		int mat = Integer.parseInt(request.getParameter("mat").trim());
		
		// 2단계 : 총점 및 평균을 구하자.
		int sum = kor + eng + mat;    // 총점을 구하는 작업
		
		double avg = sum / 3.0;       // 평균을 구하는 작업
		
		// 3단계 : 학점을 구하자.
		String grade;
		
		if(avg >= 90) {
			grade = "A학점";
		}else if(avg >= 80) {
			grade = "B학점";
		}else if(avg >= 70) {
			grade = "C학점";
		}else if(avg >= 60) {
			grade = "D학점";
		}else {
			grade = "F학점";
		}
		
		// 4단계 : 클라이언트의 요청에 응답을 해 주자.
		PrintWriter out = response.getWriter();
		
		out.println("<html>");
		
		out.println("<body>");
		out.println("<div align='center'>");
		out.println("<table border='1' width='250'>");
		out.println("<tr>");
		out.println("<th>이 름</th>");
		out.println("<td>" + name + "</td>");
		out.println("</tr>");
		
		out.println("<tr>");
		out.println("<th>국어점수</th>");
		out.println("<td>" + kor + "점</td>");
		out.println("</tr>");
		
		out.println("<tr>");
		out.println("<th>영어점수</th>");
		out.println("<td>" + eng + "점</td>");
		out.println("</tr>");
		
		out.println("<tr>");
		out.println("<th>수학점수</th>");
		out.println("<td>" + mat + "점</td>");
		out.println("</tr>");
		
		out.println("<tr>");
		out.println("<th>총 점</th>");
		out.println("<td>" + sum + "점</td>");
		out.println("</tr>");
		
		out.println("<tr>");
		out.println("<th>평 균</th>");
		out.println("<td>" + String.format("%.2f점", avg) + "</td>");
		out.println("</tr>");
		
		out.println("<tr>");
		out.println("<th>학 점</th>");
		out.println("<td>" + grade + "</td>");
		out.println("</tr>");
		out.println("</div>");
		out.println("</body>");
		
		out.println("</html>");
		
		
	}

}
