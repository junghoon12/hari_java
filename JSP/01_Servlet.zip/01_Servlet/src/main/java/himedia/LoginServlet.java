package himedia;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.io.PrintWriter;


@WebServlet("/LoginServlet")
public class LoginServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    
    public LoginServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// form 태그에서 method="get" 인 경우
		
		// request : - 첫번째 매개변수
		//           - 사용자(클라이언트)의 요청에 대한 정보를 처리.

		// response : - 두번째 매개변수
		//            - 사용자(클라이언트)의 요청에 대한 처리 결과를
		//              클라이언트에게 응답하는 처리.
		
		// 1단계 : 클라이언트에서 넘어온 데이터들을 받아 주어야 함.
		//        사용자가 전송한 데이터(아이디, 비밀번호)를 받아주어야 한다.
		String id = request.getParameter("userId");
		
		String pwd = request.getParameter("userPwd");
		
		System.out.println("아이디 >>> " + id);
		
		System.out.println("비밀번호 >>> " + pwd);
		
		// 2단계 : 요청에 대해서 응답을 하자.
		// 클라이언트에 응답 시 한글을 작성하면 한글이 깨지는 현상이 발생함.
		response.setContentType("text/html; charset=UTF-8");
		
		// getWriter() 메서드는 response 객체에 있는 메서드로
		// 문자 기반 출력 스트림을 반환해 주는 메서드임.
		// 반환 타입이 PrintWriter 객체 타입으로 반환이 됨.
		// PrintWriter 객체는 텍스트 데이터를 출력할 수 있는 스트림임.
		// 즉, out을 이용하면 HTML, 문자열 등 텍스트 데이터를
		// 웹 브라우저를 통해 클라이언트에게 응답을 보낼 수 있음.
		PrintWriter out = response.getWriter();
		
		out.println("<html>");
		out.println("<head></head>");
		out.println("<body>");
		out.println("<h2>아이디 : " +id + "<br>");
		out.println("비밀번호 : " + pwd + "</h2>");
		out.println("</body>");
		out.println("</html>");
	}

	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// form 태그에서 method="post" 인 경우
		
	}

}
