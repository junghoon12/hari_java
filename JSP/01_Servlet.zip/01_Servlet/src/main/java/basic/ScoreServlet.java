package basic;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;


@WebServlet("/score")
public class ScoreServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
   
    public ScoreServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	
	protected void service(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// 한글 깨짐 방지 작업 설정
		request.setCharacterEncoding("UTF-8");
		response.setContentType("text/html; charset=UTF-8");
		
		// 1단계 : Ex06.jsp 페이지에서 넘어온 데이터들을 받아 주어야 한다.
		String name = request.getParameter("name").trim();
		
		int kor = Integer.parseInt(request.getParameter("kor").trim());
		
		int eng = Integer.parseInt(request.getParameter("eng").trim());
		
		int mat = Integer.parseInt(request.getParameter("mat").trim());
		
		// 2단계 : 총점과 평균을 구하자.
		int total = kor + eng + mat;
		
		double avg = total / 3.0;
		
		// 3단계 : 학점을 구하자.
		String grade;
		
		// if(avg >= 90) {
		// 	grade = "A학점";
		// }else if(avg >= 80) {
		// 	grade = "B학점";
		// }else if(avg >= 70) {
		// 	grade = "C학점";
		// }else if(avg >= 60) {
		// 	grade = "D학점";
		// }else {
		//  grade = "F학점";
		// }
		
		switch((int)(avg / 10)) {
			case 10 :
			case 9 :
				grade = "A학점";
				break;
			case 8 :
				grade = "B학점";
				break;	
			case 7 :
				grade = "C학점";
				break;
			case 6 :
				grade = "D학점";
				break;
			default :
				grade = "F학점";
		}
		
		// 4단계 : 웹 브라우저에 성적 결과를 출력하자.
		PrintWriter out = response.getWriter();
		
		out.println("<html>");
		out.println("<head></head>");
		out.println("<body>");
		out.println("<div align='center'>");
		out.println("<table border='1'>");
		
		out.println("<tr>");
		out.println("<th>이 름</th>");
		out.println("<td>" + name + "</td>");
		out.println("</tr>");
		
		out.println("<tr>");
		out.println("<th>국어점수</th>");
		out.println("<td>" + kor + "점</td>");
		out.println("</tr>");
		
		out.println("<tr>");
		out.println("<th>영어점수</th>");
		out.println("<td>" + eng + "점</td>");
		out.println("</tr>");
		
		out.println("<tr>");
		out.println("<th>수학점수</th>");
		out.println("<td>" + mat + "점</td>");
		out.println("</tr>");
		
		out.println("<tr>");
		out.println("<th>총 점</th>");
		out.println("<td>" + total + "점</td>");
		out.println("</tr>");
		
		out.println("<tr>");
		out.println("<th>평 균</th>");
		out.println("<td>" + String.format("%.2f점", avg) + "</td>");
		out.println("</tr>");
		
		out.println("<tr>");
		out.println("<th>학 점</th>");
		out.println("<td>" + grade + "</td>");
		out.println("</tr>");
		
		out.println("</table>");
		out.println("</div>");
		out.println("</body>");
		out.println("</html>");
		
	}

}
