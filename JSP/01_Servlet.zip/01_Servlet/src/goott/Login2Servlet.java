package goott;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;


@WebServlet("/login")
public class Login2Servlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
   
    public Login2Servlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	
	protected void service(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		response.setContentType("text/html; charset=UTF-8");
		
		String user_id = request.getParameter("id");
		
		String user_pwd = request.getParameter("pwd");
		
		PrintWriter out = response.getWriter();
		
		out.println("<html>");
		out.println("<body>");
		out.println("<div align='center'>");
		
		out.println("<h2>회원 정보</h2>");
		out.println("<h3>");
		out.println("아이디 : " + user_id + "<br>");
		out.println("비밀번호 : " + user_pwd);
		out.println("</h3>");
		
		out.println("</div>");
		out.println("</body>");
		out.println("</html>");
		
	}

}
