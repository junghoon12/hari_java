package com.board1.controller;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.util.List;

import com.board1.model.BoardDAO;
import com.board1.model.BoardDTO;


@WebServlet("/list.go")
public class SelectServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    
    public SelectServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	
	protected void service(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// 요청 : 전체 게시물 목록을 보여달라고 요청.
		// 응답 : 전체 게시물 목록을 board 테이블에서 조회하여
		//       view page로 이동시키는 비지니스 로직.
		
		BoardDAO dao = BoardDAO.getInstance();
		
		List<BoardDTO> boardList = dao.getBoardList();
		
		request.setAttribute("List", boardList);
		
		request.getRequestDispatcher("board/board_list.jsp")
				.forward(request, response);
		
	}

}




