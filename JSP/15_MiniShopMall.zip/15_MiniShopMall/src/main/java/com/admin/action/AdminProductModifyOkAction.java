package com.admin.action;

import java.io.IOException;
import java.io.PrintWriter;

import com.shop.controller.Action;
import com.shop.controller.ActionForward;
import com.shop.model.AdminDAO;
import com.shop.model.ProductDTO;

import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.Part;

public class AdminProductModifyOkAction implements Action {

	@Override
	public ActionForward execute(HttpServletRequest request, HttpServletResponse response)
			throws IOException, ServletException {
		// 수정 폼 페이지에서 넘어온 데이터들을 받아서
		// shop_product 테이블에서 상품의 정보를 수정하는 비지니스 로직.
		
		// 첨부파일이 저장될 경로 설정.
		String saveFolder = 
				"D:\\KDT\\workspace(jsp)\\15_MiniShopMall\\src\\main\\webapp\\upload\\";
		
		ProductDTO dto = new ProductDTO();
		
		String product_name = request.getParameter("p_name").trim();
		
		String product_category = request.getParameter("p_category").trim();
		
		String product_company = request.getParameter("p_company").trim();
		
		int product_qty = 
			Integer.parseInt(request.getParameter("p_qty").trim());
		
		int product_price = 
				Integer.parseInt(request.getParameter("p_price").trim());
		
		String product_spec = request.getParameter("p_spec").trim();
				
		String product_content = request.getParameter("p_content").trim();
		
		int product_point = 
				Integer.parseInt(request.getParameter("p_point").trim());
		
		// type="hidden" 으로 넘어온 데이터들도 받아주어야 한다.
		int product_no = 
			Integer.parseInt(request.getParameter("pnum").trim());
		
		Part product_file = request.getPart("p_image_new");
		
		String fileName = null;
		
		if(product_file != null && product_file.getSize() > 0) {
			// 수정 폼 페이지에서 첨부파일을 선택한 경우
			fileName = product_file.getSubmittedFileName();
			
			product_file.write(saveFolder + fileName);
		}else {
			// 수정 폼 페이지에서 첨부파일을 선택을 하지 않은 경우
			fileName = request.getParameter("p_image_old");
		}
		
		dto.setPimage(fileName);
		
		dto.setPnum(product_no);
		dto.setPname(product_name);
		dto.setPcategory_fk(product_category);
		dto.setPcompany(product_company);
		dto.setPqty(product_qty);
		dto.setPrice(product_price);
		dto.setPspec(product_spec);
		dto.setPcontents(product_content);
		dto.setPoint(product_point);
		
		
		AdminDAO dao = AdminDAO.getInstance();
		
		int chk = dao.updateProduct(dto);
		
		PrintWriter out = response.getWriter();
		
		
		if(chk > 0) {
			out.println("<script>");
			out.println("alert('상품 정보 수정 성공!!!')");
			out.println("location.href='admin_product_content.go?pnum="+product_no+"'");
			out.println("</script>");
		}else {
			out.println("<script>");
			out.println("alert('상품 정보 수정 실패~~~')");
			out.println("history.back()");
			out.println("</script>");
		}
		
		
		return null;
	}

}
