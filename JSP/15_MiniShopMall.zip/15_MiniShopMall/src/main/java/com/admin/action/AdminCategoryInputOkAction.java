package com.admin.action;

import java.io.IOException;
import java.io.PrintWriter;

import com.shop.controller.Action;
import com.shop.controller.ActionForward;
import com.shop.model.AdminDAO;
import com.shop.model.CategoryDTO;

import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

public class AdminCategoryInputOkAction implements Action {

	@Override
	public ActionForward execute(HttpServletRequest request, HttpServletResponse response)
			throws IOException, ServletException {
		// 카테고리 등록 폼 페이지엇 넘어온 데이터들을 받아서
		// shop_category 테이블에 저장하는 비지니스 로직.
		
		String category_code = request.getParameter("category_code").trim();
		
		String category_name = request.getParameter("category_name").trim();
		
		CategoryDTO dto = new CategoryDTO();
		
		dto.setCategory_code(category_code);
		dto.setCategory_name(category_name);
		
		AdminDAO dao = AdminDAO.getInstance();
		
		int chk = dao.insertCategory(dto);
		
		PrintWriter out = response.getWriter();
		
		if(chk > 0) {
			out.println("<script>");
			out.println("alert('카테고리 코드 등록 성공!!!')");
			out.println("location.href='admin_category_list.go'");
			out.println("</script>");
		}else {
			out.println("<script>");
			out.println("alert('카테고리 코드 등록 실패~~~')");
			out.println("history.back()");
			out.println("</script>");
		}
		
		return null;
	}

}
