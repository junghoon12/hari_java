package com.admin.action;

import java.io.IOException;
import java.io.PrintWriter;

import com.shop.controller.Action;
import com.shop.controller.ActionForward;
import com.shop.model.AdminDAO;

import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

public class AdminProductDeleteAction implements Action {

	@Override
	public ActionForward execute(HttpServletRequest request, HttpServletResponse response)
			throws IOException, ServletException {
		// get 방식으로 넘어온 상품번호에 해당하는 상품을
		// shop_product 테이블에서 삭제하는 비지니스 로직.
		
		int product_no = 
			Integer.parseInt(request.getParameter("num").trim());
		
		AdminDAO dao = AdminDAO.getInstance();
		
		int chk = dao.deleteProduct(product_no);
		
		PrintWriter out = response.getWriter();
		
		if(chk > 0) {
			out.println("<script>");
			out.println("alert('상품 삭제 성공!!!')");
			out.println("location.href='admin_product_list.go'");
			out.println("</script>");
		
		}else {
			out.println("<script>");
			out.println("alert('상품 삭제 실패~~~')");
			out.println("history.back()");
			out.println("</script>");
		}
		
		return null;
	}

}
