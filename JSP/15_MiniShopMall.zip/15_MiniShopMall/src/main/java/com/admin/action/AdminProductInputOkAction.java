package com.admin.action;

import java.io.IOException;
import java.io.PrintWriter;

import com.shop.controller.Action;
import com.shop.controller.ActionForward;
import com.shop.model.AdminDAO;
import com.shop.model.ProductDTO;

import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.Part;

public class AdminProductInputOkAction implements Action {

	@Override
	public ActionForward execute(HttpServletRequest request, HttpServletResponse response)
			throws IOException, ServletException {
		// 상품 등록 폼 페이지에서 넘어온 데이터들을 받아서
		// shop_product 테이블에 저장하는 비지니스 로직.
		
		// 첨부파일이 저장될 경로 설정.
		String saveFolder = 
				"D:\\KDT\\workspace(jsp)\\15_MiniShopMall\\src\\main\\webapp\\upload\\";
		
		ProductDTO dto = new ProductDTO();
		
		String product_pname = request.getParameter("p_name").trim();
		
		String product_category = request.getParameter("p_category").trim();
		
		String product_company = request.getParameter("p_company").trim();
		
		int product_pqty = 
			Integer.parseInt(request.getParameter("p_qty").trim());
		
		int product_price = 
			Integer.parseInt(request.getParameter("p_price").trim());
		
		String product_pspec = request.getParameter("p_spec").trim();
		
		String product_content = request.getParameter("p_content").trim();
		
		int product_point = 
			Integer.parseInt(request.getParameter("p_point").trim());
		
		// 파일 데이터를 받아주어야 한다.(input type="file" name 변수)
		Part product_file = request.getPart("p_file");
		
		if(product_file != null && product_file.getSize() > 0) {
			// 첨부파일이 상품등록 폼 페이지에서 파일 첨부가 되었다면
			String fileName = product_file.getSubmittedFileName();
			
			// 파일을 저장하는 폴더에 실제 파일을 저장.
			product_file.write(saveFolder + fileName);
			
			dto.setPimage(fileName);
		}
		
		dto.setPname(product_pname);
		dto.setPcategory_fk(product_category);
		dto.setPcompany(product_company);
		dto.setPqty(product_pqty);
		dto.setPrice(product_price);
		dto.setPspec(product_pspec);
		dto.setPcontents(product_content);
		dto.setPoint(product_point);
		
		AdminDAO dao = AdminDAO.getInstance();
		
		int chk = dao.insertProduct(dto);
		
		PrintWriter out = response.getWriter();
		
		if(chk > 0) {
			out.println("<script>");
			out.println("alert('상품 등록 성공!!!')");
			out.println("location.href='admin_product_list.go'");
			out.println("</script>");
		}else {
			out.println("<script>");
			out.println("alert('상품 등록 실패~~~')");
			out.println("history.back()");
			out.println("</script>");
		}
		
		return null;
	}

}
