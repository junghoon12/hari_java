package com.user.action;

import java.io.IOException;

import com.shop.controller.Action;
import com.shop.controller.ActionForward;
import com.shop.model.AdminDAO;
import com.shop.model.ProductDTO;

import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

public class UserProductContentAction implements Action {

	@Override
	public ActionForward execute(HttpServletRequest request, HttpServletResponse response)
			throws IOException, ServletException {
		// get 방식으로 넘어온 상품번호에 해당하는 상품의
		// 상세 정보를 조회하여 view page로 이동시키는 비지니스 로직.
		
		int product_no =
			Integer.parseInt(request.getParameter("pnum").trim());
		
		AdminDAO dao = AdminDAO.getInstance();
		
		ProductDTO content = dao.getProductContent(product_no);
		
		request.setAttribute("ProductCont", content);
		
		
		ActionForward forward = new ActionForward();
		
		forward.setRedirect(false);
		
		forward.setPath("user/user_product_content.jsp");
		
		
		return forward;
	
	}

}
