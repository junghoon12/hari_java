package com.user.action;

import java.io.IOException;
import java.util.List;

import com.shop.controller.Action;
import com.shop.controller.ActionForward;
import com.shop.model.CartDTO;
import com.shop.model.UserDAO;

import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;

public class UserCartListAction implements Action {

	@Override
	public ActionForward execute(HttpServletRequest request, HttpServletResponse response)
			throws IOException, ServletException {
		// shop_cart 장바구니 테이블에서 세션에 저장된 사용자 아이디에
		// 해당하는 장바구니 목록을 조회하여 view page로 이동시키는 비지니스 로직.
		
		// 세션 정보를 하나 받아와야 한다.
		HttpSession session = request.getSession();
		
		String user_id = (String)session.getAttribute("UserId");
		
		UserDAO dao = UserDAO.getInstance();
		
		
		List<CartDTO> list = dao.getCartList(user_id);
		
		request.setAttribute("CartList", list);
		
		
		ActionForward forward = new ActionForward();
		
		forward.setRedirect(false);
		
		forward.setPath("user/user_cart_list.jsp");
		
		
		return forward;
		
	}

}
