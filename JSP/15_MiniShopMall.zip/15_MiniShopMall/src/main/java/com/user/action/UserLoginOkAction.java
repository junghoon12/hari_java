package com.user.action;

import java.io.IOException;
import java.io.PrintWriter;

import com.shop.controller.Action;
import com.shop.controller.ActionForward;
import com.shop.model.MemberDTO;
import com.shop.model.UserDAO;

import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;

public class UserLoginOkAction implements Action {

	@Override
	public ActionForward execute(HttpServletRequest request, HttpServletResponse response)
			throws IOException, ServletException {
		// 사용자 로그인 폼 페이지에서 넘어온 사용자 아이디와
		// 사용자 비밀번호를 가지고 member 테이블의 회원인지
		// 여부를 확인하는 비지니스 로직.
		
		String user_id = request.getParameter("user_id").trim();
		
		String user_pwd = request.getParameter("user_pwd").trim();
		
		UserDAO dao = UserDAO.getInstance();
		
		// 회원인지 여부를 확인하는 메서드 호출.
		int chk = dao.userCheck(user_id, user_pwd);
		
		PrintWriter out = response.getWriter();
		
		ActionForward forward = null;
		
		if(chk > 0) {
			// 회원인 경우
			// 아이디에 해당하는 회원의 상세 정보를 조회하는 메서드 호출.
			MemberDTO cont = dao.getMember(user_id);
			
			HttpSession session = request.getSession();
			
			// 세션에 사용자의 정보를 담아서 페이지 이동을 시키자
			session.setAttribute("UserId", cont.getMemid());
			
			session.setAttribute("UserName", cont.getMemname());
			
			forward = new ActionForward();
			
			forward.setRedirect(true);
			
			forward.setPath("user_main.go");
		
		}else if(chk == -1) {
			// 비밀번호가 틀린 경우
			out.println("<script>");
			out.println("alert('비밀번호가 틀립니다. 확인해 주세요~~~')");
			out.println("history.back()");
			out.println("</script>");
		
		}else {
			// 사용자 아이디가 없는 경우
			out.println("<script>");
			out.println("alert('회원이 아닙니다. 아이디를 확인해 주세요~~~')");
			out.println("history.back()");
			out.println("</script>");
		}
		
		
		return forward;
	}

}
