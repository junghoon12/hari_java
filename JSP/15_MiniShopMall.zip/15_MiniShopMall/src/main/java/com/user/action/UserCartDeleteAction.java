package com.user.action;

import java.io.IOException;
import java.io.PrintWriter;

import com.shop.controller.Action;
import com.shop.controller.ActionForward;
import com.shop.model.UserDAO;

import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

public class UserCartDeleteAction implements Action {

	@Override
	public ActionForward execute(HttpServletRequest request, HttpServletResponse response)
			throws IOException, ServletException {
		// get 방식으로 넘어온 장바구니 번호에 해당하는
		// 장바구니 내역을 shop_cart 테이블에서 삭제하는 비지니스 로직.
		
		int cart_no = 
			Integer.parseInt(request.getParameter("num").trim());
		
		UserDAO dao = UserDAO.getInstance();
		
		int chk = dao.deleteCart(cart_no);
		
		PrintWriter out = response.getWriter();
		
		if(chk > 0) {
			
			out.println("<script>");
			out.println("alert('장바구니 제품 삭제 성공!!!')");
			out.println("location.href='user_cart_list.go'");
			out.println("</script>");
		}else {
			
			out.println("<script>");
			out.println("alert('장바구니 제품 삭제 실패~~~')");
			out.println("history.back()");
			out.println("</script>");
		}
		
		
		return null;
	}

}
