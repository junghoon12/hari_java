package com.user.action;

import java.io.IOException;
import java.util.List;

import com.shop.controller.Action;
import com.shop.controller.ActionForward;
import com.shop.model.AdminDAO;
import com.shop.model.ProductDTO;

import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

public class UserMainAction implements Action {

	@Override
	public ActionForward execute(HttpServletRequest request, HttpServletResponse response)
			throws IOException, ServletException {
		// 관리자 단에서 만든 상품 전체 리스트를 shop_product
		// 테이블에서 조회하여 view page로 이동시키는 비지니스 로직.
		AdminDAO dao = AdminDAO.getInstance();
		
		List<ProductDTO> productList = dao.getProductList();
		
		request.setAttribute("ProductList", productList);
		
		
		ActionForward forward = new ActionForward();
		
		forward.setRedirect(false);
		
		forward.setPath("user/user_main.jsp");
		
		
		return forward;
	}

}
