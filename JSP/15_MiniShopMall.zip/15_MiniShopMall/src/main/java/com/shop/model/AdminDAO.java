package com.shop.model;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

import javax.naming.Context;
import javax.naming.InitialContext;
import javax.sql.DataSource;


public class AdminDAO {

	// 멤버변수
	// 1. 데이터베이스와 연동하는 객체.
	Connection con = null;
	
	// 2. 데이터베이스에 SQL문을 전송하는 객체.
	PreparedStatement pstmt = null;
	
	// 3. SQL문을 실행한 후 결과값을 가지고 있는 객체.
	ResultSet rs = null;
	
	// 4. SQL 문을 저장할 문자열 객체.
	String sql = null;
	
	
	// AdminDAO 클래스를 싱글턴 방식으로 만들어 보자.
	// 1단계 : 싱글턴 방식으로 객체를 만들기 위해서는 우선적으로
	//        기본 생성자의 접근지정자를 private 으로 선언해야 함.
	private AdminDAO() {  }  // 기본 생성자
	
	// 2단계 : AdminDAO 객체를 정적 멤버로 선언해야 함. - static 으로 선언해야 함.
	private static AdminDAO instance = null;
	
	// 3단계 : 기본 생성자 대신에 싱글턴 객체를 return 해 주는
	//        getInstance() 라는 메서드를 만들어서 외부에서는
	//        해당 메서드로 접근할 수 있게 해주면 됨.
	public static AdminDAO getInstance() {
		
		if(instance == null) {
			instance = new AdminDAO();
		}
		
		return instance;
	}
	
	
	// 데이터베이스와 연동하는 작업을 하는 메서드. - DBCP 방식으로 연동.
	public void openConn() {
		
		
		try {
			// 1단계 : JNDI 서버 객체 생성.
			// Context 객체 : 이름(name) -> 객체(Object) 를 
			//               매핑해서 관리하는 인터페이스.
			//               서버에 등록된 자원(DB 커넥션, DataSource 등)을
			//               이름으로 조회를 할 수 있음.
			
			// InitialContext() : JDNI에서 가장 처음 사용하는 
			//                    기본 컨텍스트 구현 클래스의 생성자.
			//                    이 서버의 JNDI 환경에 접근하겠다는 의미.
			// JNDI 서버(톰켓, WAS 등)에 접속해서 자원을 찾을 준비를 한다는 의미.
			Context ctx = new InitialContext();
			
			// 2단계 : lookup() 메서드를 이용하여 매칭되는 커넥션을 찾는다.
			DataSource ds = 
					(DataSource)ctx.lookup("java:comp/env/jdbc/myoracle");
			
			// 3단계 : DataSource 객체를 이용하여 커넥션 객체를 하나 가져온다.
			con = ds.getConnection();
			
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}  // openConn() 메서드 end
	
	
	// 자원을 종료시키는 메서드.
	public void closeConn(ResultSet rs,
			PreparedStatement pstmt, Connection con) {
		
		try {
			if(rs != null) rs.close();
			if(pstmt != null) pstmt.close();
			if(con != null) con.close();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}  // closeConn(rs, pstmt, con) 메서드 end
	
	
	// 자원을 종료시키는 메서드.
	public void closeConn(
			PreparedStatement pstmt, Connection con) {
		
		try {
			if(pstmt != null) pstmt.close();
			if(con != null) con.close();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}  // closeConn(pstmt, con) 메서드 end
	
	
	
	// 관리자 로그인 화면에서 입력한 아이디와 비밀번호로
	// 관리자인지 여부를 확인하는 메서드.
	public int adminCheck(String id, String pwd) {
		
		int result = 0;
		
		
		try {
			openConn();
			
			sql = "select * from shop_admin "
					+ " where admin_id = ?";
			
			pstmt = con.prepareStatement(sql);
			
			pstmt.setString(1, id);
			
			rs = pstmt.executeQuery();
			
			if(rs.next()) {
				
				if(pwd.equals(rs.getString("admin_pwd"))) {
					// 관리자인 경우(아이디와 비밀번호가 일치하는 경우)
					result = 1;
					
				}else {
					// 비밀번호가 틀린 경우(아이디는 일치하나 비밀번호가 틀린 경우)
					result = -1;
				}
				
			}
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} finally {
			
			closeConn(rs, pstmt, con);
		}
		
		return result;
	}  // adminCheck() 메서드 end
	
	
	
	// 관리자에 대한 상세 정보를 조회하는 메서드.
	public AdminDTO getAdmin(String id) {
		
		AdminDTO dto = null;
		
		
		try {
			openConn();
			
			sql = "select * from shop_admin "
					+ " where admin_id = ?";
			
			pstmt = con.prepareStatement(sql);
			
			pstmt.setString(1, id);
			
			rs = pstmt.executeQuery();
			
			if(rs.next()) {
				
				dto = new AdminDTO();
				
				dto.setAdmin_id(rs.getString(1));
				dto.setAdmin_pwd(rs.getString(2));
				dto.setAdmin_name(rs.getString(3));
				dto.setAdmin_email(rs.getString(4));
				dto.setAdmin_phone(rs.getString(5));
				dto.setAdmin_date(rs.getString(6));
			}
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} finally {
			
			closeConn(rs, pstmt, con);
		}
		
		return dto;
	}  // getAdmin() 메서드 end
	
	
	
	// 카테고리 테이블에 카테고리를 추가하는 메서드.
	public int insertCategory(CategoryDTO dto) {
		
		int result = 0, count = 0;
		
		
		try {
			openConn();
			
			sql = "select count(*) from "
					+ " shop_category";
			
			pstmt = con.prepareStatement(sql);
			
			rs = pstmt.executeQuery();
			
			if(rs.next()) {
				
				count = rs.getInt(1);
			}
			
			sql = "insert into shop_category "
					+ " values(?, ?, ?)";

			pstmt = con.prepareStatement(sql);
			
			pstmt.setInt(1, count + 1);
			pstmt.setString(2, dto.getCategory_code());
			pstmt.setString(3, dto.getCategory_name());
			
			result = pstmt.executeUpdate();
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} finally {
			
			closeConn(rs, pstmt, con);
		}
		
		return result;
	}  // insertCategory() 메서드 end
	
	
	// shop_category 테이블에 있는 카테고리 목록을 조회하는 메서드.
	public List<CategoryDTO> getCategoryList() {
		
		List<CategoryDTO> list = new ArrayList<CategoryDTO>();
		
		
		try {
			openConn();
			
			sql = "select * from shop_category "
					+ " order by category_num desc";
			
			pstmt = con.prepareStatement(sql);
			
			rs = pstmt.executeQuery();
			
			while(rs.next()) {
				
				CategoryDTO dto = new CategoryDTO();
				
				dto.setCategory_num(rs.getInt("category_num"));
				dto.setCategory_code(rs.getString("category_code"));
				dto.setCategory_name(rs.getString("category_name"));
				
				list.add(dto);
				
			}
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} finally {
			
			closeConn(rs, pstmt, con);
		}
		
		return list;
	}  // getCategoryList() 메서드 end
	

	
	// shop_product 테이블에 상품을 저장하는 메서드.
	public int insertProduct(ProductDTO dto) {
		
		int result = 0, count = 0;
		
		
		try {
			openConn();
			
			sql = "select count(*) from shop_product";
			
			pstmt = con.prepareStatement(sql);
			
			rs = pstmt.executeQuery();
			
			if(rs.next()) {
				
				count = rs.getInt(1);
			}
			
			sql = "insert into shop_product "
					+ " values(?, ?, ?, ?, ?, ?, "
					+ " ?, ?, ?, ?, sysdate)";
			
			pstmt = con.prepareStatement(sql);
			
			pstmt.setInt(1, count + 1);
			pstmt.setString(2, dto.getPname());
			pstmt.setString(3, dto.getPcategory_fk());
			pstmt.setString(4, dto.getPcompany());
			pstmt.setString(5, dto.getPimage());
			pstmt.setInt(6, dto.getPqty());
			pstmt.setInt(7, dto.getPrice());
			pstmt.setString(8, dto.getPspec());
			pstmt.setString(9, dto.getPcontents());
			pstmt.setInt(10, dto.getPoint());
			
			result = pstmt.executeUpdate();
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} finally {
			
			closeConn(rs, pstmt, con);
		}
		
		return result;
	}  // insertProduct() 메서드 end
	
	
	
	// 전체 상품 목록을 조회하는 메서드.
	public List<ProductDTO> getProductList() {
		
		List<ProductDTO> list = new ArrayList<ProductDTO>();
		
		
		try {
			openConn();
			
			sql = "select * from shop_product "
					+ " order by pnum desc";
			
			pstmt = con.prepareStatement(sql);
			
			rs = pstmt.executeQuery();
			
			while(rs.next()) {
				
				ProductDTO dto = new ProductDTO();
				
				dto.setPnum(rs.getInt("pnum"));
				dto.setPname(rs.getString("pname"));
				dto.setPcategory_fk(rs.getString("pcategory_fk"));
				dto.setPcompany(rs.getString("pcompany"));
				dto.setPimage(rs.getString("pimage"));
				dto.setPqty(rs.getInt("pqty"));
				dto.setPrice(rs.getInt("price"));
				dto.setPspec(rs.getString("pspec"));
				dto.setPcontents(rs.getString("pcontents"));
				dto.setPoint(rs.getInt("point"));
				dto.setPinputdate(rs.getString("pinputdate"));
				
				list.add(dto);
				
			}
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} finally {
			
			closeConn(rs, pstmt, con);
		}
		
		return list;
	}  // getProductList() 메서드 end
	
	
	// 카테고리 번호에 해당하는 카테고리를 
	// 테이블에서 삭제하는 메서드.
	public int deleteCategory(int cnum) {
		
		int result = 0;
		
		
		try {
			openConn();
			
			sql = "delete from shop_category "
					+ " where category_num = ?";
			
			pstmt = con.prepareStatement(sql);
			
			pstmt.setInt(1, cnum);
			
			result = pstmt.executeUpdate();
			
			if(result > 0) {
				// 삭제가 성공한 경우 - 카테고리 번호 재작업.
				sql = "update shop_category set "
						+ " category_num = category_num - 1 "
						+ " where category_num > ?";
				
				pstmt = con.prepareStatement(sql);
				
				pstmt.setInt(1, cnum);
				
				pstmt.executeUpdate();
				
			}
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} finally {
			
			closeConn(pstmt, con);
		}
		
		return result;
	}  // deleteCategory() 메서드 end
	
	
	
	// 상품번호에 해당하는 상품의 상세 정보를 조회하는 메서드.
	public ProductDTO getProductContent(int no) {
		
		ProductDTO dto = null;
		
		
		try {
			openConn();
			
			sql = "select * from shop_product "
					+ " where pnum = ?";
			
			pstmt = con.prepareStatement(sql);
			
			pstmt.setInt(1, no);
			
			rs = pstmt.executeQuery();
			
			if(rs.next()) {
				
				dto = new ProductDTO();
				
				dto.setPnum(rs.getInt("pnum"));
				dto.setPname(rs.getString("pname"));
				dto.setPcategory_fk(rs.getString("pcategory_fk"));
				dto.setPcompany(rs.getString("pcompany"));
				dto.setPimage(rs.getString("pimage"));
				dto.setPqty(rs.getInt("pqty"));
				dto.setPrice(rs.getInt("price"));
				dto.setPspec(rs.getString("pspec"));
				dto.setPcontents(rs.getString("pcontents"));
				dto.setPoint(rs.getInt("point"));
				dto.setPinputdate(rs.getString("pinputdate"));
				
			}
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} finally {
			
			closeConn(rs, pstmt, con);
		}
		
		return dto;
	}  // getProductContent() 메서드 end
	
	
	// shop_product 테이블에서 제품의 정보를 수정하는 메서드.
	public int updateProduct(ProductDTO dto) {
		
		int result = 0;
		
		
		try {
			openConn();
			
			sql = "update shop_product set "
					+ " pimage = ?, pqty = ?, "
					+ " price = ?, pspec = ?, "
					+ " pcontents = ?, point = ? "
					+ " where pnum = ?";
			
			pstmt = con.prepareStatement(sql);
			
			pstmt.setString(1, dto.getPimage());
			pstmt.setInt(2, dto.getPqty());
			pstmt.setInt(3, dto.getPrice());
			pstmt.setString(4, dto.getPspec());
			pstmt.setString(5, dto.getPcontents());
			pstmt.setInt(6, dto.getPoint());
			pstmt.setInt(7, dto.getPnum());
			
			result = pstmt.executeUpdate();
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} finally {
			
			closeConn(pstmt, con);
		}
		
		return result;
	}  // updateProduct() 메서드 end
	
	
	
	// 상품번호에 해당하는 상품을 삭제하는 메서드.
	public int deleteProduct(int pnum) {
		
		int result = 0;
		
		
		try {
			openConn();
			
			sql = "delete from shop_product "
					+ " where pnum = ?";
			
			pstmt = con.prepareStatement(sql);
			
			pstmt.setInt(1, pnum);
			
			result = pstmt.executeUpdate();
			
			// 상품번호를 재정렬을 하자.
			if(result > 0) {
				
				sql = "update shop_product "
						+ " set pnum = pnum - 1 "
						+ " where pnum > ?";
				
				pstmt = con.prepareStatement(sql);
				
				pstmt.setInt(1, pnum);
				
				pstmt.executeUpdate();
				
			}
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} finally {
			
			closeConn(pstmt, con);
		}
		
		return result;
	}  // deleteProduct() 메서드 end
	
	
	
	// 카테고리 코드에 해당하는 상품의 전체 리스트를
	// 조회하는 메서드.
	public List<ProductDTO> getProductList(String code) {
		
		List<ProductDTO> list = new ArrayList<ProductDTO>();
		
		
		try {
			openConn();
			
			sql = "select * from shop_product "
					+ " where pcategory_fk = ?";
			
			pstmt = con.prepareStatement(sql);
			
			pstmt.setString(1, code);
			
			rs = pstmt.executeQuery();
			
			while(rs.next()) {
				
				ProductDTO dto = new ProductDTO();
				
				dto.setPnum(rs.getInt("pnum"));
				dto.setPname(rs.getString("pname"));
				dto.setPcategory_fk(rs.getString("pcategory_fk"));
				dto.setPcompany(rs.getString("pcompany"));
				dto.setPimage(rs.getString("pimage"));
				dto.setPqty(rs.getInt("pqty"));
				dto.setPrice(rs.getInt("price"));
				dto.setPspec(rs.getString("pspec"));
				dto.setPcontents(rs.getString("pcontents"));
				dto.setPoint(rs.getInt("point"));
				dto.setPinputdate(rs.getString("pinputdate"));
				
				list.add(dto);
				
			}
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} finally {
			
			closeConn(rs, pstmt, con);
		}
		
		return list;
	}  // getProductList() 메서드 end
	
	
	
	
	
}
