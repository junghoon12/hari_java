package com.shop.model;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

import javax.naming.Context;
import javax.naming.InitialContext;
import javax.sql.DataSource;

public class UserDAO {

	// 멤버변수
	// 1. 데이터베이스와 연동하는 객체.
	Connection con = null;
	
	// 2. 데이터베이스에 SQL문을 전송하는 객체.
	PreparedStatement pstmt = null;
	
	// 3. SQL문을 실행한 후 결과값을 가지고 있는 객체.
	ResultSet rs = null;
	
	// 4. SQL 문을 저장할 문자열 객체.
	String sql = null;
	
	
	// UserDAO 클래스를 싱글턴 방식으로 만들어 보자.
	// 1단계 : 싱글턴 방식으로 객체를 만들기 위해서는 우선적으로
	//        기본 생성자의 접근지정자를 private 으로 선언해야 함.
	private UserDAO() {  }  // 기본 생성자
	
	// 2단계 : UserDAO 객체를 정적 멤버로 선언해야 함. - static 으로 선언해야 함.
	private static UserDAO instance = null;
	
	// 3단계 : 기본 생성자 대신에 싱글턴 객체를 return 해 주는
	//        getInstance() 라는 메서드를 만들어서 외부에서는
	//        해당 메서드로 접근할 수 있게 해주면 됨.
	public static UserDAO getInstance() {
		
		if(instance == null) {
			instance = new UserDAO();
		}
		
		return instance;
	}
	
	
	// 데이터베이스와 연동하는 작업을 하는 메서드. - DBCP 방식으로 연동.
	public void openConn() {
		
		
		try {
			// 1단계 : JNDI 서버 객체 생성.
			// Context 객체 : 이름(name) -> 객체(Object) 를 
			//               매핑해서 관리하는 인터페이스.
			//               서버에 등록된 자원(DB 커넥션, DataSource 등)을
			//               이름으로 조회를 할 수 있음.
			
			// InitialContext() : JDNI에서 가장 처음 사용하는 
			//                    기본 컨텍스트 구현 클래스의 생성자.
			//                    이 서버의 JNDI 환경에 접근하겠다는 의미.
			// JNDI 서버(톰켓, WAS 등)에 접속해서 자원을 찾을 준비를 한다는 의미.
			Context ctx = new InitialContext();
			
			// 2단계 : lookup() 메서드를 이용하여 매칭되는 커넥션을 찾는다.
			DataSource ds = 
					(DataSource)ctx.lookup("java:comp/env/jdbc/myoracle");
			
			// 3단계 : DataSource 객체를 이용하여 커넥션 객체를 하나 가져온다.
			con = ds.getConnection();
			
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}  // openConn() 메서드 end
	
	
	// 자원을 종료시키는 메서드.
	public void closeConn(ResultSet rs,
			PreparedStatement pstmt, Connection con) {
		
		try {
			if(rs != null) rs.close();
			if(pstmt != null) pstmt.close();
			if(con != null) con.close();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}  // closeConn(rs, pstmt, con) 메서드 end
	
	
	// 자원을 종료시키는 메서드.
	public void closeConn(
			PreparedStatement pstmt, Connection con) {
		
		try {
			if(pstmt != null) pstmt.close();
			if(con != null) con.close();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}  // closeConn(pstmt, con) 메서드 end
	
	
	// 회원인지 여부를 조회하는 메서드.
	public int userCheck(String id, String pwd) {
		
		int result = 0;
		
		
		try {
			openConn();
			
			sql = "select * from member "
					+ " where memid = ?";
			
			pstmt = con.prepareStatement(sql);
			
			pstmt.setString(1, id);
			
			rs = pstmt.executeQuery();
			
			if(rs.next()) {
				// 아이디가 있는 경우 - 회원인 경우
				
				if(pwd.equals(rs.getString("mempwd"))) {
					// 회원인 경우 - 아이디와 비밀번호가 일치하는 경우
					result = 1;
				}else {
					// 비밀번호가 틀린 경우 - 아이디는 일치하나 비밀번호가 틀린 경우
					result = -1;
				}
			}
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} finally {
			
			closeConn(rs, pstmt, con);
		}
		
		return result;
	}  // userCheck() 메서드 end
	
	
	// 아이디에 해당하는 회원의 정보를 조회하는 메서드.
	public MemberDTO getMember(String id) {
		
		MemberDTO dto = null;
		
		
		try {
			openConn();
			
			sql = "select * from member where memid = ?";
			
			pstmt = con.prepareStatement(sql);
			
			pstmt.setString(1, id);
			
			rs = pstmt.executeQuery();
			
			if(rs.next()) {
				
				dto = new MemberDTO();
				
				dto.setMemno(rs.getInt("memno"));
				dto.setMemid(rs.getString("memid"));
				dto.setMemname(rs.getString("memname"));
				dto.setMempwd(rs.getString("mempwd"));
				dto.setAge(rs.getInt("age"));
				dto.setMileage(rs.getInt("mileage"));
				dto.setJob(rs.getString("job"));
				dto.setAddr(rs.getString("addr"));
				dto.setRegdate(rs.getString("regdate"));
				
			}
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} finally {
			
			closeConn(rs, pstmt, con);
		}
		
		return dto;
	}  // getMember() 메서드 end
	
	
	// shop_cart 장바구니 테이블에 상품을 저장하는 메서드.
	public int insertCart(CartDTO dto) {
		
		int result = 0, count = 0;
		
		
		try {
			openConn();
			
			sql = "select count(*) from shop_cart";
			
			pstmt = con.prepareStatement(sql);
			
			rs = pstmt.executeQuery();
			
			if(rs.next()) {
				
				count = rs.getInt(1);
			}
			
			sql = "insert into shop_cart "
					+ " values(?, ?, ?, ?, ?, ?, ?, ?)";
			
			pstmt = con.prepareStatement(sql);
			
			pstmt.setInt(1, count + 1);
			pstmt.setInt(2, dto.getCart_pnum());
			pstmt.setString(3, dto.getCart_userid());
			pstmt.setString(4, dto.getCart_pname());
			pstmt.setInt(5, dto.getCart_pqty());
			pstmt.setInt(6, dto.getCart_price());
			pstmt.setString(7, dto.getCart_pspec());
			pstmt.setString(8, dto.getCart_pimage());
			
			result = pstmt.executeUpdate();
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} finally {
			
			closeConn(rs, pstmt, con);
		}
		
		return result;
	}  // insertCart() 메서드 end
	
	
	
	// shop_cart 테이블에서 사용자 아이디에 해당하는
	// 장바구니 목록을 조회하는 메서드.
	public List<CartDTO> getCartList(String id) {
		
		List<CartDTO> list = new ArrayList<CartDTO>();
		
		
		try {
			openConn();
			
			sql = "select * from shop_cart "
					+ " where cart_userid = ? "
					+ " order by cart_num desc";
			
			pstmt = con.prepareStatement(sql);
			
			pstmt.setString(1, id);
			
			rs = pstmt.executeQuery();
			
			while(rs.next()) {
				
				CartDTO dto = new CartDTO();
				
				dto.setCart_num(rs.getInt("cart_num"));
				dto.setCart_pnum(rs.getInt("cart_pnum"));
				dto.setCart_userid(rs.getString("cart_userid"));
				dto.setCart_pname(rs.getString("cart_pname"));
				dto.setCart_pqty(rs.getInt("cart_pqty"));
				dto.setCart_price(rs.getInt("cart_price"));
				dto.setCart_pspec(rs.getString("cart_pspec"));
				dto.setCart_pimage(rs.getString("cart_pimage"));
				
				list.add(dto);
			
			}
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} finally {
			
			closeConn(rs, pstmt, con);
		}
		
		return list;
	}  // getCartList() 메서드 end
	
	
	
	// 장바구니 번호에 해당하는 장바구니 목록을
	// shop_cart 테이블에서 삭제하는 메서드.
	public int deleteCart(int cart_no) {
		
		int result = 0;
		
		
		try {
			openConn();
			
			sql = "delete from shop_cart "
					+ " where cart_num = ?";
			
			pstmt = con.prepareStatement(sql);
			
			pstmt.setInt(1, cart_no);
			
			result = pstmt.executeUpdate();
			
			// 장바구니 번호 재작업 진행.
			if(result > 0) {
				
				sql = "update shop_cart set "
						+ " cart_num = cart_num - 1 "
						+ " where cart_num > ?";
				
				pstmt = con.prepareStatement(sql);
				
				pstmt.setInt(1, cart_no);
				
				pstmt.executeUpdate();
				
			}
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} finally {
			
			closeConn(pstmt, con);
		}
		
		return result;
	}  // deleteCart() 메서드 end
	
	
}
