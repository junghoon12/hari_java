package himedia;

import jakarta.servlet.RequestDispatcher;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.io.IOException;


@WebServlet("/forward")
public class ForwardServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    
    public ForwardServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
	}

	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		String user_id = request.getParameter("id").trim();

		String user_pwd = request.getParameter("pwd").trim();
		
		// 원래는 DB의 회원 관리 테이블에서 입력한 id와 pwd가 맞는지
		// 확인을 하여 회원이면 메인 페이지로 이동.
		String db_id = "hong";
		String db_pwd = "1234";
		
		if(user_id.equals(db_id)) {
			
			if(user_pwd.equals(db_pwd)) {
				// 회원인 경우
				// 회원인 경우에는 메인 페이지로 이동. ==> 페이지 이동
				// 페이지 이동 시 특정한 정보를 가지고 이동하는 경우가 많음.
				request.setAttribute("Name", "홍길동");
				
				RequestDispatcher rd = request.getRequestDispatcher("ex08.jsp");
				
				rd.forward(request, response);  // 실제로 페이지 이동
				
			}else {
				System.out.println("비밀번호가 틀립니다. 비밀번호를 다시 한 번 확인해 주세요.!!!");
			}
			
		}else {
			System.out.println("아이디가 틀립니다. 아이디를 다시 한 번 확인해 주세요.!!!");
		}
	}

}
