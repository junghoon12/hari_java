package com.emp.controller;

import java.io.IOException;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.emp.model.EmpDAO;
import com.emp.model.EmpDTO;


@WebServlet("/select")
public class SelectServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
   
    public SelectServlet() {
        super();
    }

	
	protected void service(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// main.jsp 페이지에서 요청 내용
		// ==> EMP 테이블에 있는 전체 사원을 보여달라는 요청(비지니스 로직)
		
		// 1단계 : DB와 연결 작업 진행.
		EmpDAO dao = new EmpDAO();
		
		// 2단계 : DB에서 EMP 테이블의 전체 사원 목록 조회
		List<EmpDTO> empList = dao.selectEmpList();
		
		// 3단계 : 페이지 이동 시 정보(데이터)를 넘겨 주어야 함.
		request.setAttribute("List", empList);
		
		// 4단계 : 이동할 페이지 경로를 설정해 주어야 함.
		RequestDispatcher rd = 
				request.getRequestDispatcher("view/emp_list.jsp");
		
		// 5단계 : 실제 페이지로 이동
		rd.forward(request, response);
	}

}
