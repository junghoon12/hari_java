package com.emp.controller;

import java.io.IOException;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.emp.model.DeptDTO;
import com.emp.model.EmpDAO;
import com.emp.model.EmpDTO;


@WebServlet("/update")
public class UpdateServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    
    public UpdateServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	protected void service(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// get 방식으로 넘어온 사원번호에 해당하는 사원의 정보를
		// DB에서 조회하여 수정 폼 페이지로 이동시키는 비지니스 로직.
		
		int emp_no = 
				Integer.parseInt(request.getParameter("no").trim());
		
		EmpDAO dao = new EmpDAO();
		
		// EMP 테이블에서 담당업무 리스트를 조회해 보자.
		List<String> jobList = dao.getJobList();
		
		// EMP 테이블에서 관리자 사원 리스트를 조회해 보자.
		List<EmpDTO> mgrList = dao.getMgrList();
		
		// DEPT 테이블에서 부서 전체 리스트를 조회해 보자.
		List<DeptDTO> deptList = dao.getDeptList();
		
		// 사원번호에 해당하는 사원의 상세정보도 받아오자.
		EmpDTO modify = dao.contentEmp(emp_no);
		
		// 모든 정보를 view page(수정 폼 페이지)로 이동을 시키자.
		request.setAttribute("jList", jobList);
		request.setAttribute("mList", mgrList);
		request.setAttribute("dList", deptList);
		request.setAttribute("Modify", modify);
		
		// view page 이동경로를 만들고 페이지 이동까지 같이 진행.		
		request.getRequestDispatcher("view/emp_modify.jsp")
						.forward(request, response);
		

	}

}
