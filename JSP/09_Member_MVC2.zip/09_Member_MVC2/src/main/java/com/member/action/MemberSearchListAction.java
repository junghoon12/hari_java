package com.member.action;

import java.io.IOException;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.member.model.MemberDAO;
import com.member.model.MemberDTO;

public class MemberSearchListAction implements Action {

	@Override
	public String execute(HttpServletRequest request, HttpServletResponse response) throws IOException {
		// 검색어에 해당하는 회원의 리스트를 DB에서
		// 조회하여 view page로 이동시키는 비지니스 로직.
		
		String search_field = request.getParameter("field").trim();
		
		String search_keyword = request.getParameter("keyword").trim();
		
		MemberDAO dao = MemberDAO.getInstance();
		
		List<MemberDTO> searchList = 
				dao.searchMemberList(search_field, search_keyword);
		
		request.setAttribute("Search", searchList);
		
		
		return "view/member_searchList.jsp";
		
	}

}








