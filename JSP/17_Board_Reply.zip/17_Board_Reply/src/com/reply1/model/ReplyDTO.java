package com.reply1.model;

public class ReplyDTO {

	private int rno;
	private int bno;
	private String rewriter;
	private String recont;
	private String regdate;
	private String regupdate;
	
	
	public int getRno() {
		return rno;
	}
	
	public void setRno(int rno) {
		this.rno = rno;
	}
	
	public int getBno() {
		return bno;
	}
	
	public void setBno(int bno) {
		this.bno = bno;
	}
	
	public String getRewriter() {
		return rewriter;
	}
	
	public void setRewriter(String rewriter) {
		this.rewriter = rewriter;
	}
	
	public String getRecont() {
		return recont;
	}
	
	public void setRecont(String recont) {
		this.recont = recont;
	}
	
	public String getRegdate() {
		return regdate;
	}
	
	public void setRegdate(String regdate) {
		this.regdate = regdate;
	}
	
	public String getRegupdate() {
		return regupdate;
	}
	
	public void setRegupdate(String regupdate) {
		this.regupdate = regupdate;
	}
	
	
}
