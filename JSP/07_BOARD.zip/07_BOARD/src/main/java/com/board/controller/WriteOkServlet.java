package com.board.controller;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.io.PrintWriter;

import com.board.model.BoardDAO;
import com.board.model.BoardDTO;


@WebServlet("/board_write_ok.go")
public class WriteOkServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    
    public WriteOkServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	
	protected void service(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// 게시글 폼 페이지에서 넘어온 데이터들을 받아서
		// board 테이블에 저장시키는 비지니스 로직.
		
		// 한글 처리 작업 진행.
		request.setCharacterEncoding("UTF-8");
		response.setContentType("text/html; charset=UTF-8");
		
		// 1단계 : 게시글 입력 폼 페이지에서 넘어온 데이터들을 받아주어야 한다.
		String board_writer = request.getParameter("writer").trim();
		
		String board_title = request.getParameter("title").trim();
		
		String board_content = request.getParameter("content").trim();
		
		String board_pwd = request.getParameter("pwd").trim();
		
		
		// 2단계 : DB에 전송할 BoardDTO 객체 생성.
		//        파라미터로 받은 데이터들을 setter() 메서드의
		//        인자로 넘겨줌.
		BoardDTO dto = new BoardDTO();
		
		dto.setBoard_writer(board_writer);
		
		dto.setBoard_title(board_title);
		
		dto.setBoard_cont(board_content);
		
		dto.setBoard_pwd(board_pwd);
		
		
		// 3단계 : BoardDTO 객체를 DB에 넘겨주어
		//        board 테이블에 게시글을 저장시켜 주면 됨.
		BoardDAO dao = BoardDAO.getInstance();
		
		int res = dao.insertBoard(dto);
		
		PrintWriter out = response.getWriter();
		
		if(res > 0) {
			out.println("<script>");
			out.println("alert('게시글 등록 성공!!!')");
			out.println("location.href='board_list.go'");
			out.println("</script>");
		}else {
			out.println("<script>");
			out.println("alert('게시글 등록 실패~~~')");
			out.println("history.back()");
			out.println("</script>");
		}
		
		
	}

}
