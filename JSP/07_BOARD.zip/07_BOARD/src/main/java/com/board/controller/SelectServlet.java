package com.board.controller;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.util.List;

import com.board.model.BoardDAO;
import com.board.model.BoardDTO;


@WebServlet("/board_list.go")
public class SelectServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
   
    public SelectServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	
	protected void service(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// 요청 : 전체 게시물 목록을 보여달라고 요청.
		// 응답 : 전체 게시물 목록을 board 테이블에서 조회하여
		//       view page로 이동시키는 비지니스 로직.
		
		BoardDAO dao = BoardDAO.getInstance();
		
		// 전체 게시물 목록을 조회하는 메서드 호출.
		List<BoardDTO> boardList = dao.getBoardList();
		
		// view page로 이동시키기 위해서 바인딩 작업 진행.
		request.setAttribute("List", boardList);
		
		// view page로 페이지 이동 작업 진행.
		request.getRequestDispatcher("board_list.jsp")
			.forward(request, response);
		
	}

}
