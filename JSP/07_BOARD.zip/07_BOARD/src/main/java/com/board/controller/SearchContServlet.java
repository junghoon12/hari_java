package com.board.controller;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.io.IOException;

import com.board.model.BoardDAO;
import com.board.model.BoardDTO;


@WebServlet("/board_search_cont.go")
public class SearchContServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    
    public SearchContServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	
	protected void service(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// get 방식으로 넘어온 검색 게시물 번호에 해당하는 게시물을
		// DB 에서 조회하여 상세 페이지(view page)로 이동시키는 비지니스 로직.
		int search_no = 
			Integer.parseInt(request.getParameter("no").trim());
		
		String search_field = request.getParameter("field").trim();
		
		String search_keyword = request.getParameter("keyword").trim();
		
		
		BoardDAO dao = BoardDAO.getInstance();
		
		BoardDTO cont = dao.contentBoard(search_no);
		
		request.setAttribute("Content", cont);
		request.setAttribute("Field", search_field);
		request.setAttribute("Keyword", search_keyword);
		
		request.getRequestDispatcher("board_search_cont.jsp")
				.forward(request, response);
			
		
	}

}
