package model;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

/*
 * DAO(Data Access Object)
 * - 데이터 접근 객체 ==> DB 에 접속(연동)하는 객체.
 * - DAO란 데이터베이스에 접속해서 데이터를 추가, 수정,
 *   삭제, 조회 등의 작업을 하는 클래스.
 * - 일반적으로 JSP 또는 Servlet 에서 위의 작업들을
 *   같이 사용할 수도 있지만, 중복 코드 발생 및 유지보수,
 *   코드의 모듈화 등을 위해서 일반적으로 DAO 클래스를
 *   따로 만들어서 사용을 함.  
 */

public class MemberDAO {

	// DB와 연동하는 객체.
	Connection con = null;
	
	// DB에 SQL문을 전송하는 객체.
	PreparedStatement pstmt = null;
	
	// SQL문을 실행한 후에 결과값을 가지고 있는 객체.
	ResultSet rs = null;
	
	// SQL문을 저장할 문자열 변수.
	String sql = null;
	
	public MemberDAO() {  // 기본 생성자
	
		String driver = "oracle.jdbc.driver.OracleDriver";
		
		String url = "jdbc:oracle:thin:@localhost:1521:xe";
		
		String user = "basic";
		
		String password = "1234";
		
		
		try {
			// 1단계 : 오라클 드라이버를 메모리로 로딩.
			Class.forName(driver);
			
			// 2단계 : 오라클 데이터베이스와 연동 작업 진행.
			con = DriverManager.getConnection(url, user, password);
			
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}
	
	
	// member10 테이블에서 회원 전체 목록을 조회하는 메서드.
	public List<MemberDTO> getMemberList() {
		
		List<MemberDTO> list = new ArrayList<MemberDTO>();
		
		try {
			// 3단계 : 데이터베이스에 전송할 SQL문 작성
			sql = "select * from member10 order by num desc";
			
			pstmt = con.prepareStatement(sql);
			
			// 4단계 : SQL문을 데이터베이스에 전송 및 실행.
			rs = pstmt.executeQuery();
			
			while(rs.next()) {
				
				MemberDTO dto = new MemberDTO();
				
				dto.setNum(rs.getInt("num"));
				dto.setMemid(rs.getString("memid"));
				dto.setMemname(rs.getString("memname"));
				dto.setPwd(rs.getString("pwd"));
				dto.setAge(rs.getInt("age"));
				dto.setMileage(rs.getInt("mileage"));
				dto.setJob(rs.getString("job"));
				dto.setAddr(rs.getString("addr"));
				dto.setRegdate(rs.getString("regdate"));
				
				list.add(dto);
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} finally {
			try {
				// 5단계 : 데이터베이스와 연결되어 있던 자원 종료하기.
				if(rs != null) rs.close();
				if(pstmt != null) pstmt.close();
				if(con != null) con.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		
		return list;
	}  // getMemberList() 메서드 end
	
	
	// member10 테이블에 회원을 추가해 주는 메서드.
	public int insertMember(MemberDTO dto) {
		
		int result = 0, count = 0;
		
		
		try {
			// 3단계 : 데이터베이스에 전송할 SQL문 작성
			sql = "select max(num) from member10";
			
			pstmt = con.prepareStatement(sql);
			
			// 4단계 : SQL문을 데이터베이스에 전송 및 실행.
			rs = pstmt.executeQuery();
			
			if(rs.next()) {
				count = rs.getInt(1);
			}
			
			// 3단계 : 데이터베이스에 전송할 SQL문 작성
			sql = "insert into member10 "
					+ " values(?, ?, ?, ?, ?, ?, ?, ?, sysdate)";
			
			pstmt = con.prepareStatement(sql);
			
			pstmt.setInt(1, count + 1);
			pstmt.setString(2, dto.getMemid());
			pstmt.setString(3, dto.getMemname());
			pstmt.setString(4, dto.getPwd());
			pstmt.setInt(5, dto.getAge());
			pstmt.setInt(6, dto.getMileage());
			pstmt.setString(7, dto.getJob());
			pstmt.setString(8, dto.getAddr());
			
			// 4단계 : SQL문을 데이터베이스에 전송 및 실행.
			result = pstmt.executeUpdate();
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} finally {
			try {
				// 5단계 : 데이터베이스와 연결되어 있던 자원 종료하기.
				if(rs != null) rs.close();
				if(pstmt != null) pstmt.close();
				if(con != null) con.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		
		return result;
	}  // insertMember() 메서드 end
	
	
	// 회원 번호에 해당하는 회원의 정보를 조회하는 메서드.
	public MemberDTO getMember(int no) {
		
		MemberDTO dto = null;
		
		
		try {
			// 3단계 : 데이터베이스에 전송할 SQL문 작성.
			sql = "select * from member10 where num = ?";
			
			pstmt = con.prepareStatement(sql);
			
			pstmt.setInt(1, no);
			
			// 4단계 : SQL문을 데이터베이스에 전송 및 실행
			rs = pstmt.executeQuery();
			
			if(rs.next()) {
				
				dto = new MemberDTO();
				
				dto.setNum(rs.getInt("num"));
				dto.setMemid(rs.getString("memid"));
				dto.setMemname(rs.getString("memname"));
				dto.setPwd(rs.getString("pwd"));
				dto.setAge(rs.getInt("age"));
				dto.setMileage(rs.getInt("mileage"));
				dto.setJob(rs.getString("job"));
				dto.setAddr(rs.getString("addr"));
				dto.setRegdate(rs.getString("regdate"));
				
			}
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} finally {
			try {
				// 5단계 : 데이터베이스와 연결되어 있던 자원 종료하기.
				if(rs != null) rs.close();
				if(pstmt != null) pstmt.close();
				// if(con != null) con.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		
		return dto;
	}  // getMember() 메서드 end
	
	
	// 회원 번호에 해당하는 회원의 정보를 수정하는 메서드.
	public int updateMember(MemberDTO dto) {
		
		int result = 0;
		
		
		try {
			// 3단계 : 데이터베이스에 전송할 SQL문 작성.
			sql = "update member10 set age = ?, "
					+ " mileage = ?, job = ?, "
					+ " addr = ? where num = ?";
			
			// 4단계 : SQL문을 데이터베이스 전송 객체의 인자로 전달.
			pstmt = con.prepareStatement(sql);
			
			pstmt.setInt(1, dto.getAge());
			pstmt.setInt(2, dto.getMileage());
			pstmt.setString(3, dto.getJob());
			pstmt.setString(4, dto.getAddr());
			pstmt.setInt(5, dto.getNum());
			
			// 5단계 : SQL문을 데이터베이스에 전송 및 실행.
			result = pstmt.executeUpdate();
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} finally {
			try {
				// 6단계 : 데이터베이스와 연결되어 있던 자원 종료하기.
				if(pstmt != null) pstmt.close();
				if(con != null) con.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		
		return result;
	}  // updateMember() 메서드 end
	
	
	// 회원 번호에 해당하는 회원을 테이블에서 삭제하는 메서드.
	public int deleteMember(int no) {
		
		int result = 0;
		
		
		try {
			// 3단계 : 데이터베이스에 전송할 SQL문 작성.
			sql = "delete from member10 where num = ?";
			
			// 4단계 : SQL문을 데이터베이스 전송 객체에 인자로 전달.
			pstmt = con.prepareStatement(sql);
			
			pstmt.setInt(1, no);
			
			// 5단계 : SQL문을 데이터베이스에 전송 및 실행.
			result = pstmt.executeUpdate();
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} finally {
			try {
				// 6단계 : 데이터베이스와 연결되어 있던 자원 종료하기.
				if(pstmt != null) pstmt.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		
		return result;
	}  // deleteMember() 메서드 end
	
	
	// 회원 번호를 재작업 해 주는 메서드.
	public void updateSequence(int no) {
		
		
		try {
			// 3단계 : 데이터베이스에 전송할 SQL문 작성.
			sql = "update member10 set "
					+ " num = num - 1 where num > ?";
			
			// 4단계 : SQL문을 데이터베이스 전송 객체에 인자로 전달
			pstmt = con.prepareStatement(sql);
			
			pstmt.setInt(1, no);
			
			// 5단계 : SQL문을 데이터베이스에 전송 및 실행.
			pstmt.executeUpdate();
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} finally {
			try {
				// 6단계 : 데이터베이스와 연결되어 있던 자원 종료하기.
				if(pstmt != null) pstmt.close();
				if(con != null) con.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		
	}  // updateSequence() 메서드 end
	
	// 검색어에 해당하는 회원을 조회하는 메서드.
	public List<MemberDTO> searchMemberList(
			String field, String keyword) {
		
		List<MemberDTO> searchList = new ArrayList<MemberDTO>();
		
		
		try {
			// 3단계 : 데이터베이스에 전송할 SQL문 작성.
			sql = "select * from member10 ";
			
			if(field.equals("id")) {
				sql += " where memid like ? ";
			}else if(field.equals("name")) {
				sql += " where memname like ? ";
			}else if(field.equals("job")) {
				sql += " where job like ? ";
			}else {
				sql += " where addr like ? ";
			}
			
			sql += " order by num desc";
			
			// 4단계 : SQL문을 데이터베이스 전송 객체의 인자로 전달.
			pstmt = con.prepareStatement(sql);
			
			pstmt.setString(1, "%"+keyword+"%");
			
			// 5단계 : SQL문을 데이터베이스에 전송 및 실행.
			rs = pstmt.executeQuery();
			
			while(rs.next()) {
				
				MemberDTO dto = new MemberDTO();
				
				dto.setNum(rs.getInt("num"));
				dto.setMemid(rs.getString("memid"));
				dto.setMemname(rs.getString("memname"));
				dto.setPwd(rs.getString("pwd"));
				dto.setAge(rs.getInt("age"));
				dto.setMileage(rs.getInt("mileage"));
				dto.setJob(rs.getString("job"));
				dto.setAddr(rs.getString("addr"));
				dto.setRegdate(rs.getString("regdate"));
				
				searchList.add(dto);
			}
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} finally {
			try {
				// 6단계 : 데이터베이스와 연결되어 있던 자원 종료하기.
				if(rs != null) rs.close();
				if(pstmt != null) pstmt.close();
				if(con != null) con.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		
		return searchList;
	}  // searchMemberList() 메서드 end
	
	
	
	
	
	
	
	
	
	
}
