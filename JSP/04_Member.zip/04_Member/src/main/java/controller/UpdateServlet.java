package controller;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import model.MemberDAO;
import model.MemberDTO;


@WebServlet("/update.go")
public class UpdateServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
   
    public UpdateServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	
	protected void service(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// get 방식으로 넘어온 회원 번호에 해당하는 회원의 정보를
		// DB에서 조회하여 수정 폼 페이지(view page)로 이동시키는
		// 비지니스 로직.
		
		int member_no = 
			Integer.parseInt(request.getParameter("no").trim());
		
		// 1단계 : 데이터베이스와 연동 작업 진행.
		MemberDAO dao = new MemberDAO();
		
		// 2단계 : 회원 번호에 해당하는 회원의 상세정보를 조회.
		MemberDTO content = dao.getMember(member_no);
		
		request.setAttribute("Modify", content);
		
		request.getRequestDispatcher("view/member_modify.jsp")
			.forward(request, response);
		
	}

}
