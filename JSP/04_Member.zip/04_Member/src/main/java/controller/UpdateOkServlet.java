package controller;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import model.MemberDAO;
import model.MemberDTO;


@WebServlet("/modify_ok.go")
public class UpdateOkServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
   
    public UpdateOkServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	
	protected void service(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// 수정 폼 페이지에서 넘어온 글번호에 해당하는 데이터들을
		// DB에 수정시키는 비지니스 로직.
		
		// 한글 깨짐 방지 설정 작업.
		request.setCharacterEncoding("UTF-8");
		response.setContentType("text/html; charset=UTF-8");
		
		// 1단계 : 수정 폼 페이지에서 넘어온 데이터들을 받아 주어야 한다.
		int member_num = 
			Integer.parseInt(request.getParameter("mem_num").trim());
		String member_id = request.getParameter("mem_id").trim();
		String member_name = request.getParameter("mem_name").trim();
		String member_pwd = request.getParameter("mem_pwd").trim();
		int member_age = 
			Integer.parseInt(request.getParameter("mem_age").trim());
		int member_mileage = 
			Integer.parseInt(request.getParameter("mem_mileage").trim());
		String member_job = request.getParameter("mem_job").trim();
		String member_addr = request.getParameter("mem_addr").trim();
		
		// 2단계 : 1단계에서 넘어온 데이터들을 DTO 객체에 저장을 하자.
		MemberDTO dto = new MemberDTO();
		
		dto.setNum(member_num);
		dto.setMemid(member_id);
		dto.setMemname(member_name);
		dto.setPwd(member_pwd);
		dto.setAge(member_age);
		dto.setMileage(member_mileage);
		dto.setJob(member_job);
		dto.setAddr(member_addr);
		
		// 3단계 : 데이터베이스에 저장하는 메서드 호출.
		MemberDAO dao = new MemberDAO();
		
		MemberDTO cont = dao.getMember(member_num);
		
		PrintWriter out = response.getWriter();
		
		if(member_pwd.equals(cont.getPwd())) {
			
			int check = dao.updateMember(dto);
			
			if(check > 0) {
				out.println("<script>");
				out.println("alert('회원 정보 수정 성공!!!')");
				out.println("location.href='content.go?no="+member_num+"'");
				out.println("</script>");
			}else {
				out.println("<script>");
				out.println("alert('회원 정보 수정 실패~~~')");
				out.println("history.back()");
				out.println("</script>");
			}
			
		}else {
			// 비밀번호가 틀린 경우
			out.println("<script>");
			out.println("alert('비밀번호가 틀립니다. 확인해 주세여~~~')");
			out.println("history.back()");
			out.println("</script>");
		}
		
		
	}

}
