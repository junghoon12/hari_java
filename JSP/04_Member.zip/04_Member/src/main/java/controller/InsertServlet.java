package controller;

import java.awt.print.Printable;
import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import model.MemberDAO;
import model.MemberDTO;


@WebServlet("/insert_ok.go")
public class InsertServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
   
    public InsertServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	
	protected void service(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// 요청 : member10 테이블에 입력폼 페이지에서 넘어온
		//       데이터들을 저장하는 요청.
		// 응답 : 입력폼 페이지에서 넘어온 데이터들을 DB에 저장하는 
		//       비지니스 로직.
		
		// 한글 깨짐 방지 작업 설정
		request.setCharacterEncoding("UTF-8");
		response.setContentType("text/html; charset=UTF-8");
		
		// 1단계 : 회원 등록 폼 페이지에서 넘어온 데이터들을 받아 주어야 한다.
		String member_id = request.getParameter("id").trim();
		
		String member_name = request.getParameter("name").trim();
		
		String member_pwd = request.getParameter("pwd").trim();
		
		int member_age = 
			Integer.parseInt(request.getParameter("age").trim());
		
		int member_mileage =
			Integer.parseInt(request.getParameter("mileage").trim());
		
		String member_job = request.getParameter("job").trim();
		
		String member_addr = request.getParameter("addr").trim();
		
		// 2단계 : DB에 전송할 DTO 객체의 setter() 메서드의 인자로
		//        파라미터로 넘어온 데이터들을 저장해 준다.
		MemberDTO dto = new MemberDTO();
		
		dto.setMemid(member_id);
		dto.setMemname(member_name);
		dto.setPwd(member_pwd);
		dto.setAge(member_age);
		dto.setMileage(member_mileage);
		dto.setJob(member_job);
		dto.setAddr(member_addr);
		
		// 3단계 : DAO 객체를 생성하여 DB와 연결 작업을 진행한다.
		MemberDAO dao = new MemberDAO();
		
		// 4단계 : DAO 객체 의 메서드 호출 시 인자로 DTO 객체를 넘겨준다.
		int check = dao.insertMember(dto);
		
		PrintWriter out = response.getWriter();
		
		if(check > 0) {
			out.println("<script>");
			out.println("alert('회원 등록 성공!!!')");
			out.println("location.href='select.go'");
			out.println("</script>");
		}else {
			out.println("<script>");
			out.println("alert('회원 등록 실패~~~')");
			out.println("history.back()");
			out.println("</script>");
		}
		
	}

}
