package com.member.action;

import java.util.List;

import com.member.model.MemberDAO;
import com.member.model.MemberDTO;

import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

public class MemberListAction implements Action {

	@Override
	public String execute(HttpServletRequest request, HttpServletResponse response) {
		// 요청 : 전체 회원 목록을 보여달라고 요청.
		// 응답 : member 테이블에서 전체 회원 목록을 조회하여
		//       view page로 이동시키는 비지니스 로직.
		
		MemberDAO dao = MemberDAO.getInstance();
		
		List<MemberDTO> memberList = dao.getMemberList();
		
		// member 테이블에서 가져온 전체 회원 목록을
		// view page로 이동시켜 주면 됨. ==> 바인딩 작업.
		request.setAttribute("List", memberList);
		
		return "member_list.jsp";
	}

}
