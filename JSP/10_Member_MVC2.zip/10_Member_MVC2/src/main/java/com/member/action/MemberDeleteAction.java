package com.member.action;

import java.io.IOException;

import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;



public class MemberDeleteAction implements Action {

	@Override
	public String execute(HttpServletRequest request, HttpServletResponse response) throws IOException {
		// get 방식으로 넘어온 회원번호를 받아서 회원 삭제
		// 폼 페이지로 이동시키는 비지니스 로직.
		
		int member_no = 
				Integer.parseInt(request.getParameter("no"));
		
		request.setAttribute("No", member_no);
		
		return "member_delete.jsp";
		
	}

}
