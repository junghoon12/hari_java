package goott.controller;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import goott.model.StudentDAO;
import goott.model.StudentDTO;


@WebServlet("/update")
public class UpdateServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    
    public UpdateServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	
	protected void service(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// get 방식으로 넘어온 학번에 해당하는 학생의
		// 정보를 view page로 이동시키는 비지니스 로직
		
		String hakbun = request.getParameter("no").trim();
		
		StudentDAO dao = new StudentDAO();
		
		StudentDTO cont = dao.getStudent(hakbun);
		
		request.setAttribute("Content", cont);
		
		RequestDispatcher rd = 
				request.getRequestDispatcher("view/student_update.jsp");
		
		rd.forward(request, response);
		
	}

}
