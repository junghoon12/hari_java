package goott.controller;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import goott.model.StudentDAO;
import goott.model.StudentDTO;

/**
 * Servlet implementation class UpdateOkServlet
 */
@WebServlet("/student_update_ok")
public class UpdateOkServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public UpdateOkServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#service(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void service(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// 수정 폼 페이지에서 넘어온 데이터들을 
		// DB에 저장하는 비지니스 로직
		
		// 요청과 응답에 한글 깨짐 방지 설정 작업
		request.setCharacterEncoding("UTF-8");
		response.setContentType("text/html; charset=UTF-8");
		
		// 1단계 : 수정 폼 페이지에서 넘어온 데이터들을 받아 주어야 한다.
		String student_hakbun = request.getParameter("hakbun").trim();
		
		String student_name = request.getParameter("name").trim();
		
		String student_major = request.getParameter("major").trim();
		
		String student_phone = request.getParameter("phone").trim();
		
		String student_addr = request.getParameter("addr").trim();
		
		// 2단계 : 데이터베이스에 전송할 DTO 객체의 
		//        setter 메서드에 수정 폼에서 넘어온 정보들을
		//        인자로 넘겨 주자.
		StudentDTO dto = new StudentDTO();
		
		dto.setHakbun(student_hakbun);
		dto.setName1(student_name);
		dto.setMajor(student_major);
		dto.setPhone(student_phone);
		dto.setAddr(student_addr);
		
		// 3단계 : DTO 객체를 DB에 전송
		StudentDAO dao = new StudentDAO();
		
		int check = dao.updateStudent(dto);
		
		PrintWriter out = response.getWriter();
		
		if(check > 0) {
			out.println("<script>");
			out.println("alert('학생 정보 수정 성공!!!')");
			out.println("location.href='select'");
			out.println("</script>");
		}else {
			out.println("<script>");
			out.println("alert('학생 정보 수정 실패~~~')");
			out.println("history.back()");
			out.println("</script>");
		}
		
		
		
		
	}

}
