package goott.model;

// DB의 student 테이블의 컬럼명과 동일하게
// 멈버변수 구성하는게 좋음.

public class StudentDTO {

	private String hakbun;
	private String name1;
	private String major;
	private String phone;
	private String addr;
	private String regdate;
	
	
	public String getHakbun() {
		return hakbun;
	}
	
	public void setHakbun(String hakbun) {
		this.hakbun = hakbun;
	}
	
	public String getName1() {
		return name1;
	}
	
	public void setName1(String name1) {
		this.name1 = name1;
	}
	
	public String getMajor() {
		return major;
	}
	
	public void setMajor(String major) {
		this.major = major;
	}
	
	public String getPhone() {
		return phone;
	}
	
	public void setPhone(String phone) {
		this.phone = phone;
	}
	
	public String getAddr() {
		return addr;
	}
	
	public void setAddr(String addr) {
		this.addr = addr;
	}
	
	public String getRegdate() {
		return regdate;
	}
	
	public void setRegdate(String regdate) {
		this.regdate = regdate;
	}
	
	
}
