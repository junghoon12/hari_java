package controller;

import java.io.IOException;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import model.EmpDAO;
import model.EmpDTO;


@WebServlet("/select")
public class SelactAllServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    
    public SelactAllServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	
	protected void service(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// 요청 : 전체 사원 목록을 화면에 보여달라고 요청.
		// 응답 : DB의 EMP 테이블에 있는 전체 사원 목록을
		//       view page로 이동시키는 비지니스 로직.
		
		// 1단계 : DAO 클래스 싱글턴 방식으로 객체 생성 작업 진행.
		EmpDAO dao = EmpDAO.getInstance();
		System.out.println("select dao >>> " + dao);
		
		// 2단계 : DB에서 EMP 테이블의 전체 사원 목록 조회하는 메서드 호출.
		List<EmpDTO> empList = dao.getEmpList();
		
		// 3단계 : 페이지 이동 시 정보(데이터)를 넘겨 주어야 함.
		request.setAttribute("List", empList);
		
		// 4단계 : 이동할 페이지 경로 설정 및 페이지 이동.
		request.getRequestDispatcher("views/emp_list.jsp")
				.forward(request, response);
		
		
	}

}
