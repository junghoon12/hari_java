package controller;

import java.io.IOException;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import model.DeptDTO;
import model.EmpDAO;
import model.EmpDTO;


@WebServlet("/update")
public class UpdateServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
   
    public UpdateServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	
	protected void service(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// get 방식으로 넘어온 사원 번호에 해당하는 사원의 정보를
		// DB에서 조회하여 view page(수정 폼 페이지)로 이동시키는 비지니스 로직.
		
		int emp_no =  
			Integer.parseInt(request.getParameter("no").trim());
		
		EmpDAO dao = EmpDAO.getInstance();
		
		// 1. EMP 테이블에서 담당업무 리스트를 조회하여 보자.
		List<String> jobList = dao.getJobList();
		
		// 2. EMP 테이블에서 관리자 사원 리스트를 조회하여 보자.
		List<EmpDTO> mgrList = dao.getMgrList();
		
		// 3. DEPT 테이블에서 부서 번호 전체 리스트를 조회하여 보자.
		List<DeptDTO> deptList = dao.getDeptList();
		
		// 4. 사원번호에 해당하는 사원의 상세 정보를 조회하여 보자.
		EmpDTO content = dao.contentEmp(emp_no);
		
		// 모든 정보를 view page(수정 폼 페이지)로 이동을 시키자.
		request.setAttribute("jList", jobList);
		request.setAttribute("mList", mgrList);
		request.setAttribute("dList", deptList);
		request.setAttribute("Cont", content);
		
		// 이동 경로 설정 및 이동 진행.
		request.getRequestDispatcher("views/emp_modify.jsp")
				.forward(request, response);
		
	}

}
