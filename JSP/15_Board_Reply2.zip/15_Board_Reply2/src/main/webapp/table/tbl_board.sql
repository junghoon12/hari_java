-- tbl_board 테이블 생성

create table tbl_board(
	bno number primary key,              -- 게시판 글 번호.
	writer varchar2(50) not null,        -- 게시판 글 작성자.
	title varchar2(200) not null,        -- 게시판 글 제목.
	cont varchar2(1000) not null,        -- 게시판 글 내용.
	pwd varchar2(50) not null,           -- 게시판 글 비밀번호.
	hit number default 0,                -- 게시판 글 조회수.
	regdate date not null,               -- 게시판 글 작성일자.
	regupdate date                       -- 게시판 글 수정일자.
);

-- tbl_board 테이블에 게스글을 추가해 보자.
insert into tbl_board 
		values(1, '홍길동', '제목1', '길동이 글', '1111', 
				default, sysdate, '');

insert into tbl_board 
		values(2, '세종대왕', '왕이요', '한글', '2222', 
				default, sysdate, '');
				
insert into tbl_board 
		values(3, '유관순', '독립 글', '대한독립만세!!!', '3333', 
				default, sysdate, '');