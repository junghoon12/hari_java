package com.reply2.model;

public class ReplyDTO {

	private int rno;
	private int bno;
	private String rewriter;
	private String recont;
	private String redate;
	private String reupdate;
	
	
	
	public int getRno() {
		return rno;
	}
	
	public void setRno(int rno) {
		this.rno = rno;
	}
	
	public int getBno() {
		return bno;
	}
	
	public void setBno(int bno) {
		this.bno = bno;
	}
	
	public String getRewriter() {
		return rewriter;
	}
	
	public void setRewriter(String rewriter) {
		this.rewriter = rewriter;
	}
	
	public String getRecont() {
		return recont;
	}
	
	public void setRecont(String recont) {
		this.recont = recont;
	}
	
	public String getRedate() {
		return redate;
	}
	
	public void setRedate(String redate) {
		this.redate = redate;
	}
	
	public String getReupdate() {
		return reupdate;
	}
	
	public void setReupdate(String reupdate) {
		this.reupdate = reupdate;
	}
	
	
}
