package com.dept.model;

import java.sql.*;
import java.util.ArrayList;

public class DeptDAO {

	// DB와 연동하는 객체.
	Connection con = null;
	
	// DB에 SQL문을 전송하는 객체.
	PreparedStatement pstmt = null;
	
	// SQL문을 실행 한 후에 결과 값을 가지고 있는 객체.
	ResultSet rs = null;
	
	// 쿼리문을 저장할 변수.
	String sql = null;
	
	public DeptDAO() {  // 기본 생성자.
		
		String driver = 
				"oracle.jdbc.driver.OracleDriver";
		
		String url =
				"jdbc:oracle:thin:@localhost:1521:xe";
		
		String user = "web";
		
		String password = "1234";
		
		
		try {
			// 1단계 : 오라클 드라이버를 메모리로 로딩 작업 진행.
			Class.forName(driver);
			
			// 2단계 : 오라클 데이터베이스와 연결 작업 진행.
			con = DriverManager.getConnection(url, user, password);
		
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}  // 기본 생성자 end
	

	// DEPT 테이블에서 부서 목록 전체 리스트를 조회하는 메서드.
	public ArrayList<DeptDTO> deptList() {
		
		ArrayList<DeptDTO> list = 
					new ArrayList<DeptDTO>();
		
		try {
			// 3단계 : 데이터베이스에 전송할 SQL문을 작성.
			sql = "select * from dept order by deptno";
			
			// 4단계 : SQL문을 데이터베이스의 전송 객체에 저장.
			pstmt = con.prepareStatement(sql);
			
			// 5단계 : SQL문을 데이터베이스에 전송 및 실행.
			rs = pstmt.executeQuery();
			
			while(rs.next()) {
				DeptDTO dto = new DeptDTO();
				
				dto.setDeptno(rs.getInt("deptno"));
				dto.setDname(rs.getString("dname"));
				dto.setLocation(rs.getString("loc"));
				
				list.add(dto);
			}
			
			// 6단계 : DB와 연결되어 있던 자원 종료하기
			rs.close(); pstmt.close(); con.close();
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	
		return list;
	}  // deptList() 메서드 end
	
	
	// DEPT 테이블에 부서를 추가하는 메서드.
	public int insertDept(DeptDTO dto) {
		
		int result = 0;
		
		
		try {
			// 3단계 : 데이터베이스에 전송할 SQL문을 작성.
			sql = "insert into dept values(?, ?, ?)";
			
			// 4단계 : SQL문을 데이터베이스의 전송 객체에 저장.
			pstmt = con.prepareStatement(sql);
			
			// 4-1 : ?(플레이스 홀더)에 데이터 배정.
			pstmt.setInt(1, dto.getDeptno());
			pstmt.setString(2, dto.getDname());
			pstmt.setString(3, dto.getLocation());
			
			// 5단계 : SQL문을 데이터베이스에 전송 및 실행.
			result = pstmt.executeUpdate();
			
			// 6단계 : DB에 연결되어 있던 자원 종료하기
			pstmt.close(); con.close();
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		return result;
	}  // insertDept() 메서드 end
	
	
	// 부서번호에 해당하는 부서의 정보를 조회하는 메서드.
	public DeptDTO getDept(int no) {
		
		DeptDTO dto = null;
		
		try {
			// 3단계 : 데이터베이스에 전송할 SQL문을 작성.
			sql = "select * from dept "
					+ "	where deptno = ?";
			
			// 4단계 : SQL문을 데이터베이스의 전송 객체에 저장.
			pstmt = con.prepareStatement(sql);
			
			// 4-1 : ?(플레이스 홀더)에 데이터 배정.
			pstmt.setInt(1, no);
			
			// 5단계 : SQL문을 데이터베이스에 전송 및 실행.
			rs = pstmt.executeQuery();
			
			while(rs.next()) {
				dto = new DeptDTO();
				
				dto.setDeptno(rs.getInt("deptno"));
				dto.setDname(rs.getString("dname"));
				dto.setLocation(rs.getString("loc"));
				
			}
			
			// 6단계 : DB와 연결되어 있던 자원 종료하기
			rs.close(); pstmt.close(); con.close();
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		return dto;
	}  // getDept() 메서드 end
	
	
	// DB에 수정된 부서 정보를 저장하는 메서드.
	public int updateDept(DeptDTO dto) {
		
		int result = 0;
		
		try {
			// 3단계 : 데이터베이스에 전송할 SQL문을 작성.
			sql = "update dept set dname = ?, "
					+ " loc = ? where deptno = ? ";
			
			// 4단계 : SQL문을 데이터베이스의 전송 객체에 저장.
			pstmt = con.prepareStatement(sql);
			
			// 4-1 : ?(플레이스 홀더)에 데이터 배정.
			pstmt.setString(1, dto.getDname());
			pstmt.setString(2, dto.getLocation());
			pstmt.setInt(3, dto.getDeptno());
			
			// 5단계 : SQL문을 데이터베이스에 전송 및 실행.
			result = pstmt.executeUpdate();
			
			// 6단계 : DB와 연결되어 있던 자원 종료하기
			pstmt.close(); con.close();
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		return result;
	}  // updateDept() 메서드 end
	
	
	// get 방식으로 넘어온 부서번호에 해당하는 부서를 삭제하는 메서드.
	public int deleteDept(int no) {
		
		int result = 0;
		
		
		try {
			// 3단계 : 데이터베이스에 전송할 SQL문을 작성.
			sql = "delete from dept "
						+ "	where deptno = ?";
			
			// 4단계 : SQL문을 데이터베이스의 전송 객체에 저장.
			pstmt = con.prepareStatement(sql);
			
			// 4-1 : ?(플레이스 홀더)에 데이터 배정.
			pstmt.setInt(1, no);
			
			// 5단계 : SQL문을 데이터베이스에 전송 및 실행.
			result = pstmt.executeUpdate();
			
			// 6단계 : DB와 연결되어 있던 자원 종료하기
			pstmt.close(); con.close();

		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		return result;
	}  // deleteDept() 메서드 end
	
	
	
	
	
	
	
	
}
