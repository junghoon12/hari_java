package com.dept.controller;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.dept.model.DeptDAO;


@WebServlet("/delete")
public class DeleteServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
   
    public DeleteServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	
	protected void service(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// 삭제 버튼을 누르면  get방식으로 넘어온
		// 부서번호를 가지고 DB에서 해당 부서번호를
		// 삭제하는 비지니스 로직.
		
		response.setContentType("text/html; charset=UTF-8");
		
		// 1단계 : get 방식으로 넘어온 부서번호를 받아 주어야 한다.
		int deptno = 
			Integer.parseInt(request.getParameter("no").trim());
		
		// 2단계 : 삭제할 부서번호를 DB에 전송하여 해당 부서를 삭제해야 한다.
		DeptDAO dao = new DeptDAO();
		
		int check = dao.deleteDept(deptno);
		
		PrintWriter out = response.getWriter();
		
		if(check > 0) {
			out.println("<script>");
			out.println("alert('부서 삭제 성공!!!')");
			out.println("location.href='list'");
			out.println("</script>");
		}else {
			out.println("<script>");
			out.println("alert('부서 삭제 실패~~~')");
			out.println("history.back()");
			out.println("</script>");
		}
		
		
		
	}

}
