-- shop_cart 테이블 생성

create table shop_cart(
	cart_num number(5) primary key,      -- 장바구니 번호
	cart_pnum number(5) not null,        -- 장바구니 제품 번호
	cart_user_id varchar2(50) not null,  -- 장바구니 사용자 아이디
	cart_pname varchar2(100) not null,   -- 장바구니 상품 이름
	cart_pqty number(5) not null,        -- 장바구니 상품 수량
	cart_price number(8) not null,       -- 장바구니 상품 가격
	cart_pspec varchar2(50) not null,    -- 장바구니 상품 스펙
	cart_pimage varchar2(500)            -- 장바구니 상품 이미지
);