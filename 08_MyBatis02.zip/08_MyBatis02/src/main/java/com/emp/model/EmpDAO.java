package com.emp.model;

import java.util.List;

public interface EmpDAO {

	List<EmpDTO> getEmpList();
	
	int isertEmp(EmpDTO dto);
	
	EmpDTO getEmp(int no);
	
	int updateEmp(EmpDTO dto);
	
	int deleteEmp(int no);
	
	List<DeptDTO> getDeptList();
	
	List<EmpDTO> getMgrList();
	
	List<String> getjobList();
}
