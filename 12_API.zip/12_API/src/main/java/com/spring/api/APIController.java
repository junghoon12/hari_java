package com.spring.api;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.UnsupportedEncodingException;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.net.URLEncoder;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

@Controller
public class APIController {

	private static final String serviceKey =
		"PbyyG6xVFfBRT0%2BUKogJNt3aNSriSnbSB4kHkambs%2Fnpjb7OxMHo%2B7IrpyjfvSjJE5APVeXwG4ooz4DkeHWezg%3D%3D";
	
	@ResponseBody
	@RequestMapping(value = "air.do", produces="application/json; charset=UTF-8")
	public String air(String location) throws IOException {
		
		String url = "http://apis.data.go.kr/B552584/ArpltnInforInqireSvc/getCtprvnRltmMesureDnsty";
		
		url += "?serviceKey=" + serviceKey;
		
		url += "&sidoName=" + URLEncoder.encode(location, "UTF-8");
		
		url += "&returnType=json";
		
		// URL을 통해서 서버와 통신할 때 단계
		// 1. URL 객체 만들기
		URL requestUrl = new URL(url);
		
		// 2. URL에서 URLConnection 객체 얻기
		HttpURLConnection urlConnection =
				(HttpURLConnection)requestUrl.openConnection();
		
		// 3. HttpURLConnection 구성 진행
		urlConnection.setRequestMethod("GET");
		
		BufferedReader br = 
				new BufferedReader
					(new InputStreamReader
							(urlConnection.getInputStream()));
		
		String responseText = "";
		
		String line;
		
		while((line = br.readLine()) != null) {
			responseText += line;
		}
		
		br.close();
		urlConnection.disconnect();	
		
		return responseText;
	}
}
