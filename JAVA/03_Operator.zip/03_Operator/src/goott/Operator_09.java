package goott;

import javax.swing.JOptionPane;

/*
 * [문제] 키보드로 두 수를 입력받아서 
 *       산술연산(덧셈, 뺄셈, 곱셈, 나눗셈, 나머지)을
 *       진행하여 콘솔 화면에 보여주세요.
 */

public class Operator_09 {

	public static void main(String[] args) {

		// 키보드로 입력하는 방법 - 첫번째
		// int su1 = Integer.parseInt(args[0]);
		// int su2 = Integer.parseInt(args[1]);
		
		// 키보드로 입력하는 방법 - 두번째
		int su1 = Integer.parseInt(JOptionPane.showInputDialog("첫번째 수 입력"));
		int su2 = Integer.parseInt(JOptionPane.showInputDialog("두번째 수 입력"));
		
		// 덧셈연산
		System.out.println("덧셈 결과 >>> " + (su1+su2));
		System.out.println();
		
		// 뺄셈연산
		System.out.println("뺄셈 결과 >>> " + (su1-su2));
		System.out.println();
		
		// 곱셈연산
		System.out.println("곱셈 결과 >>> " + (su1*su2));
		System.out.println();
		
		// 나눗셈연산
		System.out.println("나눗셈(몫) 결과 >>> " + (su1/su2));
		System.out.println();
		
		// 나머지연산
		System.out.println("나머지 결과 >>> " + (su1%su2));
		System.out.println();
	
	}

}
