package goott;

public class Operator_03 {

	public static void main(String[] args) {
		
		// 1. 키보드로 데이터를 입력받는 방법(두번째)
		int num1 = Integer.parseInt(args[0]);

		int num2 = Integer.parseInt(args[1]);
		
		// 덧셈연산
		System.out.println("덧셈연산 결과 >>> " + (num1 + num2));
		System.out.println();
		
		// 뺄셈연산
		System.out.println("뺄셈 결과 >>> " + (num1 - num2));
		System.out.println();  // 빈 줄 하나가 생김
		
		// 곱셈연산
		System.out.println("곱셈결과 >>> " + (num1 * num2));
		System.out.println();  // 빈 줄 하나가 생김
		
		// 나눗셈연산
		System.out.println("나눗셈결과(몫) >>> " + (num1 / num2));
		System.out.println();  // 빈 줄 하나가 생김
		
		// 나머지연산
		System.out.println("나머지 결과 >>> " + (num1 % num2));
		System.out.println();  // 빈 줄 하나가 생김

	}

}
