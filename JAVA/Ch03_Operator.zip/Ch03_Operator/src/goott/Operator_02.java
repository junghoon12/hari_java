package goott;

import javax.swing.JOptionPane;

public class Operator_02 {

	public static void main(String[] args) {
		
		// 1. 키보드로 데이터를 입력받는 방법(첫번째)
		int num1 = 
			Integer.parseInt(JOptionPane.showInputDialog("첫번째 숫자 입력하세요"));

		int num2 = 
				Integer.parseInt(JOptionPane.showInputDialog("두번째 숫자 입력하세요"));
		
		// 덧셈연산
		System.out.println("덧셈연산 결과 >>> " + (num1 + num2));
		System.out.println();
		
		// 뺄셈연산
		System.out.println("뺄셈 결과 >>> " + (num1 - num2));
		System.out.println();  // 빈 줄 하나가 생김
		
		// 곱셈연산
		System.out.println("곱셈결과 >>> " + (num1 * num2));
		System.out.println();  // 빈 줄 하나가 생김
		
		// 나눗셈연산
		System.out.println("나눗셈결과(몫) >>> " + (num1 / num2));
		System.out.println();  // 빈 줄 하나가 생김
		
		// 나머지연산
		System.out.println("나머지 결과 >>> " + (num1 % num2));
		System.out.println();  // 빈 줄 하나가 생김
	}

}
