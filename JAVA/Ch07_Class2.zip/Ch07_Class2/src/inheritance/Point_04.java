package inheritance;

public class Point_04 {

	public static void main(String[] args) {
		
		Point3D point = new Point3D(5, 3, 2);
		
		point.output();

	}

}
