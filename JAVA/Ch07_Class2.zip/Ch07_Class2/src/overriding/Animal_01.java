package overriding;

public class Animal_01 {

	public static void main(String[] args) {
	
		Dog dog = new Dog();
		
		dog.sound();

	}

}
