package polymorphism;

public class SmartTV extends TV {
	
	void AI() {  }         // 인공지능 기능

	void searching() {  }  // 검색 기능
	
}
