package polymorphism;

public class Car {

	// 멤버변수
	Tire tire;
	
	void run() {
		
		tire.roll();
	}
}
