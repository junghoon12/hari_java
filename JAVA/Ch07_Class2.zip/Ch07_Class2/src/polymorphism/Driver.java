package polymorphism;

public class Driver {

	void drive(Vehicle vehicle) {
		
		vehicle.run();
	}
}
