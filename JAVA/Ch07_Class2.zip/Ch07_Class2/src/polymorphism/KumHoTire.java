package polymorphism;

public class KumHoTire implements Tire {

	@Override
	public void roll() {
		
		System.out.println("금호 타이어가 회전을 합니다.");
	}

}
