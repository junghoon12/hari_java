package polymorphism;

public interface Tire {

	// 멤버메서드
	void roll();
	
}
