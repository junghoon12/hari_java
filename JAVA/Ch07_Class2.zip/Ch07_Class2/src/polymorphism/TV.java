package polymorphism;

public class TV {

	void powerOn() {  }    // 전원 켜기
	
	void powerOff() {  }   // 전원 끄기
	
	void volumeOn() {  }   // 볼륨 켜기
	
	void volumeOff() {  }   // 볼륨 끄기
	
	void channelUp() {  }   // 채널 올리기
	
	void channelDown() {  }   // 채널 내리기
	
	
}
