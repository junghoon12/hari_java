package polymorphism;

public interface Vehicle {

	void run();
}
