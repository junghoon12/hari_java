package exam;

public class Permanent extends Employee {

	// 멤버변수
	// String name;
	int pay;            // 기본 급여
	int bonus;          // 보너스
	
	public Permanent() { }  // 기본 생성자
	
	public Permanent(String name, int pay, int bonus) {
		
		this.name = name;
		this.pay = pay;
		this.bonus = bonus;
		
	}  // 인자 생성자

	public int getPay() {
		return pay;
	}

	public void setPay(int pay) {
		this.pay = pay;
	}

	public int getBonus() {
		return bonus;
	}

	public void setBonus(int bonus) {
		this.bonus = bonus;
	}
	
	// 부모 클래스에서 상속된 메서드를 재정의.
	@Override
	int getPays() {
		// 기본급 + 보너스
		return pay + bonus;
	}
	
	
}
