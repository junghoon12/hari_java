package abstracts;

public class Sub extends Super {

	@Override
	void output() {
		
		System.out.println("추상 메서드 재정의 했어요!!!");
		
	}
	

}
