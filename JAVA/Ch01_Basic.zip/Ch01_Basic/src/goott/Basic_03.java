package goott;

/*
 * java에서의 제어 문자.
 * 
 * - \t : 일정한 간격(tab)만큼 띄어쓰기를 해 주는 제어문자.
 * - \n : 줄바꿈을 제공해 주는 제어문자. 
 */
public class Basic_03 {

	public static void main(String[] args) {
		
		System.out.println("프로그램 시작");
		
		System.out.print("java\t");
		
		System.out.println("programming\n");
		
		System.out.println("프로그램 종료");
	}

}
