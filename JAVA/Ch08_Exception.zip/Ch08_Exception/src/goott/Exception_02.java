package goott;

public class Exception_02 {

	public static void main(String[] args) {
		
		System.out.println("프로그램 시작");
		
		String str1 = "korea";
		
		String str2 = null;   // 값이 없는 상태
		
		// length() : 현재 문자열의 길이를 
		//            정수값으로 반환해 주는 메서드.
		System.out.println("str1 문자열의 길이 >>> " + str1.length());
		
		System.out.println("str2 문자열의 길이 >>> " + str2.length());
		
		System.out.println("프로그램 종료");

	}

}
