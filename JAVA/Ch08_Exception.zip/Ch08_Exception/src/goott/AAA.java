package goott;

import javax.swing.JOptionPane;

public class AAA {

	public static void main(String[] args) {
		
		JOptionPane.showInputDialog("입력");
	}

}
