package singleton;

public class Member {

	private static Member instance = null;
	
	// 외부에서 기본생성자를 직접적으로 접근하지 못하게 함.
	private Member() { }  // 기본 생성자
	
	public static Member getInstance() {
		
		if(instance == null) {
			// Member instance = new Member();
			instance = new Member();
		}
		
		return instance;
	}  // getInstance() 메서드 end
	
}
