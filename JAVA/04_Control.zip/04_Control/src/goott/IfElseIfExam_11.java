package goott;

import java.util.Scanner;

/*
 * [문제1] 키보드로 점수를 입력받아서 90점 이상이면 "A학점",
 * 		  90~89점이면 "B학점", 70~79점이면 "C학점",
 *        60~69점이면 "D학점", 60점 이하이면 "F학점" 이라고
 *        화면에 출력해 보세요...
 */

public class IfElseIfExam_11 {

	public static void main(String[] args) {
		
		// 1. 키보드로 점수를 입력을 받자.
		Scanner sc = new Scanner(System.in);
		
		System.out.print("점수를 입력하세요. : ");
		
		int score = sc.nextInt();
		
		// 2. 다중 if~else문을 통해 해당 점수의 학점을 출력하자.
		if(score >= 90) {
			System.out.println("A학점입니다.");
		}else if(score >= 80) {
			System.out.println("B학점입니다.");
		}else if(score >= 70) {
			System.out.println("C학점입니다.");
		}else if(score >= 60) {
			System.out.println("D학점입니다.");
		}else {
			System.out.println("F학점입니다.");
		}
		
		sc.close();

	}

}
