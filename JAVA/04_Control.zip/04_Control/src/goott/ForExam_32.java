package goott;

// 다중 for문을 이용한 구구단 

public class ForExam_32 {

	public static void main(String[] args) {
		
		for(int dan = 2; dan <= 9; dan++) {
			
			System.out.println("*** " + dan + "단 ***");
			
			for(int su =1; su < 10; su++) {
				
				System.out.println(dan + " * " + su + " = " + (dan*su));
				
			}
			
			System.out.println();
			
		}
		
		System.out.println();
		System.out.println();
		
		for(int su1 = 1; su1 <= 9; su1++) {
			
			for(int dan1 = 2; dan1 < 10; dan1++) {
				
				System.out.print(dan1 + " * " + su1 + " = " + (dan1 * su1) + "\t");
			
			}
			
			System.out.println();
		}
		

	}

}
