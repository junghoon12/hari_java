package goott;

// up / down 게임

public class WhileExam_26 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
