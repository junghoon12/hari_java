package goott;

/*
 * [문제] 키보드로 정수를 하나 입력을 받아서 입력 받은 정수가
 *       5로 나누어 떨어지면 "이 정수는 5의 배수입니다." 라는
 *       메세지를 콘솔에 출력해 보세요.
 */

public class IfExam_03 {

	public static void main(String[] args) {
		
		System.out.println("프로그램 시작");
		
		// 1. 키보드로부터 정수를 입력을 받자.
		int su = Integer.parseInt(args[0]);
		
		// 2. 조건식을 이용하여 5의배수인지 판별을 하자.
		if((su%5) == 0) {
			// 3. 5의 배수이면 콘솔에 출력을 하자.
			System.out.println(su + "은(는) 5의 배수입니다.");
		}
		
		System.out.println("프로그램 종료");

	}

}
