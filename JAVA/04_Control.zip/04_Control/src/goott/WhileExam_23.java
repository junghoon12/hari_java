package goott;

import java.util.Scanner;

/*
 * [문제] 키보드로 입력 받은 수까지의 홀수의 합과
 *       짝수의 합을 구하여 화면에 보여주세요.
 *       (조건 - while 반복문을 이용할 것)
 */

public class WhileExam_23 {

	public static void main(String[] args) {
		
		// 1. 키보드로 입력받기 위한 준비 작업
		Scanner sc = new Scanner(System.in);
		
		// 2. 정수를 입력을 받자.
		System.out.print("정수를 입력하세요. : ");
		
		int max = sc.nextInt();
		
		// 3. 입력받은 수까지만 반복하여 홀수의 합, 짝수의 합 구하기.
		int su = 1;      // 반복문에서 초기식
		
		int oddSum = 0, evenSum = 0;
		
		while(su <= max) {
			
			if((su % 2) == 1) {
				oddSum += su;
			}else {
				evenSum += su;
			}
			
			su++;
			
		}  // while 반복문 end
		
		System.out.println("1 ~ " + max + " 까지의 홀수의 합 >>> " + oddSum);
		
		System.out.println("1 ~ " + max + " 까지의 짝수의 합 >>> " + evenSum);

		sc.close();
		
	}

}
