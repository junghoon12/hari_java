package goott;

// 주사위를 굴려서 임의의 숫자를 하나 받아 보자.

public class IfElseIfExam_13 {

	public static void main(String[] args) {
		
		/*
		 * 임의의 난수를 발생시키는 방법
		 * 
		 * Math.random() ==> 0.0000000000 <= su < 1
		 * 1 ~ 100
		 * 0.000000000001 ~ 0.999999999999
		 * 0.000000000001 * 100 ~ 0.999999999999 * 100
		 * (int)(0.0000 ~ 99.999999)
		 * 0 + 1 ~ 99 + 1 ==> 1 ~ 100
		 * 
		 * 형식) (int)(Math.random() * 마지막 수) + 시작 수
		 */
		
		int random = (int)(Math.random() * 6) + 1;
		
		if(random == 1) {
			System.out.println("주사위의 1번이 나왔습니다.");
		}else if(random == 2) {
			System.out.println("주사위의 2번이 나왔습니다.");
		}else if(random == 3) {
			System.out.println("주사위의 3번이 나왔습니다.");
		}else if(random == 4) {
			System.out.println("주사위의 4번이 나왔습니다.");
		}else if(random == 5) {
			System.out.println("주사위의 5번이 나왔습니다.");
		}else if(random == 6) {
			System.out.println("주사위의 6번이 나왔습니다.");
		}

	}                       

}
