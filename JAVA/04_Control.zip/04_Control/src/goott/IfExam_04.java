package goott;

import java.util.Scanner;

/*
 * 키보드로 입력 받은 정수 값이 음수이면
 * "입력 받은 정수는 음수입니다." 라는 메세지를
 * 콘솔에 출력해 보자.
 */

public class IfExam_04 {

	public static void main(String[] args) {
		
		// 키보드로 입력 받는 방법 - 3번째
		// 키보드로 입력받기 위한 준비 작업
		Scanner sc = new Scanner(System.in);
		
		// 키보드로 정수를 하나 입력을 받자.
		System.out.print("정수를 입력하세요... : ");
		int su = sc.nextInt();
		
		// 입력받은 정수가 음수인지 조건식을 이용하여 판별하자.
		if(su < 0) {
			System.out.println("입력 받은 " + su +" 은(는) 음수입니다.");
		}
		
		// Scanner를 이용하면 반드시 종료를 시켜 주자.
		sc.close();
	}

}
