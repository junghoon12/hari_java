package goott;

import java.util.Scanner;

public class SwitchCaseExam_15 {

	public static void main(String[] args) {
		
		Scanner sc = new Scanner(System.in);
		
		System.out.print("정수 하니를 입력하세요. : ");
		
		int su = sc.nextInt();
		
		switch(su%5) {
			case 0 :
				System.out.println("5의 배수입니다.");
				break;
			case 1 :
				System.out.println("나머지가 1 입니다.");
				break;
			case 2 :
				System.out.println("나머지가 2 입니다.");
				break;
			case 3 :
				System.out.println("나머지가 3 입니다.");
				break;
			case 4 :
				System.out.println("나머지가 4 입니다.");
				break;
		}
		
		sc.close();

	}

}
