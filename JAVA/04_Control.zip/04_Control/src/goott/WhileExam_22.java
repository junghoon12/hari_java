package goott;

public class WhileExam_22 {

	public static void main(String[] args) {
		
		// ABCDEFGHIJKLMN.....XYZ 까지 문자를 출력해 보자.
		char alpha = 'A';       // 반복문에서 초기식
		
		while(alpha <= 'Z') {   // 반복문에서 조건식
			
			System.out.print(alpha);
			
			alpha++;            // 반복문에서 증감식
		}
		
		System.out.println();
		
		// ZYXWV...... GFEDCBA 까지 문자를 출력해 보자.
		char alpha2 = 'Z';     // 반복문에서 초기식
		
		while(alpha2 >= 'A') {
			
			System.out.print(alpha2);
			
			alpha2--;
		}
		
		System.out.println();

	}

}
