package exam;

/*
 * 키보드로 임의의 숫자 4개를 입력을 받아서
 * 각각의 화폐와 동전이 몇개 필요한지 계산하여
 * 화면에 출력해 보세요.
 */

public class Exam_01_04 {

	public static void main(String[] args) {
		
		int num = Integer.parseInt(args[0]);
		
		// 1. 각각의 화폐단위 변수를 만들자.
		int money5000, money1000, money500, 
		    money100, money50, money10, money5, money1, res;
		
		// 2. 화폐와 동전을 계산을 해 보자.
		// 예) 8762 입력 시
		money5000 = num / 5000;  // 오천원의 몫 ==> 1
		res = num % 5000;        // 오천원으로 나눈 나머지 ==> 3762
		
		money1000 = res / 1000;  // 천원의 몫 ==> 3
		res = res % 1000;        // 천원으로 나눈 나머지 ==> 762
		
		money500 = res / 500;    // 오백원의 몫 ==> 1
		res = res % 500;         // 오백원으로 나눈 나머지 ==> 262
		
		money100 = res / 100;    // 백원의 몫 ==> 2
		res = res % 100;         // 백원으로 나눈 나머지 ==> 62
		
		money50 = res / 50;      // 오십원의 몫 ==> 1
		res = res % 50;          // 오십원으로 나눈 나머지 ==> 12
		
		money10 = res / 10;      // 십원의 몫 ==> 1
		res = res % 10;          // 십원으로 나눈 나머지 ==> 2
		
		money5 = res / 5;        // 오원의 몫 ==> 0
		res = res % 5;           // 오원으로 나눈 나머지 ==> 2
		
		money1 = res / 1;        // 일원의 몫 ==> 2
		res = res % 1;           // 일원으로 나눈 나머지 ==> 0
		
		// 3. 결과를 화면에 출력해 보자.
		System.out.println("입력받은 숫자 : " + num);
		System.out.println("오천원 지폐 : " + money5000 + "장");
		System.out.println("천원 지폐 : " + money1000 + "장");
		System.out.println("오백원 동전 : " + money500 + "개");
		System.out.println("백원 동전 : " + money100 + "개");
		System.out.println("오십원 동전 : " + money50 + "개");
		System.out.println("십원 동전 : " + money10 + "개");
		System.out.println("오원 동전 : " + money5 + "개");
		System.out.println("일원 동전 : " + money1 + "개");
		

	}

}
