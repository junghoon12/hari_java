package exam;

// 키보드로 입력 받은 수까지의 홀수의 합
// 짝수의 합 구하는 과제

import java.util.Scanner;

public class Exam_02_04 {

	public static void main(String[] args) {
		
		Scanner sc = new Scanner(System.in);
		
		System.out.print("정수 입력 : ");
		
		int su = sc.nextInt();
		
		int oddSum = 0, evenSum = 0;
		
		for(int i=1; i<=su; i++) {
			
			if((i % 2) == 1) {
				
				oddSum += i;
				
			}else {
				
				evenSum += i;
			}
		}  // for 반복문 end
		
		System.out.println("홀수의 합 >>> " + oddSum);
		System.out.println("짝수의 합 >>> " + evenSum);
		
		sc.close();

	}

}
