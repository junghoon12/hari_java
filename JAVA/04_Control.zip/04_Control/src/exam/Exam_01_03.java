package exam;

/*
 * 키보드로 입금액과 상품단가, 상품수량을 입력받으면
 * 제품금액, 부가세액, 상품총액, 거스름돈을 화면에
 * 출력하는 프로그램을 만들어 보자.
 */

public class Exam_01_03 {

	public static void main(String[] args) {
		
		// 1-1. 입금액을 키보드로 입력을 받자.
		int money = Integer.parseInt(args[0]);  // 입금액
		
		// 1-2. 상품단가를 키보드로 입력을 받자.
		int price = Integer.parseInt(args[1]);  // 상품단가
		
		// 1-3. 상품수량을 키보드로 입력을 받자.
		int amount = Integer.parseInt(args[2]);  // 상품수량
		
		// 2. 상품의 공급가액(단가 * 수량)을 계산을 하자.
		int sum = price * amount;
		
		// 3. 공급가액의 부가세액을 계산을 하자.
		//    부가세액 = 공급가액 * 0.1(10%)
		int vat = (int)(sum * 0.1);
		
		// 4. 상품의 총금액을 계산을 하자.
		//    총금액 = 공급가액 + 부가세액
		int total = sum + vat;
		
		// 5. 잔액(거스름돈)을 계산해 보자.
		//    잔액 = 입금액 - 상품의 총금액(공급가액 + 부가세액)
		int change = money - total;
		
		// 6. 화면에 처리된 내용을 출력해 보자.
		System.out.println("상품단가 : " + price + "원");
		System.out.println("상품수량 : " + amount + "개");
		System.out.println("입금액 : " + money + "원");
		System.out.println("공급가액 : " + sum + "원");
		System.out.println("부가세액 : " + vat + "원");
		System.out.println("총금액 : " + total + "원");
		System.out.println("거스름돈 : " + change + "원");

		System.out.println("::::::::::::::::::::::::::::::::::::");
		
		System.out.printf("상품단가 : %,d원\n", price);
		System.out.println("상품수량 : " + amount + "개");
		System.out.printf("입금액 : %,d원\n", money);
		System.out.printf("공급가액 : %,d원\n", sum);
		System.out.printf("부가세액 : %,d원\n", vat);
		System.out.printf("총금액 : %,d원\n", total);
		System.out.printf("거스름돈 : %,d원\n", change);
		
	}

}
