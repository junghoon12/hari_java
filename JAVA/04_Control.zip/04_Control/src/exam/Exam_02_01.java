package exam;

// 1 - 2 + 3 - 4 + 5 - 6 ...... -100

public class Exam_02_01 {

	public static void main(String[] args) {
		
		int sum = 0;   // 합을 구해 주는 변수
		
		for(int i=1; i<=100; i++) {
			
			if((i % 2) == 1) {
				
				sum += i;
			
			}else {
				
				sum -= i;
			}
		}  // for 반복문 end
		
		System.out.println("hap >>> " + sum);

	}

}
