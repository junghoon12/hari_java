package goott;

// 1. 구현 메서드의 약식 표현.

interface SuperA {
	
	// 반환타입(X), 매개변수(X)
	void method1();
}


interface SuperB {
	
	// 반환타입(X), 매개변수(O)
	void method2(int su);
}


interface SuperC {
	
	// 반환타입(O), 매개변수(X)
	int method3();
}


interface SuperD {
	
	// 반환타입(O), 매개변수(O)
	double method4(int su1, double su2);
}



public class Lambda_02 {

	public static void main(String[] args) {
		
		// 1-1. 무명 클래스로 객체 생성.
		//      ==> 반환타입(X), 매개변수(X)
		SuperA a = new SuperA() {
			
			@Override
			public void method1() {
			
				System.out.println("무명 클래스 ==> 반환타입(X), 매개변수(X) 메서드~~~");
				
			}
		};
		
		// 무명 클래스의 메서드 호출
		a.method1();
		System.out.println();
		
		
		// 1-2 람다식으로 표현하는 방법.
		SuperA a2 = () -> {
			
			System.out.println("람다식 ==> 반환타입(X), 매개변수(X) 메서드~~~");
		};
		
		a2.method1();  // 람다식으로 메서드 호출.
		
		// 람다식에서 메서드 호출 시 실행 문장이 한 줄인 경우 { } (중괄호) 생략 가능.
		SuperA a3 = () -> System.out.println("람다식 ==> 반환타입(X), 매개변수(X) 메서드~~~");
		
		a3.method1();
		System.out.println();
		
		
		// 2-1. 무명 클래스롤 객체 생성.
		//      ==> 반환타입(X), 매개변수(O)
		SuperB b = new SuperB() {
			
			@Override
			public void method2(int su) {
				
				System.out.println
				("무명 클래스 ==> 반환타입(X), 매개변수(O) 메서드~~ / su >>> " + su);
				
			}
		};
		
		b.method2(47);
		System.out.println();
		
		
		// 2-2. 람다식으로 표현하는 방법.
		SuperB b2 = (int su) -> {
			
			System.out.println
				("람다식 ==> 반환타입(X), 매개변수(O) 메서드~~ / su >>> " + su);
		};
		
		b2.method2(88);
		System.out.println();
		
		// 매개변수가 있는 경우 매개변수의 타입 생략 가능.
		SuperB b3 = (su) -> {
			
			System.out.println
				("람다식 ==> 반환타입(X), 매개변수(O) 메서드~~ / su >>> " + su);
		};
		
		b3.method2(47);
		System.out.println();
		
		// 메서드 호출 시 실행 문장이 한 문장인 경우 { } (중괄호) 생략 가능.
		SuperB b4 = (su) -> 
			System.out.println
				("람다식 ==> 반환타입(X), 매개변수(O) 메서드~~ / su >>> " + su);
		
		b4.method2(88);
		System.out.println();
		
		// 메서드 호출 시 매개변수가 하나이면 () (괄호) 생략 가능.
		SuperB b5 = su -> 
		System.out.println
			("람다식 ==> 반환타입(X), 매개변수(O) 메서드~~ / su >>> " + su);
	
		b5.method2(47);
		System.out.println();
		
		
		// 3-1. 무명 클래스로 객체 생성.
		//      ==> 반환타입(O), 매개변수(X)
		SuperC c = new SuperC() {
			
			@Override
			public int method3() {
				
				return 27;
			}
		};
		
		System.out.println
		("무명 클래스 ==> 반환타입(O), 매개변수(X) 메서드~~ >>> " + c.method3());
		System.out.println();
		
		// 3-2. 람다식으로 표현하는 방법.
		SuperC c2 = () -> {
			return 66;
		};
		
		System.out.println
		("람다식 ==> 반환타입(O), 매개변수(X) 메서드~~ >>> " + c2.method3());
		System.out.println();
		
		
		// 메서드 호출 시 Return 문장이 한 문장이면 return 키워드와 { } (중괄호) 생략 가능.
		SuperC c3 = () -> 23;
		
		System.out.println
		("람다식 ==> 반환타입(O), 매개변수(X) 메서드~~ >>> " + c3.method3());
		System.out.println();
		
		// 4-1. 무명 클래스로 객체 생성.
		//      ==> 반환타입(O), 매개변수(O)
		SuperD d = new SuperD() {
			
			@Override
			public double method4(int su1, double su2) {
				
				return su1 + su2;
			}
		};
		
		System.out.println("무명 클래스 ==> 반환타입(O), 매개변수(O) 메서드~~~ / " + d.method4(40, 128));
		System.out.println();
		
		// 4-2. 람다식으로 표현하는 방법.
		SuperD d2 = (int su1, double su2) -> {
			
			return su1 + su2;
		};
		
		System.out.println("람다식 ==> 반환타입(O), 매개변수(O) 메서드~~~ / " + d2.method4(11, 34));
		System.out.println();
		
		// 매개변수의 타입은 생략해도 됨.
		SuperD d3 = (su1, su2) -> {
			
			return su1 + su2;
		};
		
		System.out.println("람다식 ==> 반환타입(O), 매개변수(O) 메서드~~~ / " + d3.method4(40, 128));
		System.out.println();
		
		
		// 메서드 호출 시 return 문이 한 문장이면 { }(중괄호)와 return 키워드 생략 가능.
		SuperD d4 = (su1, su2) -> su1 + su2;
		
		System.out.println("람다식 ==> 반환타입(O), 매개변수(O) 메서드~~~ / " + d4.method4(11, 34));
		System.out.println();
		
	}

}
