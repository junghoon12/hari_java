package exam;

import java.util.Scanner;

// 정렬 알고리즘 - 내림차순 정렬

public class Exam_03_02 {

	public static void main(String[] args) {
		
		// 1. 키보드 준비 작업
		Scanner sc = new Scanner(System.in);
		
		// 2. 정부형 배열 선언 - 배열의 크기 5
		int[] sort = new int[5];
		
		// 3. 배열에 키보드로 데이터를 입력하여 저장해 주자.
		for(int i=0; i<sort.length; i++) {
			
			System.out.print((i+1) +" 번째 정수 입력 : ");
			
			sort[i] = sc.nextInt();
		}
		
		// 4. 내림차순으로 정렬을 해 주자.
		int temp = 0;
		
		for(int i=0; i<sort.length; i++) {
			
			for(int j=i+1; j<sort.length; j++) {
				
				if(sort[j] > sort[i]) {
					
					temp = sort[j];
					
					sort[j] = sort[i];
					
					sort[i] = temp;
				}
			}
		}
		
		System.out.println();
		
		System.out.println("***** 내림차순으로 정렬 *****");
		
		// 5. 내림차순으로 정렬된 sort 배열을 화면애 출력해 보자.
		for(int i=0; i<sort.length; i++) {
			
			System.out.print(sort[i] + "\t");
		}
		
		sc.close();

	}

}
