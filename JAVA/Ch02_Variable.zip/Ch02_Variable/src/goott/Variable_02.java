package goott;

public class Variable_02 {

	public static void main(String[] args) {
		
		// 1. 변수 선언
		// int num;
		
		// 2. 변수 초기화
		// num = 130;
		
		// 1 + 2 : 변수 선언 및 변수 초기화
		int num = 135;
		
		num = num + 100;
		
		int num2 = num;
		
		// 3. 변수 연산 또는 변수 출력
		System.out.println("num >>> " + num);
		
		System.out.println("num2 >>> " + num2);
		
		

	}

}
