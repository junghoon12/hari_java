package goott;

/*
 * 단일문자형 : char형(0 ~ 65535) ==> 2바이트
 * - 자바에서는 유니코드(UTF-8) 체계로 단일문자가 처리가 됨.
 */

public class Variable_06 {

	public static void main(String[] args) {
		
		char ch1 = 'B';
		
		System.out.println("ch1 >>> " + ch1);
		
		System.out.println((char)(ch1 + 1));  // 66 + 1 ==> 67(C)
		
		

	}

}
