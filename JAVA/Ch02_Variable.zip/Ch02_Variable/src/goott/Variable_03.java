package goott;

public class Variable_03 {

	public static void main(String[] args) {
		
		int su1 = 67, su2 = 19;
		
		System.out.println("su1 변수의 값은 " + su1 + " 입니다.");
		
		System.out.println("su2 변수의 값은 " + su2 + " 입니다.");
		
		System.out.println("두 수의 합은 "+ (su1 + su2) + " 입니다.");
		
	}

}
