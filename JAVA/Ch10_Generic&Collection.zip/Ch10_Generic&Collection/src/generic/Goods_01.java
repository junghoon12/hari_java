package generic;

public class Goods_01 {

	public static void main(String[] args) {
		
		// Goods1 객체를 이용하여 Apple 객체를
		// 추가하거나 가져오기
		Goods1 goods1 = new Goods1();
		
		// Apple 객체 타입만 입력이 가능.
		// Apple apple = new Apple();
		// Pencil pencil = new Pencil();
		
		goods1.setApple(new Apple());
		
		Apple apple = goods1.getApple();
		
		apple.output();
		
		System.out.println();
		
		// Goods2 객체를 이용하여 Pencil 객체를
		// 추가하거나 가져올 수 있음.
		Goods2 goods2 = new Goods2();
		
		// Pencil 객체 타입만 입력이 가능.
		goods2.setPencil(new Pencil());
		
		Pencil pencil = goods2.getPencil();
		
		pencil.output();
		
		

	}

}
