package generic;

public class Goods1 {
	
	private Apple apple;

	
	public Apple getApple() {
		return apple;
	}

	public void setApple(Apple apple) {
		this.apple = apple;
	}


}
