package generic;

public class Pencil {

	void output() {
		
		System.out.println("연필입니다.~~~~");
	}
	
}
