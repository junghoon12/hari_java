package model;

public class Student {

	private String hakbun;
	private String name;
	private String major;
	private String phone;
	private String addr;
	
	public Student() {  }  // 기본 생성자
	
	public Student(String hakbun, String name,
			String major, String phone, String addr) {
		
		this.hakbun = hakbun;
		this.name = name;
		this.major = major;
		this.phone = phone;
		this.addr = addr;
		
	}  // 인자 생성자

	
	public String getHakbun() {
		return hakbun;
	}

	public String getName() {
		return name;
	}

	public String getMajor() {
		return major;
	}

	public String getPhone() {
		return phone;
	}

	public String getAddr() {
		return addr;
	}
	
	
}
