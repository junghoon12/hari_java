package collection;

/*
 * [문제] List_05 클래스처럼 Student 객체를 만들어서
 *       키보드로 학생 수를 입력을 받고, 입력 받은 학생
 *       수 만큼 학생의 정보를 입력을 받아서 ArrayList에
 *       저장 후 화면에 출력해 보세요.
 *       (조건 - 학생정보는 학번, 이름, 학과, 연락처, 주소)
 */

public class List_06 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
