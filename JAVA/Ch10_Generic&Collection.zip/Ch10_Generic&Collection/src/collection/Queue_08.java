package collection;

import java.util.LinkedList;
import java.util.Queue;

/*
 * Queue 자료 구조
 * - queue는 인터페이스이어서 자식클래스로 객체를 생성하여 사용함.
 * - 대표적인 자식 클래스는 LinkedList 객체임.
 * - 특징 : 선입선출(FIFO : First In First Out) 구조임.
 */

public class Queue_08 {

	public static void main(String[] args) {
		
		  Queue<Integer> queue = new LinkedList<>();
		  
		  // 1. add() : queue에 저장하는 메서드.
		  //            queue에서 예외처리 기능 미포함된 메서드.
		  queue.add(3);
		  queue.add(4);
		  queue.add(5);
		  
		  // element() : queue에 가장 먼저 입력된 데이터를 출력하는 메서드.
		  System.out.println(queue.element());
		  
		  // remove() : queue에 가장 먼저 입력된 데이터를 
		  //            출력후 제거하는 메서드.
		  System.out.println(queue.remove());  // 3
		  
		  System.out.println(queue.remove());  // 4
		  
		  System.out.println(queue.remove());  // 5
		  
		  // 실제 queue에 저장된 데이터는 없음.  ==> 예외가 발생.
		  // System.out.println(queue.remove());  
		  
		  System.out.println();
		  
		  Queue<Integer> queue2 = new LinkedList<>();
		  // offer() : queue에 저장하는 메서드.
		  //           queue에서 예외처리 기능 포함된 메서드.
		  queue2.offer(3);
		  queue2.offer(4);
		  queue2.offer(5);
		  
		  // element() : queue에 가장 먼저 입력된 데이터를 출력하는 메서드.
		  System.out.println(queue2.element());
		  
		  // poll() : queue에 가장 먼저 입력된 데이터를 
		  //            출력후 제거하는 메서드.
		  System.out.println(queue2.poll());  // 3
		  
		  System.out.println(queue2.poll());  // 4
		  
		  System.out.println(queue2.poll());  // 5
		  
		  // 실제 queue에 저장된 데이터는 없음.
		  System.out.println(queue2.poll());
		  
	}

}
