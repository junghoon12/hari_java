package inheritance;

public class Point {

	int x;
	int y;
	
	public Point() { }   // 기본 생성자
	
	public Point(int x, int y) { 
		
		this.x = x;
		this.y = y;
		
	}  // 인자 생성자
	
}
