package inheritance;

public class Person_03 {

	public static void main(String[] args) {
		
		Student student = new Student("061123-2158973", "김지수", 23, "대학생", "컴공과");
		
		student.getStudentInfo();
		
		System.out.println();
		
		Employee employee = new Employee();
		
		employee.juminNo = "540311-2345678";
		
		employee.name = "유관순";
		
		employee.age = 19;
		
		employee.job = "주부";
		
		employee.salary = 1000;
		
		employee.getEmployeeInfo();

	}

}
