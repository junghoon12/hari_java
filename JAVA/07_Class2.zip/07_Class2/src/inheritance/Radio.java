package inheritance;

public class Radio extends Volume {

}
