package inheritance;

public class Computer extends Volume {

}
