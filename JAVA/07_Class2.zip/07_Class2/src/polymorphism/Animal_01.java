package polymorphism;

public class Animal_01 {

	public static void main(String[] args) {
		
		// 일반적인 객체 생성 방법
		// Dog dog = new Dog();
		// dog.sound();
		
		// 다형성을 이용한 객체 생성 방법
		Animal animal = new Dog();
		
		animal.sound();
		
		System.out.println();
		
		// animal.output();
		
		// 자식클래스에서 만든 메서드가
		// 부모클래스에는 존재하지 않기 때문에
		// 다형성의 원칙에 맞지 않음.
		// Dog dog = new Animal();
		

	}

}
