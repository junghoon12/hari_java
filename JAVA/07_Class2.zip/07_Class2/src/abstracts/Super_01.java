package abstracts;

public class Super_01 {

	public static void main(String[] args) {
		
		// 추상 클래스는 객체 생성이 불가능.
		// Super super1 = new Super();
		
		Sub sub = new Sub();
		
		sub.num1 = 34;
		
		System.out.println("calc() 메서드 호출 >>> " + sub.calc());
		
		// 추상 메서드 재정의 호출
		sub.output();

	}

}
