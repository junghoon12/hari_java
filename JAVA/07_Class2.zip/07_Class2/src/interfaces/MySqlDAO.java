package interfaces;

public class MySqlDAO implements DAO {

	@Override
	public void select() {
		
		System.out.println("MySql DB에서 검색하는 메서드~~~");
	}

	@Override
	public void insert() {
		
		System.out.println("MySql DB에 추가하는 메서드~~~");

	}

	@Override
	public void modify() {
		
		System.out.println("MySql DB에서 수정하는 메서드~~~");

	}

	@Override
	public void delete() {
		
		System.out.println("MySql DB에서 삭제하는 메서드~~~");

	}


}
