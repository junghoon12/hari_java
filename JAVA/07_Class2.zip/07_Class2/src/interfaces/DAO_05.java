package interfaces;

public class DAO_05 {

	void dbWork(DAO dao) {
		
		dao.select();
		dao.insert();
		dao.modify();
		dao.delete();
		
	}
	
	public static void main(String[] args) {
		
		// OracleDAO oracle = new OracleDAO();
		// MySqlDAO mySql = new MySqlDAO();
		
		// dao.dbWork(oracle);
		
		// System.out.println();
		
		// dao.dbWork(mySql);
		
		DAO_05 dao = new DAO_05();
		
		dao.dbWork(new OracleDAO());
		
		System.out.println();
		
		dao.dbWork(new MySqlDAO());

	}

}
