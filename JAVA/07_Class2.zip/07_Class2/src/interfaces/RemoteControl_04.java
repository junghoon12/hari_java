package interfaces;

public class RemoteControl_04 {

	public static void main(String[] args) {
		
		Audio audio = new Audio();
		TV tv = new TV();
		AirConditioner conditioner = new AirConditioner();
		
		audio.turnOn();
		audio.setVolume(7);
		audio.turnOff();
		System.out.println();
		
		tv.turnOn();
		tv.setVolume(13);
		tv.turnOff();
		System.out.println();
		
		conditioner.turnOn();
		conditioner.setVolume(0);
		conditioner.turnOff();

	}

}
