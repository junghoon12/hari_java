package interfaces;

// DAO(Data Access Object : 데이터 접근 객체)

public interface DAO {

	void select();    // DB에서 검색하는 추상메서드.
	void insert();    // DB에 데이터를 추가하는 추상메서드.
	void modify();    // DB에서 데이터를 수정하는 추상메서드.
	void delete();    // DB에서 데이터를 삭제하는 추상메서드.

}

