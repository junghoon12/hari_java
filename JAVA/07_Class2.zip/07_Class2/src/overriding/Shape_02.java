package overriding;

public class Shape_02 {

	public static void main(String[] args) {
		
		Line line = new Line();
		Circle circle = new Circle();
		Rectangle rectangle = new Rectangle();
		
		line.draw();
		circle.draw(); rectangle.draw();

	}

}
