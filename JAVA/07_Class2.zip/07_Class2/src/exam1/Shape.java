package exam1;

public interface Shape {

	double findArea();   // 추상메서드
	
}
