package exam1;

public class Permanent extends Employee {

	// 멤버변수
	private int salary;      // 기본급 멤버변수
	private int bonus;       // 보너스 멤버변수
	
	public Permanent() {  }  // 기본 생성자
	
	public Permanent(String name, int salary, int bonus) {
		
		this.name = name;
		this.salary = salary;
		this.bonus = bonus;
		
	}  // 인자 생성자
	
	public int getSalary() {
		return salary;
	}

	public int getBonus() {
		return bonus;
	}

	@Override
	int getPays() {
		// 급여 계산 : 기본급 + 보너스
		return salary + bonus;
	}

}
