package exam1;

public class Temporary extends Employee {

	// 멤버변수
	private int time;       // 작업시간 멤버변수
	private int pay;        // 시간당급여 멤버변수
	
	public Temporary() { }  // 기본 생성자
	
	public Temporary(String name, int time, int pay) {
		super(name);
		this.time = time;
		this.pay = pay;
	}  // 인자 생성자
	
	
	public int getTime() {
		return time;
	}

	public int getPay() {
		return pay;
	}

	@Override
	int getPays() {
		// 급여 계산 : 작업시간 * 시간당급여
		return time * pay;
	}

}
