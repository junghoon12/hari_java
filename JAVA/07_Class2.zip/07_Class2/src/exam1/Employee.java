package exam1;


public abstract class Employee {  // 추상 클래스

	// 멤버변수
	String name;
	
	public Employee() { }   // 기본 생성자
	
	public Employee(String name) {
		
		this.name = name;
		
	}  // 인자 생성자

	public String getName() {
		return name;
	}
	
	// 자식클래스에서 재정의를 진행할
	// 급여를 계산하는 추상 메서드
	abstract int getPays();
	
}
