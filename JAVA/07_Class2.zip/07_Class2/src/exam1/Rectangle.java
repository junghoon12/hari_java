package exam1;

public class Rectangle implements Shape {

	// 멤버변수
	int width;              // 가로 멤버변수
	int height;             // 세로 멤버변수
	
	public Rectangle() { }  // 기본 생성자
	
	public Rectangle(int width, int height) {
		
		this.width = width;
		this.height = height;
		
	}  // 인자 생성자
	
	
	// 인터페이스 추상메서드 재정의
	@Override
	public double findArea() {
		// 사각형의 면적 : 가로 * 세로
		return width * height;
	}

}
