package exam;

import java.util.Scanner;

public class AAA {

	public static void main(String[] args) {
		
		Scanner sc = new Scanner(System.in);
		
		System.out.print("나이를 입력하세요...");
		
		int age = sc.nextInt();
		
		System.out.print("주소를 입력하세요...");
		
		String addr = sc.nextLine();
		
		System.out.println();
		
		System.out.println("나이 >>> " + age);
		
		System.out.println("주소 >>> " + addr);
	}

}
