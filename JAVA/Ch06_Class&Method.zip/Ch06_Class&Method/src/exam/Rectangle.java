package exam;

public class Rectangle {

	// 멤버변수
	int width;               // 가로 변수
	int height;              // 세로 변수
	
	public Rectangle() { }   // 기본 생성자
	
	public Rectangle(int width, int height) {
		
		this.width = width;
		this.height = height;
		
	}   // 인자 생성자
	
	
	// 사각형의 넓이를 구하는 메서드.
	void output1() {
		
		System.out.println("사각형의 넓이 : " + (width * height));
	
	}  // output1() 메서드 end
	
	
	// 사각형의 둘레를 구하는 메서드.
	void output2() {
		
		System.out.println("사각형의 둘레 : " + ((width + height) * 2));
	
	}  // output2() 메서드 end
	
}
