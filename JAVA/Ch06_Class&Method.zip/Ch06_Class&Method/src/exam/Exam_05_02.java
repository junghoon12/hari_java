package exam;

import java.util.Scanner;

public class Exam_05_02 {

	public static void main(String[] args) {
		
		Scanner sc = new Scanner(System.in);
		
		System.out.println("사각형의 가로, 세로를 입력하세요.....");
		
		Rectangle rectangle = 
				new Rectangle(sc.nextInt(), sc.nextInt());
		
		System.out.println("================================");
		
		// 사각형의 넓이를 구하는 메서드를 호출.
		rectangle.output1();
		
		// 사각형의 둘레를 구하는 메서드를 호출.
		rectangle.output2();
		
		sc.close();
	}

}
