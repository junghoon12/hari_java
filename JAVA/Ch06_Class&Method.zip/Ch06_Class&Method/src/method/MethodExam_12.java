package method;

import java.util.Scanner;

public class MethodExam_12 {
	
	// 2과목의 총점을 구하는 메서드
	public static int sum2(int k, int e) {
		
		return k + e;
		
	}  // sum2() 메서드 end
	
	
	// 3과목의 총점을 구하는 메서드
	public static int sum3(int k, int e, int m) {
		
		return k + e + m;
		
	}  // sum3() 메서드 end
	
	
	// 4과목의 총점을 구하는 메서드
	public static int sum4(int k, int e, int m, int j) {
		
		return k + e + m + j;
		
	}  // sum4() 메서드 end
	
	
	public static void main(String[] args) {
		
		Scanner sc = new Scanner(System.in);
		
		System.out.print("국어 점수를 입력하세요. : ");
		int kor = sc.nextInt();
		
		System.out.print("영어 점수를 입력하세요. : ");
		int eng = sc.nextInt();
		
		System.out.print("수학 점수를 입력하세요. : ");
		int mat = sc.nextInt();
		
		System.out.print("자바 점수를 입력하세요. : ");
		int java = sc.nextInt();
		
		System.out.println();
		
		System.out.println
				("2과목 총점 >>> " + sum2(kor, eng));
		
		System.out.println
				("3과목 총점 >>> " + sum3(kor, eng, mat));
		
		System.out.println
				("4과목 총점 >>> " + sum4(kor, eng, mat, java));

		sc.close();
		
	}

}
