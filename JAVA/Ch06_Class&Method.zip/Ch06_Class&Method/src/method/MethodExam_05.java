package method;

import java.util.Scanner;

/*
 * [문제] 키보드로 입력 받은 수까지의 홀수의 합과
 *       짝수의 합을 구하는 메서드를 만들고,
 *       메서드를 호출하여 처리 후 화면에 보여주세요.
 */

public class MethodExam_05 {
	
	public static void total(int su) {
		
		int oddSum = 0, evenSum = 0;
		
		for(int i=1; i<=su; i++) {
			
			if(i % 2 == 1) {
				oddSum += i;
			}else {
				evenSum += i;
			}
		}
		
		System.out.println("1 ~ "+su+" 까지의 홀수의 합 >>> " + oddSum);
		
		System.out.println("1 ~ "+su+" 까지의 짝수의 합 >>> " + evenSum);
	
	}  // total() 메서드 end

	
	public static void main(String[] args) {
		
		Scanner sc = new Scanner(System.in);
		
		System.out.print("합을 구할 정수를 입력하세요. : ");
		
		// int max = sc.nextInt();
		
		total(sc.nextInt());
		
		sc.close();
		
	}

}
