package classes;

// 음료자판기

// 음료(6개) - 콜라, 사이다, 옥수수수염차, 17차, 몬스터, 포카리스웨트

public class Drink {

	// 멤버변수
	String name;                // 음료 이름
	int price;                  // 음료 가격
	
	public Drink() { }          // 기본 생성자
	
	
	public Drink(String name, int price) {
		
		this.name = name;
		this.price = price;
		
	}  // 인자 생성자
	
}
