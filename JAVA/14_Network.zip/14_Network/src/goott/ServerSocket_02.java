package goott;

import java.io.IOException;
import java.net.InetSocketAddress;
import java.net.ServerSocket;
import java.net.Socket;

public class ServerSocket_02 {

	public static void main(String[] args) {
		
		ServerSocket server = null;
		
		try {
			server = new ServerSocket();
			
			server.bind(new InetSocketAddress("localhost", 5002));
			
			while(true) {
				
				System.out.println("[연결을 기다림].....");
				
				/*
				 * accept() : 클라이언트의 연결을 수락하는 메서드.
				 *            클라이언트의 연결 요청이 들어오면 수락을 하고
				 *            데이터를 주고 받을 통신용 Socket을 하나 만들게 됨.
				 */
				Socket socket = server.accept();
				
				InetSocketAddress isa = 
						(InetSocketAddress)socket.getRemoteSocketAddress();
				
				// 클라이언트의 컴퓨터 이름을 가져올 수 있음.
				System.out.println("[연결을 수락함]..." + isa.getHostName());
			} 
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		

	}

}
