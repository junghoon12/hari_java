package goott;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.Socket;
import java.net.UnknownHostException;

public class Client_05 {

	public static void main(String[] args) {
		
		Socket socket = null;
		
		try {
			
			socket = new Socket("localhost", 5002);
			
			System.out.println("[클라이언트 : 연결이 성공이 됨].....");
			
			// 서버로 데이터를 보내 보자.
			byte[] bytes = null;
			
			String message = null;
			
			OutputStream os = socket.getOutputStream();
			
			message = "Hello Server!!!";
			
			bytes = message.getBytes("UTF-8");
			
			os.write(bytes);
			
			System.out.println("[클라이언트 : 데이터 보내기 성공].....");
			
			// 클라이언트에서 서버 데이터 받기
			InputStream is = socket.getInputStream();
			
			bytes = new byte[100];
			
			int readCount = is.read(bytes);
			
			message = 
				new String(bytes, 0, readCount, "UTF-8");
			
			System.out.println("[클라이언트 : 서버 데이터 받기 성공] >>> " + message);
			
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		if(!socket.isClosed()) {
			try {
				socket.close();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}

	}

}
