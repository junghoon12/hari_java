package goott;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.InetSocketAddress;
import java.net.ServerSocket;
import java.net.Socket;

public class ServerSocket_04 {

	public static void main(String[] args) {
		
		ServerSocket serverSocket = null;
		
		try {
			serverSocket = new ServerSocket(5002);
			
			Socket socket = serverSocket.accept();
			
			while(true) {
				
				System.out.println("[서버 : 연결을 기다림].....");
				
				InetSocketAddress isa =
						(InetSocketAddress)socket.getRemoteSocketAddress();
				
				System.out.println("[서버 : 연결을 수락함]....." + isa.getHostName());
				
				// 클라이언트 데이터를 서버에서 받기
				byte[] bytes = null;
				String message = null;
				
				InputStream is = socket.getInputStream();
				
				bytes = new byte[100];
				
				/*
				 * 클라이언트가 문자를 보내기 전 까지는 서버는
				 * 대기 상태가 됨.
				 * 클라이언트에서 데이터를 보내면 보낸 데이터는
				 * bytes 배열에 저장을 시키고, 읽은 바이트 수는
				 * int 타입의 변수에 저장을 시킬 예정.
				 */
				int readCount = is.read(bytes);
				
				message = 
					new String(bytes, 0, readCount, "UTF-8");
				
				System.out.println("[서버 : 데이터 받기 성공] >>> " + message);
				
				// 클라이언트로 데이터를 보내 보자.
				OutputStream os = socket.getOutputStream();
				
				message = "Hello Client!!!";
				
				bytes = message.getBytes("UTF-8");
				
				os.write(bytes);
				
				System.out.println("[서버 : 클라이언트로 데이터 보내기 성공].....");
				
			}
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}

}
