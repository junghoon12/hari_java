package collection;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

import model.Member;

public class List_05 {

	public static void main(String[] args) {
		
		Scanner sc = new Scanner(System.in);
		
		System.out.print("회원 수를 입력하세요. : ");
		
		int memberCount = sc.nextInt();
		
		sc.nextLine();
		
		List<Member> list = new ArrayList<Member>();
		
		// 1. 키보드로 회원 수만큼 회원 정보를 입력 받아서
		//    ArrayList에 저장해 보자.
		for(int i=0; i<memberCount; i++) {
			
			System.out.println((i+1) +" 번째 회원의 아이디, 비밀번호,"
					+ " 이름, 나이, 연락처, 주소를 입력해 주세요.....");
			
			Member member = 
					new Member(sc.nextLine(), sc.nextLine(), sc.nextLine(), 
								sc.nextLine(), sc.nextLine(), sc.nextLine());
			
			list.add(member);    // 아주 중요함
			
			System.out.println("::::::::::::::::::::::::::::::::::::::::::::::");
			
		}  // for문 end
		
		for(int i=0; i<list.size(); i++) {
			
			System.out.println("list["+i+"] >>> " + list.get(i));
		}
		
		System.out.println();
		
		// 2. 회원 정보를 ArrayList에서 가져 와서 화면에 출력해 보자.
		for(int i=0; i<list.size(); i++) {
			
			Member dto = list.get(i);  // 아주 중요함
			
			System.out.println(dto.getId()+"\t"+dto.getPwd()+"\t"+
								dto.getName()+"\t"+dto.getAge()+"\t"+
								dto.getPhone()+"\t"+dto.getAddr());
			
			System.out.println("::::::::::::::::::::::::::::::::::::::::::::::");
		}
		

		sc.close();
	}

}
