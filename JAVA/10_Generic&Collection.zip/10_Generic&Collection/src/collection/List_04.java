package collection;

import java.util.ArrayList;
import java.util.LinkedList;
import java.util.List;

/*
 * LinkedList
 * - List 인터페이스의 자식 클래스 중 한 종류.
 * - 특징
 *   1) 인접 참조를 링크해서 체인처럼 관리함.
 *   2) 특정 인덱스에서 객체를 제거하거나 추가하게 되면
 *      앞 뒤의 링크만 연결하면 되는 구조.
 *   3) 빈번하게 삽입과 삭제가 일어나는 곳에서는
 *      ArrayList 보다 더 큰 성능을 발휘함.
 *      (단, 중간에 삽입과 삭제가 일어나는 경우)
 */

public class List_04 {

	public static void main(String[] args) {
		
		List<Integer> list1 = new ArrayList<Integer>();
		
		List<Integer> list2 = new LinkedList<Integer>();
		
		long start, end;
		
		// 1. ArrayList로 중간에 데이터를 추가하는 경우
		//    걸리는 시간 확인
		start = System.nanoTime();   // 10억분의 1초
		
		for(int i=1; i<10000; i++) {
			
			list1.add(0, i);
		}
		
		end = System.nanoTime();
		
		System.out.println("ArrayList로 추가하는데 걸린 시간 >>> " + (end-start) + "ns");
		
		// 2. LinkedList로 중간에 데이터를 추가하는 경우
		//    걸리는 시간 확인
		start = System.nanoTime();   // 10억분의 1초
		
		for(int i=1; i<10000; i++) {
			
			list2.add(0, i);
		}
		
		end = System.nanoTime();
		
		System.out.println("LinkedList로 추가하는데 걸린 시간 >>> " + (end-start) + "ns");
		
		
		/*
		 * currentTimeMillis()와 nanoTime() 차이점
		 * - currentTimeMillis() 메서드는 1970년 1월 1일 00시 00분과
		 *   현재 시간과의 차이를 ms(밀리초 1/1000초) 단위로 리턴(long형)
		 *   하는 메서드임.
		 * 
		 * - nanoTime() 메서드는 현재 시간 정보와는 상관 없이 상대적인 시간
		 *   차이를 나노추 단위로 구현하는데 시용되는 메서드임.
		 *   즉, 작동중인 JVM의 정밀한 시간 소스의 현재 값을 long 타입으로
		 *   나노세컨드(1/1000000000초)를 반환함.
		 */

	}

}
