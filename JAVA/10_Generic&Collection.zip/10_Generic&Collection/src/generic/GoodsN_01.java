package generic;

public class GoodsN_01 {

	public static void main(String[] args) {
		
		// Goods1 객체를 이용하여 Apple 객체를 
		// 추가하거나 가져오기
		Goods1 goods1 = new Goods1();
		
		// Apple 객체 타입만 입력이 가능.
		// Apple apple = new Apple();
		
		goods1.setApple(new Apple());
		
		Apple apple = goods1.getApple();
		
		apple.output();
		
		System.out.println();
		
		
		// Goods2 객체를 이용하여 Pencil 객체를 
		// 추가하거나 가져오기
		Goods2 goods2 = new Goods2();
		
		// Pencil 객체 타입만 입력이 가능.
		Pencil pencil = new Pencil();
		
		goods2.setPencil(pencil);
		
		// 반환 타입도 Pencil 객체 타입이어야 함.
		Pencil pencil1 = goods2.getPencil();
		
		pencil1.output();
		

	}

}
