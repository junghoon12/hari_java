package generic;

public class Box_03 {

	public static void main(String[] args) {
		
		Box box = new Box();
		
		box.setObject("제네릭");  // String 자료형
		
		/*
		 * Object 타입으로 선언된 변수에 데이터가 들어가는 경우,
		 * 해당 변수에 있는 값을 꺼내고 싶은 경우에는 반드시
		 * 형변환(캐스팅) 작업이 필요함.
		 * 이러한 형변환 작업이 자주 일어나게 되면 프로그램 성능이
		 * 저하가 될 수 있음.
		 */
		
		String str = (String)box.getObject();
		
		System.out.println("str 문자열 >>> " + str);

	}

}
