package goott;

// java 에서의 출력 양식

public class Basic_06 {

	public static void main(String[] args) {
		
		// System.out.println()
		// System.out.print()
		// System.out.printf()
		System.out.printf("%d + %d = %d\n", 10, 20, (10+20));
		
		System.out.printf("%o\n", 10);
		
		System.out.printf("%x\n", 12);
		
		System.out.printf("%f\n", 3.2582);
		
		System.out.printf("%.2f\n", 3.2582);
		
		System.out.printf("%d\n", 10000000);
		
		System.out.printf("%,d\n", 10000000);
		
		/*
		 * 형식(%.소수점자리수f)
		 * ==> 정수는 그대로 출력이 되고, 소수점 아래는
		 *     소수점자리까지만 출력이 됨. 올림도 가능함. 
		 */
	}

}
