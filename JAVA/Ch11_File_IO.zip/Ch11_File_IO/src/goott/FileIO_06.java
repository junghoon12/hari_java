package goott;

import java.io.FileReader;
import java.io.Reader;

/*
 * [문제] FileIO_05 클래스를 읽어 들여서
 *       콘솔 창에 출력해 보세요.
 */

public class FileIO_06 {

	public static void main(String[] args) {
		
		Reader reader = null;
		
		try {
			reader = new FileReader("C:\\NCS\\workspace(java)\\Ch11_File_IO\\src\\goott\\FileIO_05.java");
			
			while(true) {
				
				int readCount = reader.read();
				
				if(readCount == -1) {
					
					break;
				}
				
				System.out.print((char)readCount);
			
			}
			
			// 입출력 객체는 종료시켜 주는 것이 좋다.
			reader.close();
			
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}

}
