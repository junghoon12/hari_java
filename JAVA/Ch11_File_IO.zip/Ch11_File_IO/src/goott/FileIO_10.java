package goott;

import java.io.FileReader;
import java.io.FileWriter;

/*
 * [문제] FileIO_05 원본 소스 내용을 복사하여
 *       이전 예제에서 만든 C:/test/sample/sample.txt
 *       파일에 넣어 보세요.
 */

public class FileIO_10 {

	public static void main(String[] args) throws Exception {
		
		// 원본 소스 파일 경로
		FileReader fr = new FileReader("C:\\NCS\\workspace(java)\\Ch11_File_IO\\src\\goott\\FileIO_05.java");
		
		// 원본 소스 파일이 복사되어 저장될 파일 경로
		FileWriter fw = new FileWriter("C:\\test\\sample\\sample.txt");

		while(true) {
			
			int readByte = fr.read();
			
			if(readByte == -1) {
				break;
			}
			
			fw.write(readByte);
		}
		
		// 입출력 객체 닫아 주자.
		fw.close(); fr.close();
		
		System.out.println("파일 소스 복사 완료!!!");
	
	}
	
	

}
