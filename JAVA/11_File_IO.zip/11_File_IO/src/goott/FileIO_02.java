package goott;

import java.io.IOException;
import java.io.InputStream;

public class FileIO_02 {

	public static void main(String[] args) {
		
		System.out.println("한 문자를 입력하세요.....");
		
		// System.in : 표준입력장치(키보드)
		InputStream is = System.in;
		
		try {
			
			int read = is.read();
			
			System.out.println("읽어온 데이터(ASCII) >>> " + read);
			
			System.out.println("읽어온 데이터(문자) >>> " + (char)read);
			
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}

}
