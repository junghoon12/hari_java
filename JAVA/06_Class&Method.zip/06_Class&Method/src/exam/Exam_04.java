package exam;

import java.util.Scanner;

// 학생관리 프로그램 과제

public class Exam_04 {
	
	// 학생의 정보를 저장하는 메서드
	public static void input(String[] n, int[] h,
			String[] m, String[] p, Scanner sc) {
		
		System.out.println("n >>> " + n);
		System.out.println("h >>> " + h);
		System.out.println("m >>> " + m);
		System.out.println("p >>> " + p);
		
		for(int i=0; i<n.length; i++) {
			
			System.out.println("<<< " + (i+1) + "번째 학생 정보 입력 >>>");
			
			System.out.print("학생 이름 입력 : ");
			n[i] = sc.next();
			
			System.out.print("학생 학번 입력 : ");
			h[i] = sc.nextInt();
			
			System.out.print("학생 학과 입력 : ");
			m[i] = sc.next();
			
			System.out.print("학생 연락처 입력 : ");
			p[i] = sc.next();
			
		}
		
	}  // input() 메서드 end
	
	
	// 전체 학생 정보를 출력하는 메서드.
	public static void output(String[] na, int[] ha,
			String[] ma, String[] ph) {
		
		for(int i=0; i<ha.length; i++) {
			System.out.println("*** " + (i+1) +" 번째 학생 정보 ***");
			
			System.out.println("학생 이름 : " + na[i]);
			System.out.println("학생 학번 : " + ha[i]);
			System.out.println("학생 학과 : " + ma[i]);
			System.out.println("학생 연락처 : " + ph[i]);
			System.out.println(":::::::::::::::::::::::::::::::::::::");
		}
		
	}  // output() 메서드 end
	
	
	// 학생 정보를 조회하는 메서드.
	public static void search(String[] n, int[] h,
			String[] m, String[] p, Scanner sc) {
		
		System.out.print("조회할 학생의 학번을 입력하세요. : ");
		int hakbun = sc.nextInt();
		
		for(int i=0; i<m.length; i++) {
			
			if(hakbun == h[i]) {
				System.out.println("학생 이름 : " + n[i]);
				System.out.println("학생 학번 : " + h[i]);
				System.out.println("학생 학과 : " + m[i]);
				System.out.println("학생 연락처 : " + p[i]);
			}
		}
			
	}  // search() 메서드 end
	
	
	// 학생의 정보를 수정하는 메서드
	public static void modify(int[] h,
			String[] m, String[] p, Scanner sc) {
		
		System.out.print("수정할 학생의 학번을 입력하세요. : ");
		int hakbun = sc.nextInt();
		
		for(int i=0; i<m.length; i++) {
			
			if(hakbun == h[i]) {
				
				System.out.print("수정할 학생 학과 입력 : ");
				m[i] = sc.next();
				
				System.out.print("수정할 학생 연락처 입력 : ");
				p[i] = sc.next();
	
			}
		}
		
	}  // modify() 메서드 end
	
	
	// 프로그램을 종료하는 메서드.
	public static String end(Scanner sc) {
		
		System.out.print("프로그램을 종료하시겠습니까?(Y:종료 / N:계속) : ");
		
		return sc.next();
	}
	

	public static void main(String[] args) {
		
		Scanner sc = new Scanner(System.in);
		
		System.out.print("학생 수를 입력하세요. : ");
		
		// int studentCount = sc.nextInt();
		
		// 학생의 정보를 저장할 배열 선언 및 배열 메모리 생성.
		String[] names = new String[sc.nextInt()];
		int[] hakbuns = new int[names.length];
		String[] majors = new String[hakbuns.length];
		String[] phones = new String[majors.length];
		
		System.out.println("names >>> " + names);
		System.out.println("hakbuns >>> " + hakbuns);
		System.out.println("majors >>> " + majors);
		System.out.println("phones >>> " + phones);
		
		// 무한 반복을 통해서 학생관리 프로그램을 실행해야 한다.
		while(true) {
			System.out.println("*** 학생관리 프로그램 ***");
			System.out.println("1. 학생 등록");
			System.out.println("2. 전체 출력");
			System.out.println("3. 학생 조회");
			System.out.println("4. 정보 수정");
			System.out.println("5. 프로그램 종료");
			
			System.out.println();
			
			String result = "";
			
			System.out.print("학생 관리 메뉴 중 번호 하나를 선택하세요. : ");
			
			switch(sc.nextInt()) {
				case 1 :  // 학생 등록 메뉴 선택.
					// 학생 등록 메서드 호출
					// call by reference로 작업이 되어야 함.
					input(names, hakbuns, majors, phones, sc);
					break;
					
				case 2 :  // 전체 출력 메뉴 선택.
					// 전체 출력 메서드 호출
					output(names, hakbuns, majors, phones);
					break;
					
				case 3 :  // 학생 조회 메뉴 선택.
					// 학생 조회 메서드 호출
					search(names, hakbuns, majors, phones, sc);
					break;
					
				case 4 :  // 정보 수정 메뉴 선택.
					// 학생 정보 수정 메서드 호출
					modify(hakbuns, majors, phones, sc);
					break;
					
				case 5 :  // 프로그램 종료 메뉴 선택.
					// 프로그램 종료하는 메서드 호출
					result = end(sc);
					break;
			}  // switch ~ case 문 end
			
			if(result.equalsIgnoreCase("Y")) {
				break;
			}
			
		}  // while 반복문 end
		
		System.out.println("프로그램이 종료 되었습니다. 수고 하셨습니다.!!!");

	}

}
