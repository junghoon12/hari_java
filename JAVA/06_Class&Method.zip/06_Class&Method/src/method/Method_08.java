package method;

// 메서드 호출 시 반환형에 대한 내용

public class Method_08 {

	// 값이 반환이 된 경우
	public static int method1() {
		
		return 178;
	}
	
	// 변수명이 반환이 되는 경우
	public static int method2(int su1, int su2) {
		
		int sum = (su1 * 2) + (su2 * 2);
		
		return sum;
	}
	
	
	// 수식이 반환되는 경우
	public static int method3(int su1, int su2) {
	
		return su1 * su2;
	}
	
	
	public static void main(String[] args) {
		
		// int su = method1();
		
		System.out.println("method1() 메서드 호출 후 반환된 값 >>> " + method1());
		
		System.out.println("method2() 메서드 호출 후 반환된 값 >>> " + method2(200, 144));
		
		System.out.println("method3() 메서드 호출 후 반환된 값 >>> " + method3(200, 144));
			

	}

}
