package method;

/*
 * [문제] 1 ~ 100까지의 합을 구하는 메서드를 만들고
 *       호출하여 결과를 화면에 보여주세요..
 */

public class Method_02 {
	
	public static void total() {
		int sum = 0;
		
		for(int i=1; i<=100; i++) {
			
			sum += i;
		}
		
		System.out.println("1 ~ 100 까지의 합 >>> " + sum);
		
	}  // total() 메서드 end

	public static void main(String[] args) {
		
		// 메서드 호출
		total();

	}

}
