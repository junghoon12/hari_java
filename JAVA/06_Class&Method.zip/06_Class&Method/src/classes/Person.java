package classes;

public class Person {

	// 멤버변수
	String name;
	int age;
	boolean marriage;
	
	public Person() { }  // 기본 생성자
	
	// 멤버메서드
	void getPersonInfo() {
		
		String marr = "";
		
		if(marriage) {
			marr = "기혼";
		}else {
			marr = "미혼";
		}
		
		System.out.println("이 름 >>> " + name);    // null
		
		System.out.println("나 이 >>> " + age);     // 0
		
		System.out.println("결혼여부 >>> " + marr);  // 미혼
		
	}  // getPersonInfo() 메서드 end
	
}
