package exam;

public class Exam_03_05 {

	public static void main(String[] args) {
		
		// 1. 다차원 배열 선언 및 메모리 할당.
		int[][] arr = new int[5][5];
		
		int count = 1;
		
		// 2. 5행5열 다차원 배열에 데이터를 저장해 보자.
		for(int i=0; i<arr.length; i++) {         // 열
			 
			for(int j=0; j<arr[i].length; j++) {  // 행
				
				arr[j][i] = count++;
			}
		}
		
		// 3. 다차원 배열을 화면에 출력해 보자.
		for(int i=0; i<arr.length; i++) {         // 열
			 
			for(int j=0; j<arr[i].length; j++) {  // 행
				
				System.out.printf("%2d\t",arr[i][j]);
			}
			
			System.out.println();
		}

	}

}
