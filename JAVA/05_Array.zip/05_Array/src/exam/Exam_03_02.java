package exam;

public class Exam_03_02 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
