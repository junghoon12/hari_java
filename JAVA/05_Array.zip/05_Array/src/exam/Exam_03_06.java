package exam;

// 다차원 배열의 가변 배열을 이용하자.

public class Exam_03_06 {

	public static void main(String[] args) {

		// 1. 다차원 배열의 가변 배열 선언 및 메모리 할당.
		int[][] arr = new int[5][];
		
		int count = 1;
		
		// 가변 배열의 열을 메모리에 할당을 해 주자.
		// arr[0] = new int[1];    // 1행1열
		// arr[1] = new int[2];    // 2행2열
		// arr[2] = new int[3];    // 3행3열
		// arr[3] = new int[4];    // 4행4열
		// arr[4] = new int[5];    // 5행5열
		
		for(int i=0; i<arr.length; i++) {
			
			arr[i] = new int[i+1];
		}
		
		// 가변 배열에 데이터를 저장해 주자.
		for(int i=0; i<arr.length; i++) {
			
			for(int j=0; j<arr[i].length; j++) {
				
				arr[i][j] = count++;
			}
		}
		
		// 가변 배열에 저장된 데이터를 화면에 출력해 보자.
		for(int i=0; i<arr.length; i++) {
			
			for(int j=0; j<arr[i].length; j++) {
				
				System.out.printf("%2d\t", arr[i][j]);
			}
			
			System.out.println();
		}

	}

}
