package goott;

import java.util.Scanner;

/*
 * [문제] for 반복문을 이용하여 키보드로 입력받은 수 까지의
 *       홀수의 합과 짝수의 합을 구하여 화면에 보여주세요.
 */

public class ForExam_25 {

	public static void main(String[] args) {
		
		int oddSum = 0, evenSum = 0;
		
		Scanner sc = new Scanner(System.in);
		
		System.out.print("입력받을 최대 정수를 입력하세요. : ");
		
		int max = sc.nextInt();
		
		for(int su = 1; su <= max; su++) {
			
			if(su % 2 == 1) {
				
				oddSum = oddSum + su;
			}else {
				evenSum += su;  // evenSum = evenSum + su;
			}
			
		}  // for 반복문 end
		
		System.out.println(max + " 까지의 홀수의 합 >>> " + oddSum);
		
		System.out.println(max + " 까지의 짝수의 합 >>> " + evenSum);

		sc.close();
	}

}
