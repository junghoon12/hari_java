package goott;

import java.util.Scanner;

/*
 * [문제] 키보드로 입력 받은 정수 값이 음수이면 
 *       "입력 받은 정수는 음수입니다." 라는 
 *       메세지를 화면에 출력해 보세요.
 */

public class IfExam_04 {

	public static void main(String[] args) {
		
		// 1. 키보드로부터 정수 하나를 입력을 받자.
		Scanner sc = new Scanner(System.in);
		
		System.out.print("정수 하나를 입력하세요. : ");
		
		int su = sc.nextInt();
		
		// 2. 입력받은 정수가 양수인지 음수인지 판별을 하자.
		if(su < 0) {
			// 3. 입력받은 정수가 음수이면 메세지를 화면에 출력을 하자.
			System.out.println("입력 받은 " + su + "은(는) 음수입니다.");
		}
		
		sc.close();

	}

}
