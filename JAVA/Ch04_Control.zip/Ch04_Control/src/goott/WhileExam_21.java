package goott;

import java.util.Scanner;

/*
 * while문을 이용하여 -1이 입력될 때까지
 * 정수를 계속 입력을 받아서 합을 구하고,
 * -1이 입력이 되면 while문을 빠져 나와서
 * 평균을 구하는 프로그램을 만들어 보자.
 */

public class WhileExam_21 {

	public static void main(String[] args) {
		
		Scanner sc = new Scanner(System.in);
		
		int count = 0; // 입력된 정수의 갯수가 저장될 변수
		int sum = 0;   // 합이 저장될 변수.
		
		System.out.println("계속적으로 정수를 입력을 하고 마지막에 -1을 입력하세요.....");
		
		int su = sc.nextInt();
		
		while(su != -1) {
			
			sum = sum + su;
			
			count++;
			
			su = sc.nextInt();
		}
		
		System.out.println("입력된 정수의 갯수는 " + count + " 입니다.");
		System.out.println
			("입력된 정수의 평균은 " + (double)sum / count + " 입니다.");

		sc.close();
	}

	
}
