package goott;

import java.util.Scanner;

/*
 * [문제] 이름과 국어점수, 영어점수, 자바점수를 키보드로 입력을 받아서
 *       아래와 같이 성적을 화면에 출력해 보세요.
 *       
 *       출력화면) 이   름 : O O O
 *               국어점수 : OO 점
 *               영어점수 : OO 점
 *               자바점수 : OO 점
 *               총   점 : OOO 점
 *               평   균 : OO.OO 점
 *               학   점 : O 학점
 *               
 *      학점 기준 : A학점(90점 이상)
 *                B학점(80 ~ 89점)
 *                C학점(70 ~ 79점)
 *                D학점(60 ~ 69점)
 *                F학점(59점 이하)
 */

public class IfElseIfExam_11 {

	public static void main(String[] args) {
		
		// 1. 키보드 입력 준비 작업
		Scanner sc = new Scanner(System.in);
		
		// 2-1. 키보드로 이름을 입력을 받자.
		System.out.print("이름을 입력하세요. : ");
		String name = sc.next();
		
		// 2-2. 키보드로 국어점수를 입력을 받자.
		System.out.print("국어 점수 입력 : ");
		int kor = sc.nextInt();
		
		// 2-2. 키보드로 영어점수를 입력을 받자.
		System.out.print("영어 점수 입력 : ");
		int eng = sc.nextInt();
		
		// 2-2. 키보드로 자바점수를 입력을 받자.
		System.out.print("자바 점수 입력 : ");
		int java = sc.nextInt();
		
		System.out.println();
		
		// 3. 총점을 구하자.
		// 총점 = 각 과목의 점수를 더해 주면 됨.
		int sum = kor + eng + java;
		
		// 4. 평균을 구하자.
		// 평균 = 총점 / 과목 수
		double avg = sum / 3.0;
		
		// 5. 학점을 구하자.
		// 학점은 평균을 가지고 구함. ==> 다중 if~else문 이용
		String grade;
		
		if(avg >= 90) {
			grade = "A학점";
		}else if(avg >= 80) {
			grade = "B학점";
		}else if(avg >= 70) {
			grade = "C학점";
		}else if(avg >= 60) {
			grade = "D학점";
		}else {
			grade = "F학점";
		}
		
		// 6. 성적 처리한 결과를 화면에 보여주자.
		System.out.println("이   름 : " + name);
		System.out.println("국어점수 : " + kor + " 점");
		System.out.println("영어점수 : " + eng + " 점");
		System.out.println("자바점수 : " + java + " 점");
		System.out.println("총   점 : " + sum + " 점");
		System.out.printf("평   균 : %.2f점\n", avg);
		System.out.println("학   점 : " + grade);
		
		sc.close();
	}

}
