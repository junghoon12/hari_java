package goott;

import java.util.Scanner;

/*
 * [문제] 키보드로 정수 하나를 입력 받아서 입력 받은 정수가
 *       5의 배수이면 "이 정수는 5의 배수입니다." 라는 
 *       메세지를 화면에 출력해 보세요.
 */

public class IfExam_03 {

	public static void main(String[] args) {
		
		Scanner sc = new Scanner(System.in);
		
		// 1. 키보드로부터 정수 하나를 입력을 받자.
		System.out.print("정수 하나를 입력하세요. : ");
		
		int su = sc.nextInt();
		
		// 2. 조건식을 이용하여 5의 배수인지 판별을 하자.
		if((su % 5) == 0) {
			// 3. 5의 배수이면 콘솔에 출력을 하자.
			System.out.println(su + "은(는) 5의 배수입니다.");
		}
		
		sc.close();
		
	}

}
