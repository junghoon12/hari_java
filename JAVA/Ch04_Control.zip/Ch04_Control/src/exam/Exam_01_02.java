package exam;

import java.util.Scanner;

public class Exam_01_02 {

	public static void main(String[] args) {
		
		// 1. 키보드로 입력받을 준비 작업.
		Scanner sc = new Scanner(System.in);
		
		// 2. 임의의 숫자 하나를 입력을 받자.
		System.out.print("임의의 정수를 입력하세요. : ");
		
		int su = sc.nextInt();
		
		if(su > 0) {
			
			System.out.println("입력 받은 정수 >>> " + su);
			
			// 3-1. 입력 받은 정수의 제곱을 구하자.
			System.out.println(su + " 의 제곱 >>> " + (su * su));
			
			// 3-2. 입력 받은 정수의 세제곱을 구하자.
			System.out.println(su + " 의 세제곱 >>> " + (su * su * su));
			
		}else {
			System.out.println("양수를 입력해 주세요.~~~");
		}
		
		sc.close();
	}

}
