package exam;

import java.util.Scanner;

// 키보드로 입력 받은 수 까지의 
// 홀수의 합과 짝수의 합을 구하시오.

public class Exam_02_02 {

	public static void main(String[] args) {
		
		Scanner sc = new Scanner(System.in);
		
		int oddSum = 0, evenSum = 0;
		
		System.out.print("수 입력 : ");
		
		int su = sc.nextInt();
		
		for(int i=1; i<=su; i++) {
			
			if(i % 2 == 1) {
				oddSum += i;
			}else {
				evenSum += i;
			}
		}
		
		System.out.println(su +"까지의 홀수의 합 >>> " + oddSum);
		
		System.out.println(su +"까지의 짝수의 합 >>> " + evenSum);
		
		sc.close();
	}

}
