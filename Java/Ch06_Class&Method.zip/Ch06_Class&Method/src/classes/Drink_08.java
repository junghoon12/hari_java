package classes;

import java.util.Scanner;

public class Drink_08 {

	public static void main(String[] args) {
		
		Scanner sc = new Scanner(System.in);
		
		System.out.print("자판기 음료 갯수를 입력하세요. : ");
		
		Drink[] drinks = new Drink[sc.nextInt()];
		
		for(int i = 0; i < drinks.length; i++) {
			
			System.out.println("음료의 이름과 가격을 입력하세요.....");
			System.out.println("==================================");
			
			drinks[i] = new Drink(sc.next(), sc.nextInt());
			
		}
		
		System.out.println();
		
		System.out.print("돈을 입력해 주세요. : ");
		
		int coin = sc.nextInt();
		
		for( int i = 0; i < drinks.length; i++) {
			
			if(coin >= drinks[i].price) {
				
				System.out.print(drinks[i].name + "\t");
			}
		}
		
		sc.close();

	}

}
