package classes;

public class TV_02 {

	public static void main(String[] args) {
		
		// TV 객체 생성
		TV tv = new TV();
		
		tv.display();
		
		System.out.println();
		
		tv.color = "검정색";
		tv.channel = 5;
		tv.channelUp();       // 채널을 증가시키는 메서드 호출
		tv.display();
		
		System.out.println();
		
		tv.power();           // 전원을 On 시키는 메서드 호출
		tv.channelUp();
		tv.display();
		
		System.out.println();
		
		/*
		 * [문제1] TV 객체를 만들되 tv1 이라는 참조변수를 이용하여
		 *        객체를 만들고 아래와 같이 조건에 맞게 실행해 보세요.
		 *        조건1) 색상:흰색, 전원:Off, 채널:15
		 *        조건2) tv1 정보를 화면에 출력해 보세요.
		 *              ==> display() 메서드를 이용하면 됨.
		 *        조건3) tv1 정보를 다음과 같이 변경하여 화면에 출력해 보세요.
		 *              색상:흰색, 전원:On, 채널:28
		 */
		TV tv1 = new TV();
		
		tv1.color = "흰색";
		
		tv1.channel = 15;
		
		tv1.display();
		
		System.out.println();
		
		// 조건3) ==> 색상:흰색, 전원:On, 채널:28
		tv1.power();
		
		for(int i=tv1.channel; i<28; i++) {
			
			tv1.channelUp();
		}
		
		tv1.display();
		
		System.out.println();
		
		
		/*s
		 * [문제2] TV 객체를 만들되 tv2 이라는 참조변수를 이용하여
		 *        객체를 만들고 아래와 같이 조건에 맞게 실행해 보세요.
		 *        조건1) 색상:흰색, 전원:Off, 채널:32
		 *        조건2) tv2 정보를 화면에 출력해 보세요.
		 *              ==> display() 메서드를 이용하면 됨.
		 *        조건3) tv2 정보를 다음과 같이 변경하여 화면에 출력해 보세요.
		 *              색상:검정색, 전원:On, 채널:11
		 */
		TV tv2 = new TV();
		
		tv2.color = "흰색";
		
		tv2.channel = 32;

		tv2.display();
		
		System.out.println();
		
		// 조건3)  ==> 색상:검정색, 전원:On, 채널:11
		
		tv2.color = "검정색";
		
		tv2.power();
		
		for(int i=tv2.channel; i > 11; i--) {
			
			tv2.channelDown();
		}
		
		tv2.display();
	}

}
