package classes;

public class Number_10 {

	public static void main(String[] args) {
		
		Number number = new Number();
		
		// 직접적으로 접근이 안됨 - private 접근지정자 때문임.
		// number.num1 = 100;
		
		number.setNum1(200);
		
		number.setNum2(100);
		
		System.out.println("num1 >>> " + number.getNum1());
		
		System.out.println("num2 >>> " + number.getNum2());
		

	}

}
