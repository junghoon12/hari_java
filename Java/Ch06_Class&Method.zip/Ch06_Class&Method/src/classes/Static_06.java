package classes;

public class Static_06 {

	public static void main(String[] args) {
		
		System.out.println("num(static) 변수 >>> " +  Static.num);
		
		System.out.println("adder() 메서드 호출 >>> " + Static.adder(150, 37));

	}

}
