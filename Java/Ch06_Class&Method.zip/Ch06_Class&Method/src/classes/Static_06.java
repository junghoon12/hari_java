package classes;

public class Static_06 {

	public static void main(String[] args) {
		
		System.out.println("num(static) 변수 >>> " +  Static.num);
		
		System.out.println("adder() 메서드 호출 >>> " + Static.adder(150, 37));
		
		Static static1 = new Static();
		
		System.out.println("su1(인스턴스) 멤버변수 >>> " + static1.su1);
		
		System.out.println("su2(인스턴스) 멤버변수 >>> " + static1.su2);
		
		static1.sum();
		

	}

}
