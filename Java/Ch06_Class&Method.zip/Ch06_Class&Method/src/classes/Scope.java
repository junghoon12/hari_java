package classes;

public class Scope {

	int su = 30;         // 전역변수
	
	void output() {
		
		int su = 10;     // 지역변수
		
		System.out.println("su >>> " + su);
		
		System.out.println("su >>> " + this.su);
		
	}
}
