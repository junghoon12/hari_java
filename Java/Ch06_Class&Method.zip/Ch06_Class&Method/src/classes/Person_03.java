package classes;

public class Person_03 {

	public static void main(String[] args) {
		
		Person person = new Person();
		
		person.getPersonInfo();
		
		System.out.println();
		
		person.juminNo = "771210-1234567";
		
		person.name = "홍길동";
		
		person.age = 27;
		
		person.marriage = false;
		
		person.getPersonInfo();
		
		System.out.println();
		
		
		Person person1 = new Person();
		
		person1.juminNo = "951105-2345678";
		
		person1.name = "홍길자";
		
		person1.age = 55;
		
		person1.marriage = true;
		
		person1.getPersonInfo();
		
		System.out.println();
		
		Person person2 = new Person();
		
		person2.juminNo = "000401-4567810";
		
		person2.name = "임정은";
		
		person2.age = 25;
		
		person2.marriage = false;
		
		person2.getPersonInfo();
		

	}

}
