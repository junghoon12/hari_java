package classes;

import javax.swing.JOptionPane;

public class Person_03 {

	public static void main(String[] args) {
		
		Person person = new Person();
		
		person.name = JOptionPane.showInputDialog("이름을 입력하세요");
		
		person.age = 
			Integer.parseInt(JOptionPane.showInputDialog("나이를 입력하세요"));
		
		person.getPersonInfo();
		
		System.out.println();

	}

}
