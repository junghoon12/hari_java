package classes;


import javax.swing.JOptionPane;

public class Student_05 {

	public static void main(String[] args) {
				
		
		Student student = new Student
				(Integer.parseInt(JOptionPane.showInputDialog("학생의 학번을 입력하세요")), 
						JOptionPane.showInputDialog("학생의 이름을 입력하세요"), 
						JOptionPane.showInputDialog("학생의 학과를 입력하세요"), 
						JOptionPane.showInputDialog("학생의 연락처를 입력하세요"), 
						JOptionPane.showInputDialog("학생의 주소를 입력하세요"));
		
		student.getStudentInfo();
		

	}

}
