package method;

import java.util.Scanner;

/*
 * [문제] 키보드로 두개의 정수와 연산자를 입력 받아서
 *       연산자에 해당하는 기능을 하는 메서드를 호출 후
 *       연산을 수행 후 결과를 화면에 출력하도록 하세요.
 */

public class MethodExam_04 {
	
	public static void plus(int s1, int s2) {
		
		System.out.println("덧셈결과 >>> " + (s1 + s2));
		
	}  // plus() 메서드 end
	
	public static void minus(int s1, int s2) {
		
		System.out.println("뺄셈결과 >>> " + (s1 - s2));
		
	}  // minus() 메서드 end

	
	public static void multiply(int s1, int s2) {
	
		System.out.println("곱셈결과 >>> " + (s1 * s2));
	
	}  // multiply() 메서드 end

	
	public static void divide(int s1, int s2) {
	
		System.out.println("나눗셈(몫)결과 >>> " + (s1 / s2));
	
	}  // divide() 메서드 end

	
	public static void mod(int s1, int s2) {
	
		System.out.println("나머지결과 >>> " + (s1 % s2));
	
	}  // mod() 메서드 end

	
	public static void main(String[] args) {
		
		// 1. 키보드로 입력 받을 준비 작업.
		Scanner sc = new Scanner(System.in);
		
		// 2. 키보드로 두 개의 정수와 연산자를 입력을 받자.
		System.out.print("첫번째 정수 입력 : ");
		int su1 = sc.nextInt();
		
		System.out.print("두번째 정수 입력 : ");
		int su2 = sc.nextInt();
		
		System.out.print("연산자(+, -, *, /, %) 중 하나 입력 : ");
		String op = sc.next();
		
		// 3. 연산자 변수에 입력된 연산 기호를 가지고
		//    해당 기호에 맞는 메서드를 호출해 주면 된다.
		switch(op) {
			case "+" :
				plus(su1, su2);
				break;
			case "-" :
				minus(su1, su2);
				break;
			case "*" :
				multiply(su1, su2);
				break;
			case "/" :
				divide(su1, su2);
				break;
			case "%" :
				mod(su1, su2);
				break;
		}
		
		sc.close();

	}

}
