package method;

public class MethodExam_04 {

	public static void total(int start, int end) {
		
		int sum = 0;
		
		for(int i=start; i<=end; i++) {
			
			sum += i;
		}
		
		System.out.println(start+"  ~ "+end+" 까지의 합 >>> " + sum);
		
	}  // total() 메서드 end
	
	public static void main(String[] args) {
		
		total(20, 200);
		total(1, 100);

	}

}
