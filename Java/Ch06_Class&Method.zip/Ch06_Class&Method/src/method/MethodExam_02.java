package method;

// [문제] 1 ~ 100 까지의 합을 구하는 메서드를 
//       만들고 호출하여 화면에 출력해 보세요.

public class MethodExam_02 {

	public static void sum() {
		
		int sum = 0;
		
		for(int i=1; i<=100; i++) {
			
			sum += i;
		}
		
		System.out.println("1 ~ 100 까지의 합 >>> " + sum);
		
	}  // sum() 메서드 end 
	
	public static void main(String[] args) {

		sum();

	}

}
