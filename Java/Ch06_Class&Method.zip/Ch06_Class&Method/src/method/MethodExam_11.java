package method;

public class MethodExam_11 {

	// 2과목의 총점을 구하는 메서드.
	public static int sum2(int k, int e) {
		
		return k + e;
	}
	
	// 3과목의 총점을 구하는 메서드.
	public static int sum3(int k, int e, int m) {
		
		return k + e + m;
	}
	
	// 4과목의 총점을 구하는 메서드.
	public static int sum4(int k, int e, int m, int j) {
		
		return k + e + m + j;
	}
	
	
	public static void main(String[] args) {
		
		int kor = 92, eng = 88, mat = 71, java = 95;
		
		System.out.println("2과목 총점 >>> " + sum2(kor, eng));

		System.out.println("3과목 총점 >>> " + sum3(kor, eng, mat));
		
		System.out.println("4과목 총점 >>> " + sum4(kor, eng, mat, java));

	}

}
