package method;

import java.util.Scanner;

/*
 * [문제] 성적 처리 프로그램
 *       main() 메서드에서는 키보드로 이름, 국어점수, 영어점수, 수학점수를
 *       입력을 받고, 총점과 평균, 학점 메서드를 만들어서 메서드 호출을 하여
 *       성적을 처리한 후에 결과를 화면에 출력해 보세요.
 *       
 *       출력 화면 예시
 *       이   름 : 홍길동
 *       국어점수 : OO점
 *       영어점수 : OO점
 *       수학점수 : OO점
 *       총   점 : OOO점
 *       평   균 : OO.OO점
 *       학   점 : O학점
 */

public class MethodExam_08 {
	
	// 총점을 구하는 메서드
	public static int total(int kor, int eng, int mat) {
		
		return kor + eng + mat;
		
	}  // total() 메서드 end
	
	// 평균을 구하는 메서드
	public static double average(int tot) {
		
		return tot / 3.0;
		
	}  // average() 메서드 end
	
	
	public static String hakjum(double avg) {
		
		String grade;
		
		if(avg >= 90) {
			grade = "A학점";
		}else if(avg >= 80) {
			grade = "B학점";
		}else if(avg >= 70) {
			grade = "C학점";
		}else if(avg >= 60) {
			grade = "D학점";
		}else {
			grade = "F학점";
		}
		
		return grade;
		
	}  // hakjum() 메서드 end

	public static void main(String[] args) {
		
		// 1. 키보드로 데이터 입력 받을 준비 작업.
		Scanner sc = new Scanner(System.in);
		
		// 2. 키보드로 이름, 국어점수, 영어점수, 수학점수를 입력을 받자.
		System.out.print("이름을 입력하세요. : ");
		String name = sc.next();
		
		System.out.print("국어점수를 입력하세요. : ");
		int kor = sc.nextInt();
		
		System.out.print("영어점수를 입력하세요. : ");
		int eng = sc.nextInt();
		
		System.out.print("수학점수를 입력하세요. : ");
		int mat = sc.nextInt();
		
		System.out.println();
		
		
		// 3. 총점을 구하자. ==> 총점 메서드 호출
		int sum = total(kor, eng, mat);
		
		// 4. 평균을 구하자. ==> 평균 메서드 호출
		double avg = average(sum);
		
		// 5. 학점을 구하자. ==> 학점 메서드 호출
		String grade = hakjum(avg);
		
		
		// 6. 성적 결과를 화면에 출력해 보자.
		System.out.println("이   름 : " + name);
		System.out.println("국어점수 : " + kor + "점");
		System.out.println("영어점수 : " + eng + "점");
		System.out.println("수학점수 : " + mat + "점");
		System.out.println("총   점 : " + sum + "점");
		System.out.printf("평   균 : %.2f점\n", avg);
		System.out.println("학   점 : " + grade);
		
		
		sc.close();

	}

}





