package exam;


import javax.swing.JOptionPane;

public class Exam_06 {

	// 클래스 멤버(정적-static) 멤버 선언
	public static final double TAX_RATE = 1.1;
	
	public static void main(String[] args) {
		
		Receipt[] receipts = new Receipt[
		          Integer.parseInt(JOptionPane.showInputDialog("메뉴는 몇개인가요?"))];
		
		// 메뉴와 단가, 수량을 키보드로 입력을 받아서
		// 객체에 저장을 해 주면 됨 - 메뉴 수만큼 반복하여
		for(int i = 0; i < receipts.length; i++) {
			
			receipts[i] = new Receipt(
					JOptionPane.showInputDialog("메뉴 이름을 입력하세요"), 
					Integer.parseInt(JOptionPane.showInputDialog("메뉴의 가격을 입력하세요.")),
					Integer.parseInt(JOptionPane.showInputDialog("메뉴의 수량을 입력하세요.")));
					
		}
		
		System.out.println();
		
		int totalPrice = 0;         // 총금액(청구금액) 변수
		
		System.out.println("----------------------------------------------");
		System.out.println("품명\t단가\t수량\t금액");
		System.out.println("----------------------------------------------");
		
		for(int i = 0; i < receipts.length; i++) {
			
			System.out.printf("%s\t%,d\t%,d\t%,d원\n",
						receipts[i].name, receipts[i].unitPrice,
						receipts[i].amount,
						(receipts[i].unitPrice * receipts[i].amount)
					);
			
			totalPrice += (receipts[i].unitPrice * receipts[i].amount);
		}
		
		// 공급가액 = 총금액 / 부가세율
		int supplyPrice = (int)(totalPrice / Exam_06.TAX_RATE);
		
		// 부가세액 = 총금액 - 공급가액
		int vat = totalPrice - supplyPrice;
		
		System.out.println("----------------------------------------------");
		System.out.printf("공급가액\t\t\t%,d원\n", supplyPrice);
		System.out.printf("부가세액\t\t\t%,d원\n", vat);
		System.out.println("----------------------------------------------");
		System.out.printf("청구금액\t\t\t%,d원\n", totalPrice);

	}

}
