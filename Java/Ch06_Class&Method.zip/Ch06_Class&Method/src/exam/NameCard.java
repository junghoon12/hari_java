package exam;

public class NameCard {

	// 멤버변수
	String name;             // 이름
	String phone;            // 전화번호
	String addr;             // 주소
	String position;         // 직급
	
	public NameCard() {  }   // 기본 생성자
	
	public NameCard(String name, String phone,
			String addr, String position) {
		
		this.name = name;
		this.phone = phone;
		this.addr = addr;
		this.position = position;
		
	}   // 인자 생성자
	
	// 멤버메서드
	void getNameCardInfo() {
		
		System.out.println("이   름 : " + name);
		System.out.println("전화번호 : " + phone);
		System.out.println("주   소 : " + addr);
		System.out.println("직   급 : " + position);
	
	}  // getNameCardinfo() 메서드
	
}








