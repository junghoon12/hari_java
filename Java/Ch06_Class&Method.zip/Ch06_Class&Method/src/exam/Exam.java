package exam;

import java.util.Scanner;

// 학생 관리 프로그램

public class Exam {
	
	public static void input(String[] n, int[] h,
			String[] m, String[] p, Scanner sc) {
		
		System.out.println("n 배열 주소 >>> " + n);
		System.out.println("h 배열 주소 >>> " + h);
		System.out.println("m 배열 주소 >>> " + m);
		System.out.println("p 배열 주소 >>> " + p);
		
		for(int i=0; i<n.length; i++) {
			
			System.out.println("<<< " + (i+1)+ " 번째 학생 정보 입력 >>> ");
			
			System.out.print("학생 이름 입력 : ");
			n[i] = sc.next();
			
			System.out.print("학생 학번 입력 : ");
			h[i] = sc.nextInt();
			
			System.out.print("학생 학과 입력 : ");
			m[i] = sc.next();
			
			System.out.print("학생 연락처 입력 : ");
			p[i] = sc.next();
			
			System.out.println();
		}
		
	}  // input() 메서드 end
	
	// 학생 정보를 출력하는 메서드.
	public static void output(String[] na, int[] ha,
			String[] ma, String[] ph) {
		
		for(int i=0; i<ha.length; i++) {
			
			System.out.println("*** " + (i+1) + " 번째 학생 정보 ***");
			
			System.out.println("학생 이름 : " + na[i]);
			System.out.println("학생 학번 : " + ha[i]);
			System.out.println("학생 학과 : " + ma[i]);
			System.out.println("학생 연락처 : " + ph[i]);
			System.out.println("::::::::::::::::::::::::::::::::::");
		}
		
	}  // output() 메서드 end
	
	// 학생 정보를 조회하는 메서드.
	public static void search(String[] n, int[] h,
			String[] m, String[] p, Scanner sc) {
		
		System.out.print("조회할 학생의 학번을 입력하세요. : ");
		int hakbun = sc.nextInt();
		
		for(int i=0; i<p.length; i++) {
			
			if(hakbun == h[i]) {
				System.out.println("학생 이름 : " + n[i]);
				System.out.println("학생 학번 : " + h[i]);
				System.out.println("학생 학과 : " + m[i]);
				System.out.println("학생 연락처 : " + p[i]);
			}
		}
		
	}  // search() 메서드 end
	
	
	// 학생의 정보를 수정하는 메서드
	public static void modify(int[] h,
			String[] m, String[] p, Scanner sc) {
		
		System.out.print("수정할 학생의 학번을 입력하세요. : ");
		int hakbun = sc.nextInt();
		
		for(int i=0; i<m.length; i++) {
			
			if(hakbun == h[i]) {
				
				System.out.print("수정할 학생의 학과 입력 : ");
				m[i] = sc.next();
				
				System.out.print("수정할 학생의 연락처 입력 : ");
				p[i] = sc.next();
			}
		}
		
	}  // modify() 메서드 end
	
	
	// 프로그램을 종료하는 메서드.
	public static String end(Scanner sc) {
		
		System.out.println("프로그램을 종료하시겠습니까?(Y:종료 / N:계속) : ");
		
		return sc.next();
		
	}  // end() 메서드 end
	
	

	public static void main(String[] args) {
		
		// 1. 키보드 준비 작업
		Scanner sc = new Scanner(System.in);
		
		System.out.print("학생 수를 입력하세요. : ");
		
		// int studentCount = sc.nextInt();
		
		// 2. 학생의 정보를 저장할 배열 선언 및 배열 메모리 생성.
		String[] names = new String[sc.nextInt()];  // 학생 이름 배열
		int[] hakbuns = new int[names.length];      // 학생 학번 배열
		String[] majors = new String[names.length]; // 학생 학과 배열
		String[] phones = new String[names.length]; // 학생 연락처 배열
		
		System.out.println("names 배열 주소 >>> " + names);
		System.out.println("hakbuns 배열 주소 >>> " + hakbuns);
		System.out.println("majors 배열 주소 >>> " + majors);
		System.out.println("phones 배열 주소 >>> " + phones);
		
		// 3. 무한반복을 통하여 학생관리 프로그램을 실행해야 한다.
		while(true) {
			
			System.out.println("1. 학생 등록");
			System.out.println("2. 전체 출력");
			System.out.println("3. 학생 조회");
			System.out.println("4. 정보 수정");
			System.out.println("5. 프로그램 종료");
			System.out.println();
			
			System.out.print("학생 관리 메뉴 중 하나를 선택하세요. : ");
			
			int menu = sc.nextInt();
			
			String res = "";
			
			switch(menu) {
				case 1 :  // 학생 등록 메뉴 선택.
					// 학생 등록 메서드 호출.
					input(names, hakbuns, majors, phones, sc);
					break;
				
				case 2 :  // 전체 학생 출력 메뉴 선택.
					// 전체 학생 출력 메서드 호출.
					output(names, hakbuns, majors, phones);
					break;
					
				case 3 : // 학생 정보 조회 메뉴 선택.
					// 학생 정보 조회하는 메서드 호출
					search(names, hakbuns, majors, phones, sc);
					break;
				
				case 4 : // 학생 정보 수정 메뉴 선택.
					// 학생 정보 수정하는 메서드 호출
					modify(hakbuns, majors, phones, sc);
					break;
					
				case 5 : // 프로그램 종료 메뉴 선택.
					// 프로그램을 종료하는 메서드 호출
					res = end(sc);
			}
			
			if(res.equalsIgnoreCase("Y")) {
				
				break;
			}
 					
		}  // while 반복문 end
		
		System.out.println("프로그램이 종료 되었습니다. 수고 하셨습니다.");
		
	}

}
