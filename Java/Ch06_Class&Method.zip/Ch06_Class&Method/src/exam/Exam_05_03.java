package exam;

import java.util.Scanner;

public class Exam_05_03 {

	public static void main(String[] args) {
		
		Scanner sc = new Scanner(System.in);
		
		System.out.println("이름, 전화번호, 주소, 직급을 입력하세요.....");
		
		NameCard card = 
			new NameCard(sc.nextLine(), sc.nextLine(), sc.nextLine(), sc.nextLine());
		
		System.out.println("======================================");
		
		card.getNameInfo();
		
		sc.close();
		
	}

}
