package exam;

import javax.swing.JOptionPane;

// 커피 자판기 메뉴

public class Exam_02_06 {

	public static void main(String[] args) {
		
		// 1. 메뉴 화면 만들어 보자.
		System.out.println("*** Coffee 메뉴 ***");
		System.out.println("1. 아메리카노 - 3,000원");
		System.out.println("2. 카페라떼 - 4,000원");
		System.out.println("3. 마끼아또 - 4,500원");
		System.out.println("4. 바닐라라떼 - 4,500원");
		
		// 2-1. 키보드로 메뉴 번호를 하나 입력을 받자.
		int menu = Integer.parseInt(JOptionPane.showInputDialog("위 메뉴 중 하나를 선택하세요."));
		
		// 2-2. 키보드로 주문 수량을 입력을 받자.
		int amount = Integer.parseInt(JOptionPane.showInputDialog("주문 수량을 입력하세요."));
		
		// 2-3. 키보드로 입금액을 입력을 받자.
		int money = Integer.parseInt(JOptionPane.showInputDialog("입금액을 입력하세요."));
		
		String coffeeStr = "";    // 커피 종류가 저장될 문자열 변수.
		int coffeePrice = 0;      // 커피 가격이 저장딜 정수형 변수.
		
		switch(menu) {
			case 1 : 
				coffeeStr = "아메리카노";
				coffeePrice = 3000;
				break;
			case 2 :
				coffeeStr = "카페라떼";
				coffeePrice = 4000;
				break;
			case 3 :
				coffeeStr = "마끼아또";
				coffeePrice = 4500;
				break;
			case 4 :
				coffeeStr = "바닐라라떼";
				coffeePrice = 4500;
				break;
		}
		
		
		// 3. 공급가액을 계산해 보자.
		// 공급가액 = 단가 * 수량
		int sum = coffeePrice * amount;
		
		// 4. 부가세액을 계산해 보자.
		// 부가세액 = 공급가액 * 0.1(10%)
		int vat = (int)(sum * 0.1);
		
		// 5. 총금액을 계산해 보자.
		// 총금액 = 공급가액 + 부가세액
		int total = sum + vat;
		
		// 6. 거스름돈(잔액)을 계산해 보자.
		// 거스름돈 = 입금액 - 총금액
		int result = money - total;
		
		
		// 7. 계산된 결과를 화면에 출력해 보자.
		System.out.println("주문한 커피메뉴 : " + coffeeStr);
		System.out.printf("커피 단가 : %,d원\n", coffeePrice);
		System.out.println("주문 수량 : " + amount);
		System.out.printf("입 금 액 : %,d원\n", money);
		System.out.printf("공급가액 : %,d원\n", sum);
		System.out.printf("부가세액 : %,d원\n", vat);
		System.out.printf("총 금 액 : %,d원\n", total);
		System.out.printf("거스름돈 : %,d원\n", result);
		
		
		
		
	}

}
