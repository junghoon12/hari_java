package exam;

import javax.swing.JOptionPane;

/*
 * 임의의 정수 하나를 입력 받아서 그 수의 
 * 제곱, 세제곱을 구하여 화면에 출력해 보세요.
 */

public class Exam_01_02 {

	public static void main(String[] args) {
		
		// 1. 임의의 정수 숫자 하나를 키보드로 입력을 받자.
		int su = Integer.parseInt(JOptionPane.showInputDialog("정수 하나를 입력하세요."));
		
		if(su > 0) {
			
			System.out.println("입력 받은 정수 >>> " + su);
			
			System.out.println(su + " 의 제곱 >>> " + (su * su));
			
			System.out.println(su + " 의 세제곱 >>> " + (su * su * su));
			
		}else {
			
			System.out.println("음수입니다. 양수 값을 입력하세요.");
		}
	}

}
