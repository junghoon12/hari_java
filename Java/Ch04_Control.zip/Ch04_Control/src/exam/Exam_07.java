package exam;

import java.util.Scanner;

// 별찍기 번외

public class Exam_07 {

	public static void main(String[] args) {
		
		Scanner sc = new Scanner(System.in);
		
		System.out.print("별의 최대 갯수를 입력하세요. : ");
		
		int starMax = sc.nextInt();
		
		int line = 0;    // 별을 찍을 라인 수
		
		// 전체 라인 수 ==> (입력받은 최대 별의 수 * 2) - 1
		for(int i = 1; i <= (starMax * 2 - 1); i++) {
			
			line = (i <= starMax) ? i : (starMax*2 - i);
			
			for(int j = 1; j <= line; j++) {
				
				System.out.print("*");
			}
			
			System.out.println();
		}
		
		sc.close();
		
		
		
		
	}

}
