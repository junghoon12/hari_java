package exam;

import java.util.Scanner;

// 키보드로 입력 받은 수까지의 홀수의 합, 짝수의 합 구하기.

public class Exam_04 {

	public static void main(String[] args) {

		Scanner sc = new Scanner(System.in);
		
		int oddSum = 0, evenSum = 0;
		
		System.out.print("수 입력 : ");
		
		int su = sc.nextInt();
		
		for(int i = 1; i <= su; i++) {
			
			if(i % 2 == 1) {
				oddSum += i;
			}else {
				evenSum += i;
			}
		}
		
		System.out.println("홀수 합계 : " + oddSum);
		
		System.out.println("짝수 합계 : " + evenSum);
		
		sc.close();

	}

}
