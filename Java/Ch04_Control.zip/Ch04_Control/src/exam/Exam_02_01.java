package exam;

import javax.swing.JOptionPane;

/*
 * 지방(fat), 탄수화물(carbohydrate), 단백질(protein) 
 * 칼로리의 합계를 계산하는 프로그램
 * 지방, 탄수화물, 단백질의 그램을 키보드로 입력
 * 총 칼로리 구하기
 * 지방 1그램 : 9칼로리
 * 단백질과 탄수화물 1그램 : 4칼로리
 * 총 칼로리 = 지방 * 9 + 단백질 * 4 + 탄수화물 * 4
 */

public class Exam_02_01 {

	public static void main(String[] args) {
		
		// 1-1. 지방의 그램을 키보드로 입력을 받자.
		int fat = Integer.parseInt(JOptionPane.showInputDialog("지방의 그램을 입력하세요."));
		
		// 1-2. 탄수화물의 그램을 키보드로 입력을 받자.
		int car = Integer.parseInt(JOptionPane.showInputDialog("탄수화물의 그램을 입력하세요."));
		
		// 1-3. 단백질의 그램을 키보드로 입력을 받자.
		int protein = Integer.parseInt(JOptionPane.showInputDialog("지방의 그램을 입력하세요."));
		

		// 2. 총 칼로리를 구하자.
		// 총 칼로리 = 지방 * 9 + 단백질 * 4 + 탄수화물 * 4
		int total = (fat * 9) + (protein * 4) + (car * 4);
		
		// 3. 총 칼로리를 화면에 출력해 보자.
		System.out.printf("총칼로리 : %,d cal\n", total);
		
	}

}
