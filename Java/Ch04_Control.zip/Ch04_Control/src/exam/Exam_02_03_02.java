package exam;

import javax.swing.JOptionPane;

public class Exam_02_03_02 {

	public static void main(String[] args) {
		
		int maxStarCnt = Integer.parseInt(JOptionPane.showInputDialog("별의 최대 갯수 입력"));
		
		int line;             // 별을 찍을 라인 수
		
		
		// 전체 행의 수 ==> (입력받은 최대 별의 수 * 2) - 1
		for(int i = 1; i <= (maxStarCnt * 2) - 1; i++) {
			
			line = (i <= maxStarCnt) ? i : (maxStarCnt * 2 - i);
			
			for(int j = 1; j <= line; j++) {
				
				System.out.print("*");
			}
			
			System.out.println();
			
		}
		

	}

}
