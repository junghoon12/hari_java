package exam;

// 1 - 2 + 3 - 4 + 5 - 6 + ........ - 100

public class Exam_01 {

	public static void main(String[] args) {
		
		int total = 0;    // 1 ~ 100까지 합을 저장할 변수
		
		for(int su = 1; su <= 100; su++) {
			
			if(su % 2 == 1) {
				// 홀수인 경우
				total = total + su;
			}else {
				// 짝수인 경우
				total = total - su;
			}
		}
		
		System.out.println("hap >>> " + total);
		

	}

}
