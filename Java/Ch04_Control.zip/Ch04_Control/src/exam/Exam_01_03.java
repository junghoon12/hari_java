package exam;

import javax.swing.JOptionPane;

/*
 * 키보드로 금액과 상품단가, 수량을 입력하면 부가세, 
 * 상품총액, 거스름돈을 화면에 보여주는 프로그램을 완성해 보세요.
 * ※ 부가세 : (상품단가 * 수량) 의 10% 
 * ※ 상품총액 : (상품단가 * 수량) + 부가세
 */

public class Exam_01_03 {

	public static void main(String[] args) {
		
		// 1-1. 키보드로 입금액을 입력을 받자.
		int money = Integer.parseInt(JOptionPane.showInputDialog("입금액 입력"));
		
		// 1-2. 키보드로 상품의 단가를 입력을 받자.
		int price = Integer.parseInt(JOptionPane.showInputDialog("상품 단가 입력"));
		
		// 1-3. 키브도르 상품의 수량을 입력을 받자.
		int amount = Integer.parseInt(JOptionPane.showInputDialog("상품 수량 입력"));
		
		
		// 2. 상품의 공급가액을 계산해 보자.
		// 공급가액 = 상품 단가 * 상품 수량
		int sum = price * amount;
		
		// 3. 상품의 부가세액을 계산해 보자.
		// 부가세액 = 공급가액 * 0.1(10%)
		int vat = (int)(sum * 0.1);
		
		// 4. 상품의 총금액을 계산해 보자.
		// 총금액 = 공급가액 + 부가세액
		int total = sum + vat;
		
		// 5. 잔액(거스름돈)을 계산해 보자.
		// 거스름돈 = 입금액 - 총금액
		int change = money - total;
		
		
		// 6. 계산된 내용을 화면에 출력해 보자.
		System.out.printf("지불한 금액 : %,d원\n", money);
		System.out.printf("제품 단가 : %,d원\n", price);
		System.out.printf("제품 수량 : %,d\n", amount);
		System.out.printf("공급가액 : %,d원\n", sum);
		System.out.printf("부가세액 : %,d원\n", vat);
		System.out.printf("상품총액 : %,d원\n", total);
		System.out.printf("거스름돈 : %,d원\n", change);
		
		
	}

}
