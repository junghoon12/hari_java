package exam;

import javax.swing.JOptionPane;

public class Exam_02_02 {

	public static void main(String[] args) {
		
		// 1. 홀수의 합 누적변수와 짝수의 합 누적변수를 만들자.
		int oddSum = 0, evenSum = 0;
		
		// 2. 키보드로 정수 하나를 입력을 받자.
		int su = Integer.parseInt(JOptionPane.showInputDialog("정수 하나 입력"));
		
		// 3. for 반복문을 이용하여 홀수의 합, 짝수의 합에 누적을 시키자.
		for(int i=1; i<=su; i++) {
			
			if(i % 2 == 1) {
				
				oddSum = oddSum + i;
			}else {
				
				evenSum = evenSum + i;
			}
		}
		
		// 4. 홀수의 합과 짝수의 합을 화면에 출력해 보자.
		System.out.println("1 ~ " + su + " 까지의 홀수의 합 : " + oddSum);
		System.out.println("1 ~ " + su + " 까지의 짝수의 합 : " + evenSum);

	}

}
