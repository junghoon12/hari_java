package exam;

import javax.swing.JOptionPane;

/*
 * 국어, 영어, 수학, 자바 변수를 만들고, 해당 변수에 키보드로 
 * 점수를 입력 후 총점과 평균을 구하여 화면에 출력해 보세요. 
 * 조건) 평균은 소숫점 이하 2자리까지만 출력할 것.
 */
		
public class Exam_01_01 {

	public static void main(String[] args) {
		
		// 1-1. 키보드로 국어 점수를 입력을 받자.
		int kor = Integer.parseInt(JOptionPane.showInputDialog("국어 점수 입력"));
		
		// 1-2. 키보드로 영어 점수를 입력을 받자.
		int eng = Integer.parseInt(JOptionPane.showInputDialog("영어 점수 입력"));
		
		// 1-3. 키보드로 수학 점수를 입력을 받자.
		int mat = Integer.parseInt(JOptionPane.showInputDialog("수학 점수 입력"));
		
		// 1-4. 키보드로 자바 점수를 입력을 받자.
		int java = Integer.parseInt(JOptionPane.showInputDialog("자바 점수 입력"));
		
		
		// 2. 총점을 구하자.
		// 총점 = 국어점수 + 영어점수 + 수학점수 + 자바점수
		int total = kor + eng + mat + java;
		
		// 3. 평균을 구하자.
		// 평균 = 총점 / 과목 수
		double avg = total / 4.0;
		
		
		// 4. 성적 결과를 화면에 출력하자.
		System.out.println("국어점수 : " + kor + "점");
		System.out.println("영어점수 : " + eng + "점");
		System.out.println("수학점수 : " + mat + "점");
		System.out.println("자바점수 : " + java + "점");
		System.out.println("총   점 : " + total + "점");
		System.out.printf("평   균 : %.2f점\n", avg);

		
	}

}
