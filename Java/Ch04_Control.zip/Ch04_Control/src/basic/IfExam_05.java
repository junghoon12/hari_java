package basic;

import java.util.Scanner;

/*
 * [문제] 키보드로부터 입력 받은 점수가 60점
 *       이상이면 "합격입니다." 라는 메세지를
 *       화면에 출력해 보세요. 
 */

public class IfExam_05 {

	public static void main(String[] args) {
	
		// 1. 키보드로 정수 하나를 입력을 받자.
		Scanner sc = new Scanner(System.in);
		
		System.out.print("점수를 입력해 주세요... : ");
		
		int score = sc.nextInt();
		
		// 2. 조건식을 이용하여 5의 배수인지 판별을 하자.
		if(score >= 60) {
			System.out.println("합격입니다.");
		}
		
		sc.close();

	}

}
