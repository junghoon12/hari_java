package basic;

public class WhileExam_18 {

	public static void main(String[] args) {
		
		// ABCDEFGHIJKLMNOPQRSTUVWXYZ 까지 문자를 출력해 보자.
		
		char alpha = 'A';             // 반복문에서 초기식
		
		while(alpha <= 'Z') {
			
			System.out.print(alpha);
			
			alpha++;
		}

		System.out.println();
		System.out.println();
		
		
		// ZYXWVUT....CBA 까지 문자를 출력해 보자.
		char alpha2 = 'Z';
		
		while(alpha2 >= 'A') {
			
			System.out.print(alpha2);
			
			alpha2--;
		}
		
		
	}

}
