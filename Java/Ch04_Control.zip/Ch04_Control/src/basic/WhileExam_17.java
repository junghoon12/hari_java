package basic;

import java.util.Scanner;

/*
 * [문제] 키보드로 입력받은 수까지의 홀수의 합과
 *       짝수의 합을 구하여 화면에 출력해 보세요.
 */

public class WhileExam_17 {

	public static void main(String[] args) {
		
		// 1. 필요한 변수 선언
		int su = 1;         // 반복문에서 필요한 변수 - 반복문에서 초기식
		int oddSum = 0, evenSum = 0; // 홀수의 합 변수, 짝수의 합 변수
		
		Scanner sc = new Scanner(System.in);
		
		System.out.print("정수 하나를 입력 : ");
		
		int max = sc.nextInt();
		
		while(su <= max) {
			
			if(su % 2 == 1) {
				// 홀수의 합 변수에 저장
				oddSum = oddSum + su;
			}else {
				// 짝수의 합 변수에 저장
				evenSum += su;  // evenSum = evenSum + su;
			}
			
			su++;
			
		}  // while 반복문 end
		
		System.out.println("1 부터 " + max + " 까지의 홀수의 합 : " + oddSum);
		
		System.out.println("1 부터 " + max + " 까지의 짝수의 합 : " + evenSum);

		System.out.println("1 부터 " + max + " 까지의 총 합 : " + (oddSum + evenSum));
		
		sc.close();

	}

}
