package basic;

import java.util.Scanner;

/*
 * [문제3] 키보드로 입력받은 정수가 5의 배수이면
 *        " 이 정수는 5의 배수입니다" 라는 메세지를
 *        화면에 출력하고, 5의 배수가 아니면
 *        "이 정수는 5의 배수가 아닙니다." 라는 메세지를
 *        화면에 출력해 보세요.
 *        단, 입력받은 정수가 음수이면 "음수가 입력되었습니다."
 *        라는 메세지를 화면에 출력해 보세요.
 */

public class IfElseExam_09 {

	public static void main(String[] args) {
		
		Scanner sc = new Scanner(System.in);
		
		System.out.print("정수 하나 입력 : ");
		
		int num = sc.nextInt();
		
		if(num > 0) {
			// 양수인 경우
			if(num % 5 == 0) {
				// 참인 경우 - 5의 배수
				System.out.println("입력 받은 "+num+ "은(는) 5의 배수입니다.");
			}else {
				// 거짓인 경우 - 5의 배수가 아님.
				System.out.println("입력 받은 "+num+ "은(는) 5의 배수가 아닙니다.");
			}
		}else {
			// 음수인 경우
			System.out.println("음수 값을 입력하시면 아니되옵니다.");
		}
	}

}
