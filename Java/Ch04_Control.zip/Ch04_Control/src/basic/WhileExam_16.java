package basic;

// while 반복문을 이용하여 1 ~ 10 까지의
// 합을 구해 보자.

public class WhileExam_16 {

	public static void main(String[] args) {
		
		// 1. 변수 선언
		// 반복문에서 사용할 초기식의 변수와 
		// 1~10까지 합을 저장할 변수.
		int num = 1, sum = 0;
		
		while(num <= 100) {
			
			sum = sum + num;
			
			num++;
		}  // while문 end
		
		System.out.println("1 ~ 10 까지의 합 : " + sum);
	}

}
