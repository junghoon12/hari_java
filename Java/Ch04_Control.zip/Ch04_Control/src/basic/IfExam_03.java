package basic;

import java.util.Scanner;

/*
 * [문제] 키보드로 임의의 정수 하나를 입력받아서 입력 받은
 *       정수가 5의 배수이면 "이 정수는 5의 배수입니다."
 *       라는 메세지를 화면에 출력해 보세요.
 */

public class IfExam_03 {

	public static void main(String[] args) {
		
		// 1. 키보드로 정수 하나를 입력을 받자.
		Scanner sc = new Scanner(System.in);
		
		System.out.print("정수를 입력해 주세요... : ");
		
		int su = sc.nextInt();
		
		// 2. 조건식을 이용하여 5의 배수인지 판별을 하자.
		if((su % 5) == 0) {
			System.out.println(su + "은(는) 5의 배수입니다.");
		}
		
		sc.close();

	}

}
