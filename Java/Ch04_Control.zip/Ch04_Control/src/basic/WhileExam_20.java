package basic;

import java.util.Scanner;

/*
 * while문을 이용하여 -1이 입력될 때까지
 * 정수를 계속 입력을 받아서 합을 구하고,
 * 몇 개의 정수가 입력이 되었는지 카운트 한 후에
 * -1이 입력이 되면 while문을 빠져 나와서
 * 입력된 정수의 합의 평균을 구하여 화면에 출력해 보세요. 
 */

public class WhileExam_20 {

	public static void main(String[] args) {
		
		Scanner sc = new Scanner(System.in);
		
		int count = 0;     // 입력된 정수의 갯수가 저장될 변수.
		int sum = 0;       // 합이 저장될 변수.
		
		System.out.println("계속적으로 정수를 입력하고 마지막에 -1을 입력하세요...");
		
		int su = sc.nextInt();
		
		while(su != -1) {
			
			sum = sum + su;
			
			count++;
			
			su = sc.nextInt();
			
		}
		
		System.out.println("입력된 정수의 count 는 " + count + " 입니다.");
		
		System.out.printf
			("입력된 정수의 평균은 %.2f 입니다\n", (sum / (double)count));
		
		sc.close();

	}

}
