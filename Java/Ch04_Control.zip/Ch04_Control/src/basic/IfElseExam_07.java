package basic;

import java.util.Scanner;

/*
 * [문제1] 키보드로 점수를 입력받아서 입력 받은 점수가
 *        60점 이상이면 "합격입니다" 라는 메세지를 
 *        화면에 보여주시고, 60점 미만이면 "불합격입니다"
 *        라는 메세지를 화면에 보여주세요.
 */

public class IfElseExam_07 {

	public static void main(String[] args) {
		
		// 1. 키보드로 점수를 입력을 받자.
		Scanner sc = new Scanner(System.in);
		
		System.out.print("점수를 입력하세요. : ");
		
		int score = sc.nextInt();
		
		// 2. 조건식을 이용하여 점수를 판별을 하자.
		if(score >= 60) {
			System.out.println("합격입니다.");
		}else {
			System.out.println("불합격입니다.ㅠㅠㅠ");
		}
		
		sc.close();

	}

}
