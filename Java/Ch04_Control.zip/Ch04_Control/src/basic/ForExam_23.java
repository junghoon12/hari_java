package basic;

import java.util.Scanner;

/*
 * [문제] 키보드로 입력 받은 수까지의 홀수의 합과
 *       짝수의 합을 구하여 화면에 출력해 보세요.
 *       단, for 반복문을 이용할 것.
 */

public class ForExam_23 {

	public static void main(String[] args) {
		
		int oddSum = 0, evenSum = 0;
		
		Scanner sc = new Scanner(System.in);
		
		System.out.print("정수 하나를 입력하세요. : ");
		
		int max = sc.nextInt();
		
		for(int su = 1; su <= max; su++) {
			
			if(su % 2 == 0) {
				evenSum = evenSum + su;
			}else {
				oddSum = oddSum + su;
			}
		}
		
		System.out.println(max + " 까지의 홀수 합 >>> " + oddSum);
		
		System.out.println(max + " 까지의 짝수 합 >>> " + evenSum);
		
		
		sc.close();

	}

}
