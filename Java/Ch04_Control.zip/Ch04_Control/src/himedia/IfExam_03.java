package himedia;

import javax.swing.JOptionPane;

/*
 * [문제1] 키보드로 입력 받은 점수가 60점 이상이면
 *        "합격입니다." 라는 메세지를 화면에 출력해 보세요.
 */

public class IfExam_03 {

	public static void main(String[] args) {
		
		// 1. 키보드로 점수를 입력을 받자.
		int score = Integer.parseInt(JOptionPane.showInputDialog("점수를 입력하세요."));
		
		// 2. 키보드로 입력받은 점수가 60점 이상인지 조건 체크
		if(score >= 60) {
			// 3. 콘솔에 "합격입니다." 라는 문자열 출력
			System.out.println("합격입니다.");
			
		}
		
	}

}
