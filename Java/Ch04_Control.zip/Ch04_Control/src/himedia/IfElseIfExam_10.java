package himedia;

import javax.swing.JOptionPane;

/*
 * 3. 다중 if ~ else 문 - 분기문(조건문)
 *    - 여러 개의 조건 중에 맞는 조건에 해당하는
 *      문장을 실행하는 조건문.
 *      
 *    형식)
 *    		if(조건식1) {
 *    			조건식1이 참인 경우 실행 문장;
 *      	}else {
 *      		if(조건식2) {
 *      			조건식1이 거짓이고, 조건식2이 참인 경우 실행 문장;
 *      		}else {
 *      			if(조건식3) {
 *      				조건식1, 조건식2는 거짓이고, 조건식3은 참인 경우 실행 문장;
 *      			}else {
 *      				조건식1, 조건식2, 조건식3 모두가 거짓인 경우 실행 문장;
 *      			}
 *      		}
 *      	}
 *      
 *          ==>
 *          	if(조건식1) {
 *    				조건식1이 참인 경우 실행 문장;
 *      		}else if(조건식2) {
 *      			조건식1이 거짓이고, 조건식2이 참인 경우 실행 문장;
 *      		}else if(조건식3) {
 *      			조건식1, 조건식2는 거짓이고, 조건식3은 참인 경우 실행 문장;
 *      		}else {
 *      			조건식1, 조건식2, 조건식3 모두가 거짓인 경우 실행 문장;
 *      		}
 */

public class IfElseIfExam_10 {

	public static void main(String[] args) {
		
		int su = 
			Integer.parseInt(JOptionPane.showInputDialog("1 ~ 3 사이의 숫자 중에서 하나를 입력"));
		
		if(su == 1) {
			System.out.println("입력 받은 수는 1입니다.");
		}else if(su == 2) {
			System.out.println("입력 받은 수는 2입니다.");
		}else if(su == 3) {
			System.out.println("입력 받은 수는 3입니다.");
		}else {
			System.out.println("1 ~ 3 이외의 숫자가 입력되었습니다.");
		}
	}

}
