package himedia;

// ABCDEFGHIJKLMNOPQRSTUVWXYZ
// ZYXWVUTSRQPONMLKJIHGFEDCBA


public class WhileExam_20 {

	public static void main(String[] args) {
		
		// ABCDEFGHIJKLMNOPQRSTUVWXYZ 문자를 출력해 보자.
		char alpha1 = 'A';            // 반복문에서의 초기식
		
		while(alpha1 <= 'Z') {        // 반복문에서의 조건식
			
			System.out.print(alpha1);
			
			alpha1++;
		}
		
		System.out.println();
		
		
		// ZYXWVUTSRQPONMLKJIHGFEDCBA 문자를 출력해 보자.
		char alpha2 = 'Z';            // 반복문에서의 초기식
		
		while(alpha2 >= 'A') {        // 반복문에서의 조건식
			
			System.out.print(alpha2);
			
			alpha2--;                 // 반복문에서의 증감식
		}

	}

}
