package himedia;

import javax.swing.JOptionPane;

/*
 * [문제2] 키보드로 입력 받은 정수 값이 음수이면
 *        "입력 받은 정수는 음수입니다." 라는 
 *        메세지를 화면에 출력해 보세요.
 */

public class IfExam_04 {

	public static void main(String[] args) {
		
		// 1. 키보드로 정수 하나를 입력을 받자.
		int su = Integer.parseInt(JOptionPane.showInputDialog("정수 하나를 입력하세요."));
		
		// 2. 입력받은 정수가 음수인지 조건을 체크하자.
		if(su < 0) {
			// 3. 입력 받은 정수가 음수이면 "음수입니다." 라는 메서지 출력
			System.out.println("입력 받은 " + su + " 은(는) 음수입니다.");
		}

	}

}
