package himedia;

import javax.swing.JOptionPane;

/*
 * if ~ else 문 - 분기문(조건문)
 * - 조건식이 참이면 참인 경우의 실행문장을 실행을 하고,
 *   if ~ else 블럭을 빠져 나온다.
 * - 조건식이 거짓이면 거짓인 경우의 실행문장을 실행을 하고,
 *   if ~ else 블럭을 빠져 나온다.
 *   
 * 형식)
 * 		if(조건식) {
 * 			조건식이 참인 경우 실행 문장;
 * 		}else {
 * 			조건식이 거짓인 경우 실행 문장;
 * 		}
 */

public class IfElseExam_06 {

	public static void main(String[] args) {
		
		// 1. 키보드로 정수 하나를 입력을 받아 변수에 저장을 하자.
		int su = Integer.parseInt(JOptionPane.showInputDialog("정수 하나를 입력하세요."));
		
		// 2. 조건식을 통하여 참인지 거짓인지 판별하자.
		if(su >= 50) {
			// 참이면 50 이상의 숫자입니다.
			System.out.println("입력 받은 " + su + " 은(는) 50 이상의 숫자입니다.");
		}else  {
			// 거짓이면 50 미만의 숫자입니다.
			System.out.println("입력 받은 " + su + " 은(는) 50 미만의 숫자입니다.");
		}

	}

}
