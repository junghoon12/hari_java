package himedia;

import javax.swing.JOptionPane;

// 점수를 키보드로 입력을 받아보자

public class IfExam_02 {

	public static void main(String[] args) {
		
		System.out.println("프로그램 시작");
		
		// 1. 키보드로 점수를 입력받아서 변수에 저장 ==> 형변환까지 같이 진행.
		int jumsu = Integer.parseInt(JOptionPane.showInputDialog("점수를 입력하세요."));
		
		// 2. 조건식을 통해서 원하는 결과를 화면에 출력
		if(jumsu >= 90) {
			System.out.println("점수가 90점 이상입니다.");
			System.out.println("A학점입니다.");
		}
		
		System.out.println("프로그램 종료");
		
	}

}
