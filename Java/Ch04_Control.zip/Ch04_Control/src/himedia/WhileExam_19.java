package himedia;

import javax.swing.JOptionPane;

/*
 * 1 ~ 키보드로 입력받은 수 까지의 홀수의 합과 
 * 짝수의 합을 구하여 화면에 출력해 보세요.
 */

public class WhileExam_19 {

	public static void main(String[] args) {
		
		int max = Integer.parseInt(JOptionPane.showInputDialog("정수 하나를 입력하세요."));
		
		// 1. 사용될 변수 선언
		int su = 1;                    // 반복문에서의 초기식
		int oddSum = 0, evenSum = 0;   // 홀수의 합 누적변수, 짝수의 합 누적변수
		
		while(su <= max) {             // 반복문에서의 조건식
			
			if(su % 2 == 1) {
				// true ==> 홀수인 경우
				oddSum = oddSum + su;
			}else {
				// false ==> 짝수인 경우
				evenSum = evenSum + su;
			}
			
			su++;
			
		}  // while 반복문 end
		
		System.out.println("1 ~ " + max + " 까지의 홀수의 합 >>> " + oddSum);
		System.out.println("1 ~ " + max + " 까지의 짝수의 합 >>> " + evenSum);

	}

}
