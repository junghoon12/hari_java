package himedia;

import javax.swing.JOptionPane;

/*
 * [문제3] 키보드로부터 입력 받은 정수가 5의 배수이면
 *         " 이 정수는 5의 배수입니다." 라는 메세지를 아니면
 *         " 이 정수는 5의 배수가 아닙니다." 라는
 *         메세지를 화면에 출력해 보세요.
 *         단, 입력 받은 정수가 음수인 경우에는
 *         "음수가 입력 되었습니다." 라는 메세지를 화면에
 *         출력해 주세요. 
 */

public class IfElseExam_09 {

	public static void main(String[] args) {
		
		int num = Integer.parseInt(JOptionPane.showInputDialog("정수 하나를 입력하세요."));
		
		// 1. 양수인지 음수인지 먼저 판별
		if(num > 0) {
			// 조건이 참인 경우 ==> 양수인 경우
			if(num % 5 == 0) {
				// true ==> 5의 배수인 경우
				System.out.println("입력 받은 " + num + "은 5의 배수입니다.");
			}else {
				// false ==> 5의 배수가 아닌 경우
				System.out.println("입력 받은 " + num + "은 5의 배수가 아닙니다.");
			}
		}else {
			// 조건이 거짓인 경우 ==> 음수인 경우
			System.out.println("음수가 입력 되었습니다.");
		}

	}

}
