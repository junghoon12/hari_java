package himedia;

// while 반복문을 이용하여 1 ~ 10 까지의 합을 구해 보자


public class WhileExam_17 {

	public static void main(String[] args) {
		
		// 1. 변수 선언
		// 반복문에서 사용할 변수(초기식)와 1 ~ 10까지의 합을 저장할 변수.
		int su = 1, sum = 0;
		
		while(su <= 10) {
			
			sum = sum + su;   // sum += su; ==> 단축배정연산자
			
			su++;
			
		}  // while 반복문 end
		
		System.out.println("1 ~ 10 까지의 합 >>> " + sum);

	}

}
