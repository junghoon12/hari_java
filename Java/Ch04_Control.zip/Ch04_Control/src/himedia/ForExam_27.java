package himedia;

// 다중 for문을 이용하여 구구단을 만들어 보자.

public class ForExam_27 {

	public static void main(String[] args) {

		for(int dan = 2; dan <= 9; dan++) {   // 바깥쪽 for문 고정.
			
			System.out.println("*** " + dan + "단 ***");
			
			for(int su = 1; su < 10; su++) {  // 안쪽 for문 변동.
				
				System.out.println(dan + " * " + su + " = " + (dan * su));
				
			}
			
			System.out.println();
			
		}

	}

}
