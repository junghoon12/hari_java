package himedia;

import javax.swing.JOptionPane;

/*
 * [문제2] 키보드로부터 입력 받은 정수가
 *         홀수인지 아니면 짝수인지 판별하여
 *         화면에 출력해 보세요.
 */

public class IfElseExam_08 {

	public static void main(String[] args) {
		
		int su = Integer.parseInt(JOptionPane.showInputDialog("정수 하나를 입력하세요."));
		
		if(su % 2 == 1) {
			// true - 홀수인 경우
			System.out.println("입력 받은 " + su + "은(는) 홀수입니다.");
		}else {
			// false - 짝수인 경우
			System.out.println("입력 받은 " + su + "은(는) 짝수입니다.");
		}

	}

}
