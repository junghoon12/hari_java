package himedia;

import javax.swing.JOptionPane;

/*
 * [문제2] for문을 이용하여 키보드로 입력받은 수 까지의 
 *       홀수의 합과 짝수의 합을 구하여 화면에 
 *       출력해 보세요.
 */

public class ForExam_25 {

	public static void main(String[] args) {
		
		// 1. 변수 선언
		int oddSum = 0, evenSum = 0;
		
		int max = Integer.parseInt(JOptionPane.showInputDialog("정수를 입력하세요."));
		
		for(int i = 1; i <= max; i++) {
			
			if(i % 2 == 1) {
				
				oddSum = oddSum + i;
			}else {
				
				evenSum = evenSum + i;
			}
			
		}  // for 반복문 end
		
		System.out.println("1 ~ " + max + " 까지의 홀수의 합 >>> " + oddSum);
		
		System.out.println("1 ~ " + max + " 까지의 짝수의 합 >>> " + evenSum);

	}

}
