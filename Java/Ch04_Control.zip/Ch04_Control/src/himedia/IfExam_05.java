package himedia;

import javax.swing.JOptionPane;

/*
 * [문제3] 키보드로 입력 받은 정수가 5의 배수이면
 *        "이 정수는 5의 배수입니다." 라는 
 *        메세지를 화면에 출력해 보세요.
 */

public class IfExam_05 {

	public static void main(String[] args) {
		
		// 1. 키보드로 정수 하나를 입력을 받자.
		int num = Integer.parseInt(JOptionPane.showInputDialog("정수 하나를 입력하세요."));
		
		// 2. 조건식을 이용하여 입력 받은 수가 5의 배수인지 판별.
		if((num % 5) == 0) {
			// 3. 5의 배수이면 콘솔(화면)에 출력.
			System.out.println(num + " 은(는) 5의 배수입니다.");
		}

	}

}
