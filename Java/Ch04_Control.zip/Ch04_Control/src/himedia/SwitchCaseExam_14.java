package himedia;

import javax.swing.JOptionPane;

public class SwitchCaseExam_14 {

	public static void main(String[] args) {
		
		String alpha =
				JOptionPane.showInputDialog("알파벳 a ~ c 사이의 글자 중에서 한 글자 선택");
		
		switch(alpha) {
			case "a" :
				System.out.println("apple(사과)를 선택 하셨습니다.");
				break;
			case "b" :
				System.out.println("banana(바나나)를 선택 하셨네요");
				break;
			case "c" :
				System.out.println("cherry(체리)를 선택 하셨습니다.");
				break;
			default : 
				System.out.println("메뉴에 없는 과일을 선택 하셨습니다.");
		}
		
		
	}

}
