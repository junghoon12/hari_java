package himedia;

import javax.swing.JOptionPane;

public class IfElseIfExam_11 {

	public static void main(String[] args) {
		
		String alpha =
				JOptionPane.showInputDialog("알파벳 a ~ c 사이의 글자 중에서 한 글자 선택");
		
		if(alpha.equals("a")) {
			System.out.println("apple(사과)를 선택 하셨습니다.");
			JOptionPane.showMessageDialog(null, "apple(사과)를 선택 하셨습니다.");
		}else if(alpha.equals("b")) {
			System.out.println("banana(바나나)를 선택 하셨네요");
			JOptionPane.showMessageDialog(null, "banana(바나나)를 선택 하셨네요");
		}else if(alpha.equals("c")) {
			System.out.println("cherry(체리)를 선택 하셨습니다.");
			JOptionPane.showMessageDialog(null, "cherry(체리)를 선택 하셨습니다.");
		}else {
			System.out.println("메뉴에 없는 과일을 선택 하셨습니다.");
			JOptionPane.showMessageDialog(null, "메뉴에 없는 과일을 선택 하셨습니다.");
		}

	}

}
