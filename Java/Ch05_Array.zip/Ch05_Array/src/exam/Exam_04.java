package exam;

// 5 * 5 배열

public class Exam_04 {

	public static void main(String[] args) {
		
		// 1. 다차원 배열 선언 및 메모리 생성.
		int[][] arr = new int[5][5];   // 5행5열
		
		int count = 1;
		
		// 2. 5행5열 다차원 배열에 데이터를 저장해 보자.
		for(int i=0; i<arr.length; i++) {         // 고정 - 행
			
			for(int j=0; j<arr[i].length; j++) {  // 값 변동 - 열
				
				arr[i][j] = count;
				
				count++;
			}
		}
		
		// 3. 저장된 배열을 화면에 출력해 보자.
		for(int i=0; i<arr.length; i++) {
			
			for(int j=0; j<arr[i].length; j++) {
				
				System.out.printf("%2d\t", arr[i][j]);
			}
			
			System.out.println();
		}

	}

}
