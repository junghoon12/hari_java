package exam;

import java.util.Scanner;

// 성적 처리 - 베열을 이용.

public class Exam_03 {

	public static void main(String[] args) {
		
		// 1. 키보드 준비 작업
		Scanner sc = new Scanner(System.in);
		
		// 2. 키보드로 학생 수를 입력을 받자.
		System.out.print("학생 수를 입력하세요. : ");
		
		// int studentCount = sc.nextInt();
		
		// 3. 학생 이름 배열, 국어점수 배열, 영어점수 배열,
		//    수학점수 배열, 총점 배열, 평균 배열, 학점 배열,
		//    순위 배열까지 만들어야 함.
		String[] names = new String[sc.nextInt()];   // 이름 배열
		int[] kor = new int[names.length];           // 국어점수 배열
		int[] eng = new int[kor.length];             // 영어점수 배열
		int[] mat = new int[eng.length];             // 수학점수 배열
		int[] sum = new int[mat.length];             // 총점 배열
		double[] avg = new double[sum.length];       // 평균 배열
		String[] grade = new String[avg.length];     // 학점 배열
		int[] rank = new int[grade.length];          // 순위 배열
		
		// 4. 학생 수 만큼 이름, 국어점수, 영어점수, 수학점수를
		//    키보드로 입력을 받아서 각각의 배열에 저장을 해 주자.
		for(int i=0; i<names.length; i++) {
			
			/// 이름과 각 과목의 점수를 배열에 저장을 하자.///
			System.out.print("학생의 이름을 입력하세요. : ");
			names[i] = sc.next();
			
			System.out.print("국어 점수를 입력하세요. : ");
			kor[i] = sc.nextInt();
			
			System.out.print("영어 점수를 입력하세요. : ");
			eng[i] = sc.nextInt();
			
			System.out.print("수학 점수를 입력하세요. : ");
			mat[i] = sc.nextInt();
			
			/// 총점과 평균 그리고 학점을 구해 보자.
			// 총점을 구하자.
			sum[i] = kor[i] + eng[i] + mat[i];
			
			// 평균을 구하자.
			avg[i] = sum[i] / 3.0;
			
			// 학점을 구하자.
			if(avg[i] >= 90) {
				grade[i] = "A학점";
			}else if(avg[i] >= 80) {
				grade[i] = "B학점";
			}else if(avg[i] >= 70) {
				grade[i] = "C학점";
			}else if(avg[i] >= 60) {
				grade[i] = "D학점";
			}else {
				grade[i] = "F학점";
			}
			
			// 순위를 구해 보자.
			rank[i] = 1;
			
		}  // for문 end
		
		// 실제로 석차를 구해 보자.
		for(int i=0; i<rank.length; i++) {
			
			for(int j=0; j<rank.length; j++) {
				
				if(sum[j] > sum[i]) {
					
					rank[i]++;
				}
			}
		}
		
		// 마지막으로 성적을 화면에 출력해 보자.
		for(int i=0; i<kor.length; i++) {
			
			System.out.println("::::::::::::::::::::::::::::::::::");
			
			System.out.print("이 름 : " + names[i] + "\t");
			System.out.print("총 점 : " + sum[i] + "점\t");
			System.out.printf("평 균 : %.2f점\t", avg[i]);
			System.out.print("학 점 : " + grade[i] + "\t");
			System.out.print("순 위 : " + rank[i] + "등");
			System.out.println();
		}
		
		sc.close();
		
	}
}
