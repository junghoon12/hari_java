package exam;

public class Exam_03_05 {

	public static void main(String[] args) {
		
		// 1. 다차원 배열 선언 및 메모리 할당.
		int[][] score = new int[5][5];    // 5행5열
		
		int count = 1;
		
		// 2. 5행5열 다차원 배열에 데이터를 저장해 보자.
		for(int i = 0; i < score.length; i++) {         // 고정 - 열
			
			for(int j = 0; j <score[i].length; j++) {   // 변동 - 행
				
				score[j][i] = count++;
			}
		}
		
		// 3. 저장된 다차원 배열을 화면에 출력해 보자.
		for(int i = 0; i < score.length; i++) {         // 고정 - 행
			
			for(int j = 0; j <score[i].length; j++) {   // 변동 - 열
				
				System.out.printf("%2d\t", score[i][j]);
			}
			
			System.out.println();
		}

	}

}
