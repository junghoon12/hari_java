package basic;

/*
 * 다차원 배열
 * - 1차원 배열이 여러 개 묶여 있는 형태의 배열을 말함.
 * - 행과 열의 개념이 적용이 됨.
 */

public class ArrayExam_09 {

	public static void main(String[] args) {
		
		// 1. 다차원 배열 선언 및 배열 메모리 할당.
		int[][] arr = new int[3][4];  // 3행4열
		
		int count = 10;
		
		for(int i=0; i<arr.length; i++) {   // 행
			
			for(int j=0; j<arr[i].length; j++) {
				
				arr[i][j] = count;
				
				count += 10;   // count = count + 10;
				
				System.out.print("arr["+i+"]["+j+"] >>> " + arr[i][j] + "\t");
				
			}
			
			System.out.println();
		}

	}

}
