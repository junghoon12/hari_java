package basic;

// 2. 배열의 초기값을 이용하여 배열을 생성.

public class ArrayExam_04 {

	public static void main(String[] args) {

		// 배열을 생성함과 동시에 초기값을 설정하여 배열 생성.
		int[] arr1 = {10, 20, 30, 40, 50};
		
		for(int k : arr1) {
			
			System.out.print(k + "\t");
		}
		

	}

}
