package himedia;

import javax.swing.JOptionPane;

/*
 * 5개의 정수를 저장할 배열을 만들고, 키보드로 배열에
 * 5개의 데이터를 저장 후, 해당 배열을 화면에 출력해 보자.
 */

public class ArrayExam_02 {

	public static void main(String[] args) {
		
		// 1단계 + 2단계 : 배열 선언 및 배열 메모리 생성.
		int[] score = new int[5];
		
		// score[0] = Integer.parseInt(JOptionPane.showInputDialog("첫번째 정수 입력"));
		// score[1] = Integer.parseInt(JOptionPane.showInputDialog("두번째 정수 입력"));
		// score[2] = Integer.parseInt(JOptionPane.showInputDialog("세번째 정수 입력"));
		// score[3] = Integer.parseInt(JOptionPane.showInputDialog("네번째 정수 입력"));
		// score[4] = Integer.parseInt(JOptionPane.showInputDialog("다섯번째 정수 입력"));
		
		// 반복문을 이용하여 5개의 정수를 베열에 저장을 해 보자.
		for(int i = 0; i < 5; i++) {
			
			score[i] = Integer.parseInt(JOptionPane.showInputDialog((i+1)+"번째 정수 입력"));
		}
		
		
		// 배열에 저장된 데이터를 화면에 출력해 보자
		for(int i = 0; i < 5; i++) {
			
			System.out.println("score["+i+"] >>> " + score[i]);
		}
		

	}

}
