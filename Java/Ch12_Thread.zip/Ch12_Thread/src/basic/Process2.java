package basic;

public class Process2 {

	void go() {
		
		int j = 1;
		
		while(true) {
			
			System.out.println("j >>> " + j);
			
			j++;
		}
	}
}
