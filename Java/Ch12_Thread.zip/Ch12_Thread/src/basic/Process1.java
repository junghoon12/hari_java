package basic;

public class Process1 {

	void go() {
		
		int i = 1;
		
		while(true) {
			
			System.out.println("i >>> " + i);
			
			i++;
		}
	}
}
