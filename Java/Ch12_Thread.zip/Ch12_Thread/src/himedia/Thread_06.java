package himedia;

public class Thread_06 {

	public static void main(String[] args) {
		
		new Thread() {
			
			@Override
			public void run() {
				
				for(int i = 1; i <= 100; i++) {
					
					System.out.println("number >>> " + i);
				}
			}
		}.start();
		
		
		new Thread(new Runnable() {
			
			@Override
			public void run() {
				
				char j = 'A';
				
				while(j <= 'Z') {
					
					System.out.println("alpha >>> " + j++);
				}
				
			}
		}).start();

	}

}
