package himedia;

/*
 * 2. Runnable 인터페이스를 구현(implements)하여 사용하는 방법.
 *    1) Runnable 인터페이스를 구현(implements).
 *    2) run() 추상 메서드를 재정의.
 *    3) 인터페이스를 구현한 자식 클래스(스레드 클래스) 객체 생성.
 *    4) java.lang.Thread 클래스 객체 생성.
 *       ==> 생성자의 매개변수 위치에 자식클래스의 참조변수를 기재.
 *    5) java.lang.Thread 클래스의 참조변수.start() 메서드 호출.
 */


class Runnable1 implements Runnable {  // 2-1)

	@Override
	public void run() {                // 2-2)
		
		int i = 1;
		
		while(true) {
			
			System.out.println("i >>> " + i++);
			
		}
		
	}
	
}

class Runnable2 implements Runnable {

	@Override
	public void run() {
		
		int j = 1;
		
		while(true) {
			
			System.out.println("j >>> " + j++);
			
		}
		
	}

	
}


public class Thread_03 {

	public static void main(String[] args) {
		
		// 2-3) 인터페이스를 구현한 자식 클래스(스레드 클래스) 객체 생성.
		Runnable1 r1 = new Runnable1();
		
		Runnable2 r2 = new Runnable2();
		
		// 2-4) java.lang.Thread 클래스 객체 생성.
		//      ==> 생성자의 매개변수 위치에 자식클래스의 참조변수를 기재.
		Thread thread1 = new Thread(r1);
		
		Thread thread2 = new Thread(r2);
		
		
		thread1.start(); thread2.start();
		

	}

}
