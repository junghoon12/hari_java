package basic;

// 1. 구현 메서드의 약식 표현.
interface SuperA {
	
	// 반환타입(X), 매개변수(X)
	void method1();
}

interface SuperB {
	
	// 반환타입(X), 매개변수(O)
	void method2(int su);
}

interface SuperC {
	
	// 반환타입(O), 매개변수(X)
	int method3();
}

interface SuperD {
	
	// 반환타입(O), 매개변수(O)
	double method4(int su1, double su2);
}


public class Lambda_02 {

	public static void main(String[] args) {

		// 람다식으로 표현하는 방법
		// 반환타입(X), 매개변수(X)
		SuperA a2 = () -> {
			
			System.out.println("람다식 ==> 반환타입(X), 매개변수(X) 메서드 재정의");
		};
		
		a2.method1();
		
		System.out.println();
		
		// 람다식에서 메서드 호출 시 실행 문장이 한 줄인 경우 {  }(중괄호) 생략
		SuperA a3 = () -> System.out.println("람다식 ==> 반환타입(X), 매개변수(X) 메서드 재정의");
		
		a3.method1();
		
		System.out.println();
		
		// 매개변수가 있는 경우에는 매개변수의 타입 생략 가능.
		SuperB b3 = (su) ->  {
			
			System.out.println("람다식 ==> 반환타입(X), 매개변수(O) 메서드 / su >>> " + su);
		};
		
		b3.method2(47);
		
		System.out.println();
		
		
		// 매개변수가 하나인 경우 () (괄호) 생략 가능.
		SuperB b4 = su -> System.out.println
					("람다식 ==> 반환타입(X), 매개변수(O) 메서드 / su >>> " + su);
		
		b4.method2(47);
		
		System.out.println();
		
		
		// 반환타입이 있고, 매개변수는 없는 경우
		SuperC b5 = () -> {
			
			return 77;
		};
		
		System.out.println
		  ("람다식 ==> 반환타입(O), 매개변수(X) 메서드 >>> " + b5.method3());
		
		System.out.println();
		
		
		// 반환타입이 있고, 매개변수는 없는 경우
		// 메서드 호출 시 return 문장이 한 문장이면, return 키워드와
		// {  } 중괄호 생략 가능.
		SuperC b6 = () -> 77;
		
		System.out.println
		  ("람다식 ==> 반환타입(O), 매개변수(X) 메서드 >>> " + b6.method3());
		
		System.out.println();
		
		// 반환타입이 있고, 매개변수는 있는 경우
		SuperD d2 = (int su1, double su2) -> {
			
			return su1 + su2;
		};
		
		System.out.println
		  ("람다식 ==> 반환타입(O), 매개변수(O) 메서드 >>> " + d2.method4(11, 46));
		
		System.out.println();
		
		// 반환타입이 있고, 매개변수는 있는 경우
		// 1. 매개변수 타입 생략 가능
		// 2. 메서드 호출 시 return 문장이 한 문장이면, return 키워드와
		//    {  } 중괄호 생략 가능.
		SuperD d4 = (su1, su2) -> su1 + su2;
		
		System.out.println
		  ("람다식 ==> 반환타입(O), 매개변수(O) 메서드 >>> " + d4.method4(11, 46));
		
	}

}
