package inheritance;

public class Point3D extends Point {

	int z;
	
	public Point3D() {
	
		super();     // 부모 클래스의 기본 생성자 호출
	}
	
	public Point3D(int x, int y) {
		
		super(x, y);  // 부모 클래스의 인자 생성자 호출
		// this.x = x;
		// this.y = y;
	}
	
	public Point3D(int x, int y, int z) {
		
		this(x, y);
		this.z = z;
		
		// this.x = x;
		// this.y = y;
		
	}
	
	
}
