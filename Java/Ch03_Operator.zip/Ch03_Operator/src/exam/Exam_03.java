package exam;

import java.util.Scanner;

public class Exam_03 {

	public static void main(String[] args) {
		
		// 두번째 방법
		Scanner sc = new Scanner(System.in);
		
		// 2-1. 키보드로 입금액을 입력을 받자.
		System.out.print("입금액을 입력해 주세요. : ");
		int money = sc.nextInt();
		
		// 2-2. 키보드로 상품단가를 입력을 받자.
		System.out.print("상품 단가를 입력해 주세요. : ");
		int price = sc.nextInt();

		// 2-3. 키보드로 상품의 수량을 입력을 받자.
		System.out.print("상품 수량을 입력해 주세요. : ");
		int amount = sc.nextInt();
		
		// 3. 상품의 공급가액을 계산해 보자.
		// 공급가액 : 상품단가 * 상품수량
		int sum = price * amount;
		
		// 4. 상품의 부가세액을 계산해 보자.
		// 부가세액 계산 = 공급가액 * 0.1(10%)
		int vat = (int)(sum * 0.1);
		
		// 5. 상품의 총금액을 계산해 보자.
		// 총금액 = 공급가액 + 부가세액
		int total = sum + vat;
		
		// 6. 잔액(거스름돈)을 계산해 보자.
		// 잔액 = 입금액 - 총금액(공급가액 + 부가세액)
		int change = money - total;
		
		// 7. 계산된 결과를 화면에 출력해 보자.
		System.out.printf("지불한 금액 : %,d원\n", money);
		System.out.printf("상품  단가 : %,d원\n", price);
		System.out.printf("상품  수량 : %,d원\n", amount);
		System.out.printf("공급가액   : %,d원\n", sum);
		System.out.printf("부가세액 : %,d원\n", vat);
		System.out.printf("상품총액 : %,d원\n", total);
		System.out.printf("거스름돈 : %,d원\n", change);
		

		sc.close();
	}

}
