package exam;

import java.util.Scanner;

public class Exam_02 {

	public static void main(String[] args) {
		
		// 첫번째 방법
		// int su = Integer.parseInt(args[0]);
		
		// System.out.println("입력 받은 정수 >>> " + su);
		
		// System.out.println(su + "의 제곱 >>> " + (su * su));
		
		// System.out.println(su + "의 세제곱 >>> " + (su * su * su));

		// 두번째 방법
		Scanner sc= new Scanner(System.in);
		
		System.out.print("양의 정수를 입력하세요..");
		
		int su = sc.nextInt();
		
		System.out.println("입력 받은 정수 >>> " + su);
		
		System.out.println(su + "의 제곱 >>> " + (su * su));
		
		System.out.println(su + "의 세제곱 >>> " + (su * su * su));
		
		sc.close();
		
	}
}
