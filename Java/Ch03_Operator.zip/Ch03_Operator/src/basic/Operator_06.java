package basic;

/*
 * 3. 논리연산자
 *    - 논리곱(&&) : 주어진 조건이 모두 참(true)인 
 *                  경우에만 결과가 참(true)이 됨.
 *                  그 나머지는 모두 거짓(false)이 됨.
 *    - 논리합(||) : 주어진 조건 중에 어느 하나라도 참(true)이면
 *                  결과는 참(true)이 됨.
 *                  그 나머지는 모두 거직(false)이 됨.
 *    - 부정(!) : true -> false, false -> true가 됨.
 *    
 *    ※ 논리연산자는 관계연산자의 결과를 가지고 논리연산이 수행이 됨.
 */
public class Operator_06 {

	public static void main(String[] args) {
		
		int su1 = 10, su2 = 6;
		
		// 논리곱인 경우 : true && true ==> true
		boolean test = (su1 >= su2) && (su2 >= 5);
		System.out.println("test 결과 >>> " + test);
		
		// 논리곱인 경우 : false && true ==> false
		test = (su1 <= su2) && (su2 >= 5);
		System.out.println("test 결과 >>> " + test);
		
		// 논리합인 경우 : true || false ==> true
		test = (su1 >= su2) || (su2 < 5);
		System.out.println("test 결과 >>> " + test);
		

	}

}
