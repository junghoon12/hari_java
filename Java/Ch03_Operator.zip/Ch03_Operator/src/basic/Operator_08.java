package basic;

/*
 * 5. 배정연산자 / 단축배정연산자
 *    - 배정연산자(=)
 *      형식) 변수 = 값 or 수식 or 변수;
 *                 * 좌변에는 항상 변수명이 와야 한다.
 *                 * 우변에는 값(리터럴 - 숫자), 수식, 변수명이 와야 함.
 *                 
 *    - 단축배정연산자
 *      * 배정연산자를 간편하게 사용하는 연산자.
 */

public class Operator_08 {

	public static void main(String[] args) {
		
		// 배정연산자.
		// 형식) 변수명 = 값(데이터)
		int su1 = 10, su2 = 20, result = 0;
		
		// 형식) 변수명 = 변수명
		su1 = su2;
		
		// 형식) 변수명 = 수식
		su1 = su2 + 27;
		
		System.out.println("su1 >>> " + su1);  // 47
		
		System.out.println("su2 >>> " + su2);  // 20
		
		
		// 단축배정연산자
		// result = result + 10;
		result += 10;
		
		int su = 15;
		
		su += 5;  // su = su + 5;
		System.out.println("su >>> " + su);  // 20
		System.out.println();
		
		su -= 5;  // su = su - 5;
		System.out.println("su >>> " + su);  // 15
		System.out.println();
		
		su *= 5;  // su = su * 5;
		System.out.println("su >>> " + su);  // 75
		System.out.println();
		
		su /= 5;  // su = su / 5;
		System.out.println("su >>> " + su);  // 15
		System.out.println();
		
		su %= 5;  // su = su % 5;
		System.out.println("su >>> " + su);  // 0
		
		

	}

}
