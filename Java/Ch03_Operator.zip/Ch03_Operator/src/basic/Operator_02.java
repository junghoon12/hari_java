package basic;

import javax.swing.JOptionPane;

public class Operator_02 {

	public static void main(String[] args) {
		
		// 키보드로 두 수를 입력을 받아 보자. - 1번째
		int su1 = 
			Integer.parseInt(
					JOptionPane.showInputDialog(null, "첫번째 숫자 입력하세요."));

		int su2 = 
				Integer.parseInt(
					JOptionPane.showInputDialog(null, "두번째 숫자 입력하세요."));
	
		// 덧셈연산
		System.out.println("덧셈결과 >>> " + (su1 + su2));
		System.out.println();
		
		// 뺄셈연산
		System.out.println("뺄셈결과 >>> " + (su1 - su2));
		System.out.println();
		
		// 곱셈연산
		System.out.println("곱셈결과 >>> " + (su1 * su2));
		System.out.println();
		
		// 나눗셈연산
		System.out.println("나눗셈결과(몫) >>> " + (su1 / su2));
		System.out.println();
		
		// 나머지연산
		System.out.println("나머지결과 >>> " + (su1 % su2));
		System.out.println();
	
	
	}

}
