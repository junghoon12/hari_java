package himedia;

import javax.swing.JOptionPane;

/*
 * 2. 관계연산자(비교연산자)
 * 
 * - >= (크거나 같은지)
 * - > (큰지)
 * - <= (작거나 같은지)
 * - < (작은지)
 * - == (같은지)
 * - != (같지 않은지)
 * 
 * - 결과값은 반드시 boolean 형으로 나옴 ==> 즉, true 또는 false로 나옴.
 * - 관계연산자는 제어문(조건문)에서 가장 많이 사용되는 연산자.
 */

public class Operator_05 {

	public static void main(String[] args) {
		
		// 키보드로 데이터를 입력받는 방법 - 첫번째
		int num1 = Integer.parseInt(JOptionPane.showInputDialog("첫번째 정수 입력"));
		int num2 = Integer.parseInt(JOptionPane.showInputDialog("두번째 정수 입력"));
		
		System.out.println("(num1 >= num2) 결과 >>> " + (num1 >= num2));
		System.out.println();
		
		System.out.println("(num1 > num2) 결과 >>> " + (num1 > num2));
		System.out.println();
		
		System.out.println("(num1 <= num2) 결과 >>> " + (num1 <= num2));
		System.out.println();
		
		System.out.println("(num1 < num2) 결과 >>> " + (num1 < num2));
		System.out.println();
		
		System.out.println("(num1 == num2) 결과 >>> " + (num1 == num2));
		System.out.println();
		
		System.out.println("(num1 != num2) 결과 >>> " + (num1 != num2));
		System.out.println();
		

	}

}
