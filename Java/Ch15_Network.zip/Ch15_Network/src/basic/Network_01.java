package basic;

import java.net.InetAddress;
import java.net.UnknownHostException;

public class Network_01 {

	public static void main(String[] args) throws UnknownHostException {
		
		InetAddress addr = InetAddress.getLocalHost();
		
		System.out.println("내 컴퓨터 이름 >>> " + addr.getHostName());
		
		System.out.println("내 컴퓨터 IP >>> " + addr.getHostAddress());
		
		addr = InetAddress.getByName("www.oracle.com");
		
		System.out.println("oracle ip 주소 >>> " + addr);
		
		addr = InetAddress.getByName("www.google.com");
		
		System.out.println("google ip 주소 >>> " + addr);
		
		// 여러 개의 IP 주소 받기
		InetAddress[] ipAll = InetAddress.getAllByName("www.naver.com");
		
		for(int i=0; i<ipAll.length; i++) {
			System.out.println
				("www.naver.com IP 주소 >>> " + ipAll[i].getHostAddress());
		}
		
		

	}

}
