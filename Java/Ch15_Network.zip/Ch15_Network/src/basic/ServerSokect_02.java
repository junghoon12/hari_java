package basic;

import java.io.IOException;
import java.net.InetSocketAddress;
import java.net.ServerSocket;
import java.net.Socket;

/*
 * 소켓(socket)?
 * - 소켓은 응용 프로그램에서 TCP/IP를 이용하는 창구 역할을 함.
 * - 두 프로그램이 네트워크를 통하여 서로 통신할 수 있도록
 *   양쪽에서 생성되는 링크.
 * - 두 소켓이 연결이 되면 서로 다른 프로그램이 서로 다른 데이터를
 *   전달 할 수 있음. 
 */

/*
 * [소켓 통신의 일련의 규칙]
 * 1. Server에서 port를 열고 접속을 기다림.
 * 2. Client에서 Server의 IP와 port를 접속하여 통신이 연결됨.
 * 3. 이 때 서버에서는 클라이언트와 통신을 할 socket을 보내줌.
 * 4. 클라이언트는 서버에서 보내준 socket을 통해서 서버와 통신을 하게 됨.
 *    ==> 이 때 서로의 통신은 send와 receive 형태로 주고 받게 됨.
 * 5. 통신이 끝나면 close() 메서드로 접속을 끊게 됨.
 */

public class ServerSokect_02 {

	public static void main(String[] args) {
		
		ServerSocket serverSocket = null;
		
		try {
			serverSocket = new ServerSocket();
			serverSocket.bind(new InetSocketAddress("localhost", 5002));
			
			while(true) {
				
				System.out.println("[연결을 기다림].......");
				
				// accept() : 클라이언트의 연결을 수락하는 메서드.
				// 클라이언트의 연결 요청이 들어오면 수락을 하고
				// 데이터를 주고 받을 수 있는 통신용 소켓을 하나 만들게 됨.
				Socket socket = serverSocket.accept();
				
				InetSocketAddress isa =
						(InetSocketAddress)socket.getRemoteSocketAddress();
				
				// 클라이언트의 컴퓨터 이름을 가져올 수 있음.
				System.out.println("[연결을 수락함]..." + isa.getHostName());
			}
			
			
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}

}
