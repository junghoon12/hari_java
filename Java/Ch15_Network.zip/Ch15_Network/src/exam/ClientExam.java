package exam;

import java.io.*;
import java.net.*;

import java.util.Scanner;

public class ClientExam {

	public static void main(String[] args) {
		
		BufferedReader in = null;
		BufferedWriter out = null;
		Socket socket = null;
		
		Scanner sc = new Scanner(System.in);
		
		try {
			
			socket = new Socket("localhost", 7777);
			
			in = new BufferedReader(
					new InputStreamReader(socket.getInputStream()));
			
			out = new BufferedWriter(
					new OutputStreamWriter(socket.getOutputStream()));
			
			while(true) {
				
				System.out.print("문자 보내기 >>> ");
				
				// 서버로 한 줄 문자 보내기
				String outputMsg = sc.nextLine();
				
				if(outputMsg.equalsIgnoreCase("bye")) {
					
					out.write(outputMsg + "\n");
					
					out.flush();
					
					// 클라이언트가 "bye" 문자열을 입력한 경우 서버로 문자 전송 후 실행 종료
					break;  
				}
				
				out.write(outputMsg + "\n");  // 문자열을 서버로 보낸다.
				
				out.flush();
				
				////// 서버로부터 받은 문자열을 확인을 하자 ////////
				
				// 서버로부터 받은 문자 수신 작업.
				String inputMsg =  in.readLine();
				
				System.out.println("서버에서 받은 문자 >>> " + inputMsg);
				
			}
			
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} finally {
			
			try {
				sc.close();
				socket.close();
				// out.close();
				// in.close();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
		}

	}

}
