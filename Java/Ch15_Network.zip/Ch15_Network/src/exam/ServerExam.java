package exam;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.net.InetSocketAddress;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.Scanner;

public class ServerExam {

	public static void main(String[] args) {
		
		BufferedReader in = null;
		BufferedWriter out = null;
		ServerSocket listener = null;
		Socket socket = null;
		
		Scanner sc = new Scanner(System.in);
		
		try {
			
			listener = new ServerSocket();
			
			listener.bind(new InetSocketAddress("localhost", 7777));
			
			System.out.println("클라이언트의 연결을 기다리는 중.....");
			
			socket = listener.accept();
			
			in = new BufferedReader(
					new InputStreamReader(socket.getInputStream()));
			
			out = new BufferedWriter(
					new OutputStreamWriter(socket.getOutputStream()));
			
			while(true) {
				
				// 클라이언트로부터 받은 한 줄 문자 읽기.
				String inputMsg = in.readLine();
				
				if(inputMsg.equalsIgnoreCase("bye")) {
					
					System.out.println("클라이언트에서 bye로 연결을 종료함.....");
					
					break;
				}
				
				System.out.println("클라이언트에서 보낸 문자 >>> " + inputMsg);
				
				System.out.println();
				
				System.out.print("문자 보내기 >>> ");
				
				String outputMsg = sc.nextLine();
				
				out.write(outputMsg +  "\n");
				
				// out 스트림 버퍼에 있는 모든 문자열을 전송
				out.flush();
				
			}
			
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} finally {
			
			try {
				sc.close();
				socket.close();
				listener.close();
				// out.close();
				// in.close();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
		}

	}

}
