package basic;

/*
 * [문제] 아래와 같은 내용으로 콘솔창에 출력하는
 *       프로그램을 완성해 보세요.
 *       단, 앞에서 배운 내용을 활용하여 사용해 볼 것.
 *       
 *       이 름 : 임 정 훈
 *       연락처 : 010-4725-3440
 *       이메일 : jhehun@gmail.com
 *       주 소 : 경기도 파주시
 */

public class Basic_04 {

	public static void main(String[] args) {
		
		System.out.print("이 름 : 임 정 훈");
		
		System.out.println("\n연락처 : 010-4725-3440");
		
		System.out.print("이메일 : jhehun@gmail.com\n");
		
		System.out.println("주 소 : 경기도 파주시");

	}

}
