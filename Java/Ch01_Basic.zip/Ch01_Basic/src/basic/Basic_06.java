package basic;

// 자바에서의 출력 양식

public class Basic_06 {

	public static void main(String[] args) {

		// System.out.println();
		// System.out.print();
		// System.out.printf();
		
		// %d : 정수 값을 출력 시
		System.out.printf("%d + %d = %d\n", 10, 20, (10+20));
		
		// %o : 8진수 값을 출력 시
		System.out.printf("10진수 10을 8진수로 하면 >>> %o\n", 10);
		
		// %x : 16진수 값을 출력 시
		System.out.printf("10진수 15을 16진수로 하면 >>> %x\n", 15);
		
		System.out.println(12.6666666666666666);
		
		System.out.printf("%.2f\n", 12.6666666666666666);
		
		System.out.println(2000000000);
		
		System.out.printf("%,d\n", 2000000000);

	}

}
