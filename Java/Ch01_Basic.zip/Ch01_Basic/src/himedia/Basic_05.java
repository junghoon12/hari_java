package himedia;

public class Basic_05 {

	public static void main(String[] args) {
		
		// 숫자 + 숫자 ==> 숫자(+의 의미는 덧셈의 의미)
		System.out.println(10 + 37);
		
		// 문자 + 숫자 ==> 문자(+의 의미는 연결의 의미)
		System.out.println("10" + 37);
		
		// 숫자 + 문자 ==> 문자(+의 의미는 연결의 의미)
		System.out.println(10 + "37");
		
		// 문자 + 문자 ==> 문자(+의 의미는 연결의 의미)
		System.out.println("10" + "37");
		
		System.out.println(4 + 7 + "10");
		
		

	}

}
