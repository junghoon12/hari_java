package himedia;

/*
 * "두 번째 자바 프로그램입니다. 콘솔 화면에 출력을 합니다"
 * 라는 문자열을 화면(콘솔)에 출력하는 방법
 */

public class Basic_02 {

	public static void main(String[] args) {
		
		// 첫번째 방법
		System.out.println("두 번째 자바 프로그램입니다. 콘솔 화면에 출력을 합니다");
		
		// 두번째 방법
		System.out.print("두 번째 자바 프로그램입니다.");
		System.out.println("콘솔 화면에 출력을 합니다");
		
		// 세번째 방법
		System.out.println("두 번째 자바 프로그램입니다." + "콘솔 화면에 출력을 합니다");
		System.out.println("두 번째 자바 프로그램입니다." + "콘솔 화면에 출력을 합니다");
		System.out.println("두 번째 자바 프로그램입니다." + "콘솔 화면에 출력을 합니다");
		
		
		/*
		 * 이클립스 프로그램 사용 시 단축키
		 * 
		 * - syso + ctrl + space bar ==> 출력문 코드 작성 단축 키.
		 * - ctrl + s ==> 소스 파일을 저장하는 단축 키.
		 * - ctrl + F11 ==> 프로그램을 실행시키는 단축 키.
		 * - ctrl + alt + 아래화살표 ==> 현재코드를 밑(아래)에 복사해 주는 단축 키.
		 */
		
	}

}
