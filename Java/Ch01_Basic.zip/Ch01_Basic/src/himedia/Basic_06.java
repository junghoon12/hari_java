package himedia;

public class Basic_06 {

	public static void main(String[] args) {
		
		// System.out.println();
		// System.out.print();
		// System.out.printf();    // format의 약어
		
		System.out.println(3.1415927547);
		
		// %f : 실수값 출력 시 사용되는 format
		System.out.printf("%.3f\n",3.1412927547);
		
		// %d : 정수값 출력 시 사용되는 format
		System.out.printf("%d\n", 1000000000);
		
		System.out.printf("%,d\n", 1000000000);
		
		System.out.printf("%d + %d = %d\n", 10, 20, (10+20));
		
		System.out.println("10 + 20 = " + (10+20));
		
		System.out.printf("십진수 10을 8진수로 바꾸면 >>> %o\n", 10);
		
		System.out.printf("십진수 15를 16진수로 바꾸면 >>> %x\n", 15);

	}

}
