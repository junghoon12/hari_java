package jdbc;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.Scanner;

public class Update {

	public static void main(String[] args) {
		
		// 오라클 데이터베이스와 연결하는 객체.
		Connection con = null;
		
		// SQL문을 데이터베이스에 전송하는 객체.
		PreparedStatement pstmt = null;
		
		// SQL문을 실행한 후에 결과값을 가지고 있는 객체.
		// ResultSet rs = null;
		
		String url = "jdbc:oracle:thin:@localhost:1521:xe";
		
		String user = "basic";
		
		String password = "1234";
		
		Scanner sc = new Scanner(System.in);
		
		System.out.print("수정 부서 번호 입력 : ");
		String deptno = sc.nextLine();
		
		System.out.print("수정할 부서명 입력 : ");
		String dname = sc.nextLine();
		
		System.out.print("수정할 부서 위치 입력 : ");
		String loc = sc.nextLine();
		
		
		try {
			// 1단계 : 오라클 드라이버 동적으로 메모리 로딩.
			Class.forName("oracle.jdbc.driver.OracleDriver");
			
			// 2단계 : 오라클 데이터베이스와 연결 시도.
			con = DriverManager.getConnection(url, user, password);
			
			// 3단계 : 데이터베이스에 전송할 SQL문 작성.
			String sql = "update dept set dname = ?, loc = ? where deptno = ?";
			
			pstmt = con.prepareStatement(sql);
			
			pstmt.setString(1, dname);
			pstmt.setString(2, loc);
			pstmt.setInt(3, Integer.parseInt(deptno));
			
			// 4단계 : 데이터베이스에 SQL문 전송 및 실행.
			int res = pstmt.executeUpdate();
			
			if(res > 0) {
				System.out.println("부서 정보 수정 완료!!!");
			}else {
				System.out.println("부서 정보 수정 실패~~~");
			}
			
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} finally {
			try {
				sc.close();
				pstmt.close();
				con.close();	
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
		}
		

	}

}
