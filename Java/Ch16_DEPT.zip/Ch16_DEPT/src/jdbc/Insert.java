package jdbc;

import java.sql.*;
import java.util.Scanner;


public class Insert {

	public static void main(String[] args) {
		// 오라클 데이터베이스와 연결하는 객체.
		Connection con = null;
		
		// SQL문을 데이터베이스에 전송하는 객체.
		PreparedStatement pstmt = null;
		
		// SQL문을 실행한 후에 결과값을 가지고 있는 객체.
		// ResultSet rs = null;
		
		String url = "jdbc:oracle:thin:@localhost:1521:xe";
		
		String user = "basic";
		
		String password = "1234";
		
		Scanner sc = new Scanner(System.in);
		
		System.out.print("신규 부서 번호 입력 : ");
		String deptno = sc.nextLine();
		
		System.out.print("신규 부서명 입력 : ");
		String dname = sc.nextLine();
		
		System.out.print("신규 부서 위치 입력 : ");
		String loc = sc.nextLine();
		
		try {
			// 1단계 : 오라클 드라이버를 동적으로 메모리에 로딩.
			// 동적 로딩 : 프로그램을 실행할 때 드라이버를 로딩.
			Class.forName("oracle.jdbc.driver.OracleDriver");
			
			System.out.println("오라클 드라이버 로딩 성공!!!");
			
			// 2단계 : 자바와 오라클 데이터베이스와 연결 시도
			con = DriverManager.getConnection(url, user, password);
			
			if(con != null) {
				System.out.println("오라클 데이터베이스와 연결 성공!!!");
			}
			
			// 3단계 : 오라클 데이터베이스에 전송할 SQL문 작성.
			String sql = "insert into dept values(?, ?, ?)";
			
			pstmt = con.prepareStatement(sql);
			
			pstmt.setInt(1, Integer.parseInt(deptno));
			pstmt.setString(2, dname);
			pstmt.setString(3, loc);
			
			// 4단계 : 데이터베이스에 SQL문 전송 및 실행.
			int result = pstmt.executeUpdate();
			
			if(result > 0) {
				System.out.println("신규 부서 등록 성공!!!");
			}else {
				System.out.println("신규 부서 등록 실패~~~");
			}
			
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} finally {
			
			try {
				// 연결되어 있던 자원들을 종료시켜 주자.
				sc.close();
				pstmt.close();
				con.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}

	}

}
