package himedia;

import java.io.File;
import java.text.SimpleDateFormat;
import java.util.Date;

public class File_IO_11 {

	public static void main(String[] args) {
		
		File temp = new File("C:/Windows/System32");
		
		SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd a HH:mm");
		
		/*
		 * listFiles() 메서드
		 * ==> 현재 디렉토리에 포함된 파일 및 서브 디렉토리 목록을
		 *     전부 확인하여 File 객체 배열로 반환해 주는 메서드.
		 */
		
		File[] contents = temp.listFiles();
		
		System.out.println("이름\t\t\t\t\t\t\t\t\t형태\t크기\t날짜\t시간");
		
		System.out.println("------------------------------------------------------------------");
		
		for(File file : contents) {
			
			if(!file.isDirectory()) {
				
				System.out.print(file.getName() +"\t"+ file.length()+"\t");
				
			}else {
				
				System.out.print("<DIR>\t" + file.getName());
			}
			
			
			// lastModified() : 파일의 마지막 수정 날짜 및 시간을 반환해 주는 메서드.
			System.out.print(sdf.format(new Date(file.lastModified())));
			
			System.out.println();
			
		}  // for 반복문 end
	}

}
