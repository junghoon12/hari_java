package himedia;

import java.io.FileInputStream;
import java.io.InputStream;

public class File_IO_03 {

	public static void main(String[] args) {
		
		// 바이트 스트림 방식
		InputStream is = null;
		
		try {
			is = new FileInputStream("D:\\KDT\\test\\test.txt");
			
			while(true) {
				
				int readByte = is.read();
				
				// read() 메서드로 파일을 읽을 때 더 이상
				// 읽을 데이터가 없는 경우에는 -1 이라는 값을 반환을 함.
				if(readByte == -1) {
					
					break;
				}
				
				System.out.print((char)readByte + " ");
				
			}  // while 반복문 end
			
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}

}
