package himedia;

import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.io.Reader;

/*
 * [문제] File_IO_05 예제 클래스를 읽어 들여서
 *       콘솔 창에 출력해 보세요.
 */

public class File_IO_06 {

	public static void main(String[] args) {
		
		Reader reader = null;
		
		try {
			reader = 
				new FileReader("D:\\KDT\\workspace(java)\\Ch11_File_IO\\src\\himedia\\File_IO_05.java");
			
			while(true) {
				int readByte = reader.read();
				
				if(readByte == -1) {
					
					break;
				}
				
				System.out.print((char)readByte);
			
			}  // while 반복문 end
			
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} finally {
			
			try {
				// 입출력 객체는 종료시켜 주는 것이 좋음.
				reader.close();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}

	}

}
