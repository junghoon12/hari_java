package himedia;

import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;

/*
 * File 클래스
 * - 파일 및 디렉토리(폴더)를 만들어 주는 클래스.
 * - 파일 입출력 시에 사용됨.
 * - 파일 디렉토리에 대한 경로명, 크기, 타입, 수정 날짜 등의
 *   속성을 제공함. 또한 파일 삭제, 디렉토리 생성, 파일 이름
 *   변경, 디렉토리 내의 파일 리스트 제공 등 다양한 파일 관리
 *   작업을 제공함.
 */

public class File_IO_10 {

	public static void main(String[] args) throws IOException {
		
		// D:/KDT/test 폴더가 존재함.
		// D:/KDT/test/sample 폴더를 만들고 싶음.
		// D:/KDT/test/sample/sample.txt 파일도 만들고 싶음.
		
		
		// 1. D:/KDT/test/sample 폴더를 만들어 보자.
		File dir = new File("D:/KDT/test/sample");
		
		if(!dir.exists()) {
			
			dir.mkdir();    // 실제로 폴더를 만들어 주는 메서드.
			System.out.println("폴더 생성 완료!!!");
		}
		
		
		// 2. D:/KDT/test/sample/sample.txt 파일도 만들어 보자.
		File file = new File(dir, "sample.txt");
		
		if(!file.exists()) {
			
			file.createNewFile();  // 실제로 파일을 만들어 주는 메서드.
			System.out.println("파일 생성 완료!!!");
		}
		
		// 원본 소스 파일 경로
		FileReader fr = 
				new FileReader("D:\\KDT\\workspace(java)\\Ch11_File_IO\\src\\himedia\\File_IO_07.java");
		
	
		// 원본 소스 파일이 복사되어 저장될 경로
		FileWriter fw = new FileWriter("D:/KDT/test/sample/sample.txt");
		
		
		while(true) {
			
			int readByte = fr.read();
			
			if(readByte == -1) {
				
				break;
			}
			
			
			fw.write(readByte);
			
		}  // while 반복문 end
		
		fw.close(); fr.close();
		
		System.out.println("파일 복사 완료!!!");

	}

}
