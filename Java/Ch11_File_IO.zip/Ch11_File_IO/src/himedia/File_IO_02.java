package himedia;

import java.io.IOException;

public class File_IO_02 {

	public static void main(String[] args) {
		
		System.out.println("한 줄을 입력하세요.....");
		
		
			
			try {
				
				while(true) {
					
					int readByte = System.in.read();
					
					if(readByte == '\n') {
						
						break;
					}
					
					System.out.print((char)readByte + " ");
					
				}  // while 반복문 end
				
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		
	}

}
