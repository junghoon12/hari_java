package himedia;

import java.io.FileWriter;
import java.io.IOException;
import java.io.Writer;
import java.util.Scanner;

/*
 * java 스트림의 종류
 * 1. 바이트 스트림 관련 클래스
 *    - 바이트 스트림 방식으로 데이터를 입출력하는 클래스.
 *      ==> xxxInputStream / xxxOutputStream
 * 
 * 2. 문자 스트림 관련 클래스
 *    - 문자 스트림 방식으로 데이터를 입출력하는 클래스.
 *      ==> xxxReader / xxxWriter
 * 
 * 3. 바이트 스트림 -> 문자 스트림으로 변환하는 클래스
 *    ==> InputStreamReader / OutputStreamWriter
 */

public class File_IO_05 {

	public static void main(String[] args) {
		
		Scanner sc = new Scanner(System.in);
		
		// 문자 스트림 방식으로 키보드로 입력된 데이터를
		// 파일에 출력하는 예제.
		Writer writer = null;
		
		try {
			
			writer = new FileWriter("D:\\KDT\\test\\test2.txt");
			
			System.out.println("한 줄을 입력하세요.....");
			
			String str = sc.nextLine();
			
			writer.write(str);
			
			// writer.flush();
			
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} finally {
			
			try {
				// 입출력과 관련된 파일은 종료시켜주는 것이 좋음.
				writer.close();
				sc.close();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
		}

	}

}







