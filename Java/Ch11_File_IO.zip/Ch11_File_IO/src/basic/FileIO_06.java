package basic;

import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;

/*
 * [문제] 파일탐색기 안에 C 드라이브가 있음.
 *       windows 폴더 안에 system.ini 파일을
 *       읽어 와서 콘솔 창에 출력해 보세요.
 */

public class FileIO_06 {

	public static void main(String[] args) {
		
		InputStream is = null;
		
		try {
			is = new FileInputStream("C:/windows/system.ini");
			
			while(true) {
				
				int readByte = is.read();
				
				if(readByte == -1) {
					
					break;
				}
				
				System.out.print((char)readByte);
				
			}
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} finally {
			try {
				is.close();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}

	}

}
