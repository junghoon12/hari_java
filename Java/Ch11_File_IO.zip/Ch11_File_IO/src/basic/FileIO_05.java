package basic;

import java.io.FileReader;
import java.io.IOException;
import java.io.Reader;

/*
 * [문제] FileIO_04 클래스를 읽어서
 *       콘솔 창에 출력해 보세요.
 */

public class FileIO_05 {

	public static void main(String[] args) {
		
		Reader reader = null;
		
		try {
			reader = new FileReader("D:/NCS/workspace(java)/Ch11_File_IO/src/basic/FileIO_04.java");
			
			while(true) {
				
				int readCount = reader.read();
				
				if(readCount == -1) {
					
					break;
				}
				
				System.out.print((char)readCount);
				
			}
			
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} finally {
			try {
				// 입출력 객체는 종료시켜 주는 것이 좋다.
				reader.close();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}

	}

}
