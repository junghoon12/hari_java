package basic;

import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;

/*
 * [문제] FileIO_08번 원본 소스 내용을 복사하여
 *       이전 예제에서 만든 D:/test/sample/sample.txt
 *       파일에 복사하시오.
 */

public class FileIO_10 {

	public static void main(String[] args) throws Exception {
		
		// 원본 소스 파일 경로
		FileReader fr = new FileReader("D:\\NCS\\workspace(java)\\Ch11_File_IO\\src\\basic\\FileIO_08.java");
		
		// 원본 소스 파일이 복사되어 저장될 파일 경로
		FileWriter fw = new FileWriter("D:/test/sample/sample.txt");
		
		while(true) {
			
			int readByte = fr.read();
			
			if(readByte == -1) {
				break;
			}
			
			fw.write(readByte);
		}
		
		// 입출력 객체를 닫아 주자.
		fw.close(); fr.close();
		
		System.out.println("파일 소스 복사 완료!!!");
		
	}

}
