package himedia;

public class Variable_02 {

	public static void main(String[] args) {
		
		// 1. 변수 선언
		// int num1;
		
		// 2. 변수 초기화
		// num1 = 130;
		
		// 1 + 2 : 변수 선언 및 변수 초기화
		int num1 = 130;
		
		// 변수 활용
		num1 = num1 + 346;
		
		// 3. 변수 출력
		System.out.println("num1 >>> " + num1);
		
		

	}

}
