package himedia;

// 두 개의 변수에 있는 값을 바꾸어 보자

public class Variable_08 {

	public static void main(String[] args) {
		
		// 변수 선언 및 초기화 작업
		int su1 = 47, su2 = 88;
		
		System.out.println("바꾸기 전.........");
		
		System.out.println("su1 >>> " + su1);
		
		System.out.println("su2 >>> " + su2);
		
		// 방법1
		// int temp = su1;
		
		// su1 = su2;
		
		// su2 = temp;
		
		
		// 방법2
		int temp = su2;
		
		su2 = su1;
		
		su1 = temp;
		
		
		System.out.println();
		
		System.out.println("바꾼 후 .........");
		
		System.out.println("su1 >>> " + su1);
		
		System.out.println("su2 >>> " + su2);
		

	}

}
