package himedia;

/*
 * [문제] 두 개의 변수를 선언하여 각각의 변수에 데이터를 넣은 후,
 *       각각의 변수를 콘솔 화면에 출력해 보세요.
 *       또한 두 변수에 있는 데이터를 더한 값을 콘솔에 출력해 보세요.
 */

public class Variable_03 {

	public static void main(String[] args) {
		
		// 1. 변수 선언 및 변수 초기화
		int su1 = 33, su2 = 345;
		
		// 2. 변수 출력
		System.out.println("su1 >>> " + su1);
		
		System.out.println("su2 >>> " + su2);
		
		System.out.println("su1 + su2 >>> " + (su1+su2));

	}

}
