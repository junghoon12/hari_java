package basic;

public class Variable_02 {

	public static void main(String[] args) {
		
		// 1. 변수 선언
		// int num;
		
		// 2. 변수 초기화
		// num = 147;
		
		// 1 + 2 : 변수 선언 및 변수 초기화
		int num = 147;
		
		num = num + 100;
		
		int num2 = num;
		
		
		// 3. 변수에 저장된 값을 출력해 보자.
		System.out.println("num >>> " + num);
		
		System.out.println("num2 >>> " + num2);
		
		

	}

}
