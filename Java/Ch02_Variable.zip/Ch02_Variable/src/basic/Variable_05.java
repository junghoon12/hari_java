package basic;

/*
 * 실수자료형 : 소숫점이 생기는 자료형.
 * 
 * - float : 출력되는 값이 소숫점 이하 6~7자리까지 발생함.
 * - double : 출력되는 값이 소숫점 이하 15~16자리까지 발생함. - 기본자료형
 */

public class Variable_05 {

	public static void main(String[] args) {
		
		double dNum = 123.45666666666;
		
		System.out.println("dNum >>> " + dNum);
		
		float fNum = 123.45666666f;
		
		/*
		 * float 자료형의 변수에 실수 값을 저장 시 오류 발생.
		 * 이유 : 실수 자료형의 기본형은 double 형 이기 때문임.
		 * - 따라서 float 자료형의 변수에 실수 데이터를 저장 시
		 *   반드시 실새값 앞에 float 라고 형을 기재해 주거나,
		 *   아니면 값 뒤에 f를 붙여주면 됨.(생략 시 error 발생)
		 * - 데이터의 손실은 거의 빌생하지 않음. 
		 */
		System.out.println("fNum >>> " + fNum);
		
		
		
		
		

	}

}
