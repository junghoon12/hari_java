package basic;

public class Variable_08 {

	public static void main(String[] args) {
		
		// 변수 선언 및 변수 초기화
		int su1 = 47, su2 = 85;
		
		System.out.println("두 수를 변경하기 전...");
		
		System.out.println("su1 >>> " + su1);
		
		System.out.println("su2 >>> " + su2);
		
		// 두 변수의 값을 바꾸어 보자.
		// 방법 1
		// int temp = su1;
		
		// su1 = su2;
		
		// su2 = temp;
		
		// 방법 2
		int temp = su2;
		
		su2 = su1;
		
		su1 = temp;
		
		System.out.println();  // 빈 줄 추가
		
		System.out.println("두 수를 변경한 후...");
		
		System.out.println("su1 >>> " + su1);
		
		System.out.println("su2 >>> " + su2);
		
		
		
		
	}

}
