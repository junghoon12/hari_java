package basic;

import java.awt.Button;
import java.awt.Frame;
import java.awt.Panel;

public class Ex05_Button extends Frame {
	
	public Ex05_Button() {
	
		setTitle("Button 예제");
		
		// 1단계 : 컨테이너를 만들자.
		Panel container = new Panel();
		
		// 2단계 : 컴포넌트를 만들어야 한다.
		Button button1 = new Button();
		
		// 3단계 : 컴포넌트를 컨테이너에 올려야 한다.
		container.add(button1);
		
		// 4단계 : 컨테이너를 프레임에 올려야 한다.
		add(container);
		
		setBounds(300, 300, 300, 400);
		
		setVisible(true);
		
	}
	

	public static void main(String[] args) {
		
		new Ex05_Button();

	}

}
