package basic;

import java.awt.BorderLayout;

import javax.swing.*;

public class Ex21_Layout extends JFrame {

	public Ex21_Layout() {
	
		setTitle("간단한 계산기");
		
		// 1. 컨테이너를 3개를 만들자.
		JPanel container1 = new JPanel();
		JPanel container2 = new JPanel();
		JPanel container3 = new JPanel();
		
		
		// 2. 컴포넌트를 만들자.
		// 2-1. 상단에 들어갈 컴포넌트를 만들자.
		JLabel jl1 = new JLabel("수 1 : ");
		JTextField jtf1 = new JTextField(5);
		
		JLabel jl2 = new JLabel("수 2 : ");
		JTextField jtf2 = new JTextField(5);
		
		JLabel jl3 = new JLabel("연산자 : ");
		JTextField jtf3 = new JTextField(1);
		
		// 2-2. 중앙에 들어갈 컴포넌트를 만들자.
		JTextArea jTextArea = new JTextArea(5, 20);
		
		JScrollPane jsp = new JScrollPane(
				jTextArea, 
				ScrollPaneConstants.VERTICAL_SCROLLBAR_AS_NEEDED, 
				ScrollPaneConstants.HORIZONTAL_SCROLLBAR_NEVER);
				
		// 2-3. 하단에 들어갈 컴포넌트를 만둘자.
		JButton button1 = new JButton("계 산");
		JButton button2 = new JButton("종 료");
		JButton button3 = new JButton("취 소");
		
		// 3. 컴포넌트를 컨테이너에 올려주어야 한다.
		// 3-1. 상단 컨테이너에 들어갈 컴포넌트들을 올려 주자.
		container1.add(jl1); container1.add(jtf1);
		container1.add(jl2); container1.add(jtf2);
		container1.add(jl3); container1.add(jtf3);
		
		// 3-2. 중앙 컨테이너에 들어갈 컴포넌트들을 올려 주자.
		container2.add(jsp);
		
		// 3-3. 하단 컨테이너에 들어갈 컨포넌트들을 올려 주자.
		container3.add(button1);
		container3.add(button2); container3.add(button3);
		
		// 4. 컨테이너를 프레임에 올려 주어야 한다.
		// 컨테이너를 올릴 때 배치를 하여 올려주면 됨.
		
		add(container1, BorderLayout.NORTH);
		add(container2, BorderLayout.CENTER);
		add(container3, BorderLayout.SOUTH);
		
		setBounds(100, 100, 100, 300);
		
		// pack() : 프레임의 크기를 조절해 주는 메서드.
		pack();
		
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		
		setVisible(true);
		
	}
	
	public static void main(String[] args) {
		
		new Ex21_Layout();

	}

}
