package basic;

import javax.swing.*;

public class Ex13_JLabel_JTextField extends JFrame {

	public Ex13_JLabel_JTextField() {
	
		setTitle("JLabel & JTextField 예제");
		
		JPanel container = new JPanel();
		
		JLabel label1 = new JLabel("이 름 : ");
		JTextField name = new JTextField(15);
		
		JLabel label2 = new JLabel("학 과 : ");
		JTextField major = new JTextField(15);
		
		JLabel label3 = new JLabel("주 소 : ");
		JTextField addr = new JTextField(15);
		
		container.add(label1); container.add(name);
		container.add(label2); container.add(major);
		container.add(label3); container.add(addr);
		
		add(container);
		
		setBounds(100, 100, 250, 200);
		
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		
		setVisible(true);
		
	}
	
	
	public static void main(String[] args) {
		
		new Ex13_JLabel_JTextField();

	}

}
