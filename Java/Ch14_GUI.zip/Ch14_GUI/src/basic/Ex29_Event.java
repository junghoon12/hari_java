package basic;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.*;

public class Ex29_Event extends JFrame {

	public Ex29_Event() {
	
		JPanel container = new JPanel();
		
		JButton button = new JButton("종 료");
		
		container.add(button);
		
		add(container);
		
		setBounds(100, 100, 200, 200);
		
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		
		setVisible(true);
		
		// 4. 익명 클래스를 이용하여 이벤트 처리하는 방법.
		button.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				
				JOptionPane.showMessageDialog(null, "시스템이 종료되었습니다.");
				
				System.exit(0);
				
			}
		});
		
	}
	
	public static void main(String[] args) {
		
		new Ex29_Event();

	}

}
