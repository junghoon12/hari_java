package basic;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.*;

// 독립된 클래스를 작성하여 이벤트를 처리
class MyButton implements ActionListener {

	@Override
	public void actionPerformed(ActionEvent e) {
		
		// getSource() : 현재 발생한 이벤트 소스 컴포넌트의
		//               정보(러퍼런스)를 반환해 주는 메서드.
		//               반환타입이 Object 타입이므로 원래의
		//               타입으로 형변환을 해 주어야 함.
		JButton button = (JButton)e.getSource();
		
		if(button.getText().equals("JAVA")) {
			button.setText("자바");
		}else {
			button.setText("JAVA");
		}
		
	}
	
}


public class Ex27_Event extends JFrame {

	public Ex27_Event() {
	
		setTitle("버튼 이벤트");
		
		JPanel container = new JPanel();
		
		// 1. 컴포넌트를 만들어 보자.
		JButton button = new JButton("JAVA");
		
		// 2. 컴포넌트를 컨테이너에 올려야 한다.
		container.add(button);
		
		// 3. 컨테이너를 프레임에 올려야 한다.
		add(container);
		
		setBounds(200, 200, 100, 100);
		
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		
		setVisible(true);
		
		// 이벤트를 처리하는 방법
		// 이벤트와 관련하여 독립된 클래스를 생성하여 처리하는 방법.
		MyButton listener = new MyButton();
		
		button.addActionListener(listener);
		
	}
	
	public static void main(String[] args) {
		
		new Ex27_Event();

	}

}
