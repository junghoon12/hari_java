package basic;

import java.awt.BorderLayout;
import java.awt.CardLayout;
import java.awt.Color;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.*;

public class Ex31_Event extends JFrame {

	CardLayout cardLayout;
	JPanel cardPanel;
	
	public Ex31_Event() {
	
		cardPanel = new JPanel(new CardLayout());
		
		// 카드 패널에 추가할 각각의 카드들
		JPanel card1 = new JPanel();
		card1.add(new JLabel("Card 1"));
		card1.setBackground(Color.BLUE);
		
		JPanel card2 = new JPanel();
		card2.add(new JLabel("Card 2"));
		card2.setBackground(Color.YELLOW);
		
		JPanel card3 = new JPanel();
		card3.add(new JLabel("Card 3"));
		card3.setBackground(Color.LIGHT_GRAY);
		
		cardPanel.add(card1, "Card 1");
		cardPanel.add(card2, "Card 2");
		cardPanel.add(card3, "Card 3");
		
		cardLayout = (CardLayout)cardPanel.getLayout();
		
		// 버튼 컴포넌트를 생성하여 클릭 시 다음 카드로 이동하게 설정.
		JButton button = new JButton("Next Card");
		
		
		setLayout(new BorderLayout());
		
		add(cardPanel, BorderLayout.CENTER);
		
		add(button, BorderLayout.SOUTH);
		
		setBounds(100, 100, 300, 300);
		
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		
		setVisible(true);
		
		
		button.addActionListener(new ActionListener() {
			
			int count = 0;
			
			@Override
			public void actionPerformed(ActionEvent e) {
			
				count++;
				
				if(count >= 3) {
					count = 0;  // 3번째 카드 보여진 후 다시 처음으로 돌아감.
				}
				
				cardLayout.show(cardPanel, "Card "+(count+1));
				
			}
		});
		
		
	}
	
	public static void main(String[] args) {

		new Ex31_Event();

	}

}
