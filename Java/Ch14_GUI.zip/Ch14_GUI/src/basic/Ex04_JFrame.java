package basic;

import javax.swing.JFrame;

public class Ex04_JFrame {

	public static void main(String[] args) {
		
		JFrame frame = new JFrame("네번째 예제");
		
		frame.setBounds(300, 300, 300, 400);
		
		frame.setVisible(true);

	}

}
