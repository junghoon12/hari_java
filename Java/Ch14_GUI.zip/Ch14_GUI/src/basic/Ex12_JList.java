package basic;

import javax.swing.*;

public class Ex12_JList extends JFrame {

	public Ex12_JList() {
	
		setTitle("JList 예제");
		
		JPanel container = new JPanel();
		
		String[] job = {"회사원", "공무원", "학생", "주부", "기타"};
		
		JList<String> list = new JList<String>(job);
		
		container.add(list);
		
		add(container);
		
		setBounds(100, 100, 300, 300);
		
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		
		setVisible(true);
		
		
	}
	
	public static void main(String[] args) {
		
		new Ex12_JList();

	}

}
