package basic;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.*;

/*
 * Event Handler(이벤트 핸들러)?
 * - 각 컴포넌트에 대하여 특정 행위를 하였을 때 그 행위에 대한
 *   작업을 처리할 수 있도록 하는 것을 말함.
 *   사용자 또는 프로그램에 의해 발생할 수 있는 하나의 사건.
 * - 이벤트를 처리하는 자바 프로그램 코드로써 클래스를 만듦.
 *   이벤트 리스너는 인터페이스를 제공하며, 개발자는 이 인터페이스를
 *   상속을 받고 추상메서드를 구현하여 이벤트 리스너를 작성한다.
 * - 현재 발생한 이벤트에 관한 정보를 가진 객체를 말함.
 *   이벤트 리스너에게 전달이 됨.
 * - 각 컴포넌트별 이벤트 처리 메서드 : add로 시작하여 Listener
 *   로 끝나는 메서드.
 * - 이벤트 관련 클래스 : Listener 인터페이스, Adapter 클래스,
 *                    Event 클래스
 * - 이벤트 리스너는 모두가 다 인터페이스임(xxxListener)
 *   이벤트 리스너는 이벤트를 처리하는 프로그램 코드를 말함.
 *   이벤트 리스너는 컴포넌트에 연결되어 있어야 작동을 함.
 *   즉, 화면에 구성된 컴포넌트들은 이벤트 리스너를 하나씩 가지고 있음.
 * - 컴포넌트와 이벤트 리스너를 연결시키는 메서드 : addXXXXListener()
 *   ==> XXXX는 리스너 이름.
 *   
 * - 이벤트 리스너 작성 과정
 *   1) 이벤트와 이벤트 리스너 선택 
 *      ==> 목적에 적합한 이벤트와 리스너 인터페이스 선택.
 *   2) 이벤트와 리스너 클래스 작성
 *      ==> 리스너 인터페이스를 상속받은 클래스를 작성하고
 *          추상메서드를 모두 구현.
 *   3) 이벤트 리스너 등록
 *      ==> 이벤트를 받을 컴포넌트에 이벤트 리스너 등록
 */

/*
 * Event Handler 클래스 생성 방법 - 4가지
 * 1. Listener 인터페이스를 구현하는 방법
 * 2. Adapter 클래스를 구현하는 방법
 * 3. Frame 클래스에 Listener 구현하는 방법 - 가장 많이 사용.
 * 4. 익명 클래스를 이용하는 방법 - 많이 사용이 됨. 
 */

/*
 * 아래 화면과 같이 버튼을 눌렀을 때 이벤트가 발생되고
 * 처리되는 과정을 한 번 확인해 보자.
 * 1. 사용자가 마우스로 화면의 버튼을 누른다.
 * 2. 버튼 클릭은 운영체제의 마우스 드라이버를 거쳐 
 *    자바 가상 기계에 전달된다.
 * 3. 자바 가상 기계는 이벤트 분배 스레드(Event Dispatch Thread)
 *    에게 마우스 클릭에 관한 정보를 보낸다.
 * 4. 이벤트 분배 스레드는 이벤트(ActionEvent) 객체를 생성함.
 *    이벤트 객체는 이벤트에 관한 여러 정보를 담은 객체임.
 *    이벤트 객체 내에 저장되는 정보 중, 특별히 이벤트를 발생시킨
 *    컴포넌트를 이벤트 소스(Event Source)라고 부름. 여기서
 *    이벤트 소스는 JButton 컴포넌트임.
 * 5. 이벤트 분배 스레드는 JButton에 연결된 이벤트 리스너를
 *    찾아 호출을 함.
 * 6. 이벤트 분배 스레드는 이벤트 리스너로부터 리턴한 후 다음 
 *    이벤트를 기다리게 됨.
 *    
 * 위 내용 중 주요 용어
 * - 이벤트 소스 : 이벤트를 발생시킨 GUI 컴포넌트.
 * - 이벤트 객체 : 발생한 이벤트에 대한 정보(이벤트 종류, 이벤트 소스,
 *              화면 좌표, 마우스 버튼 종류, 눌려진 키)를 담는
 *              객체로서, 이벤트에 따라 서로 다른 정보가 저장됨.
 * - 이벤트 리스너 : 이벤트를 처리하는 코드로서 컴포넌트에 등록되어야
 *                작동이 가능함.
 * - 이벤트 분배 스레드 : 이벤트 기반 프로그래밍의 핵심 요소로써
 *                    무한 루프를 실행하는 스레드임. 자바 가상
 *                    기계로부터 이벤트의 발생을 통지 받아, 이벤트
 *                    소스와 이벤트 종류를 결정하고 이에 따라 적절한
 *                    이벤트 객체를 생성하고 이벤트 리스너를 찾아 
 *                    호출함.
 */

// 독립된 클래스를 작성하여 이벤트를 처리하는 방법
class A implements ActionListener {

	@Override
	public void actionPerformed(ActionEvent e) {
		
		JOptionPane.showMessageDialog(null, "시스템 종료");
		
		System.exit(0);    // 시스템을 종료시키는 메서드.
		
	}
	
}

public class Ex26_Event extends JFrame {

	public Ex26_Event() {
	
		JPanel container = new JPanel();
		
		JButton exit = new JButton("종료");
		
		container.add(exit);
		
		add(container);
		
		setBounds(100, 100, 200, 200);
		
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		
		setVisible(true);
		
		
		// 이벤트 처리
		A a = new A();
		
		// 이벤트 등록
		exit.addActionListener(a);
		
	}
	
	
	public static void main(String[] args) {
	
		new Ex26_Event();
	}

}
