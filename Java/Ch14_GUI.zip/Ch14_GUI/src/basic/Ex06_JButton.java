package basic;


import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JPanel;

public class Ex06_JButton extends JFrame {

	public Ex06_JButton() {
	
		setTitle("Button 예제");
		
		// 1단계 : 컨테이너를 만들자.
		JPanel container = new JPanel();
		
		// 2단계 : 컴포넌트를 만들어야 한다.
		JButton button1 = new JButton("버튼1");
		JButton button2 = new JButton("버튼2");
		JButton button3 = new JButton("버튼3");
		
		// 3단계 : 컴포넌트를 컨테이너에 올려야 한다.
		container.add(button1);
		container.add(button2); container.add(button3);
		
		// 4단계 : 컨테이너를 프레임에 올려야 한다.
		add(container);
		
		setBounds(300, 300, 300, 400);
		
		setVisible(true);
	}
	
	public static void main(String[] args) {
		
		new Ex06_JButton();

	}

}
