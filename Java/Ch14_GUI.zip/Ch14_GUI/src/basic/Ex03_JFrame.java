package basic;

import javax.swing.JFrame;

public class Ex03_JFrame extends JFrame {

	public Ex03_JFrame() {
	
		setTitle("세번째 예제");
		
		setBounds(300, 300, 300, 400);
		
		setVisible(true);
		
	}  // 기본 생성자
	
	
	public static void main(String[] args) {
		
		new Ex03_JFrame();

	}

}
