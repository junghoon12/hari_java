package basic;

import java.awt.CardLayout;
import java.awt.Color;
import java.awt.Frame;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;

import javax.swing.*;


class EventHandler extends WindowAdapter {
	
	// 윈도우 창의 x 버튼을 누를 때
	@Override
	public void windowClosing(WindowEvent e) {
		
		System.exit(0);
	}
}

// 3. Frame 클래스에 Listener 구현하는 방법 - 가장 많이 사용.
public class Ex28_Event extends Frame implements MouseListener {

	CardLayout cardLayout = new CardLayout();
	
	JPanel container1 = new JPanel();
	JPanel container2 = new JPanel();
	JPanel container3 = new JPanel();
	JPanel container4 = new JPanel();
	
	public Ex28_Event() {
	
		setTitle("CardLayout 예제");
		
		setLayout(cardLayout);
		
		// 각각의 컨테이너에 배경색 지정.
		container1.setBackground(Color.BLUE);
		container2.setBackground(Color.YELLOW);
		container3.setBackground(Color.CYAN);
		container4.setBackground(Color.GRAY);
		
		// 1. 컴포넌트를 만들어 보자.
		// JLabel label1 = new JLabel("Card1");
		
		container1.add(new JLabel("Card1"));
		container2.add(new JLabel("Card2"));
		container3.add(new JLabel("Card3"));
		container4.add(new JLabel("Card4"));
		
		add(container1, "1"); add(container2, "2");
		add(container3, "3"); add(container4, "4");
		
		// 컴포넌트와 이벤트 리스너와 연결 작업
		container1.addMouseListener(this);
		container2.addMouseListener(this);
		container3.addMouseListener(this);
		container4.addMouseListener(this);
		
		setBounds(200, 200, 300, 300);
		
		addWindowListener(new EventHandler());
		
		setVisible(true);
		
	}
	
	public static void main(String[] args) {
		
		new Ex28_Event();

	}

	@Override
	public void mouseClicked(MouseEvent e) {
		
		cardLayout.next(this);
	}

	@Override
	public void mousePressed(MouseEvent e) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void mouseReleased(MouseEvent e) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void mouseEntered(MouseEvent e) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void mouseExited(MouseEvent e) {
		// TODO Auto-generated method stub
		
	}

}
