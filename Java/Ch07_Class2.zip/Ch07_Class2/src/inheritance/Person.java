package inheritance;

public class Person {

	// 멤버변수
	String juminNo;        // 주민번호
	String name;           // 이름
	String age;            // 나이
	String job;            // 직업
	

}
