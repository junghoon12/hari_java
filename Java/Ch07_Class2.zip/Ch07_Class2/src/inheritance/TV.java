package inheritance;

public class TV extends Volume {

	
}
