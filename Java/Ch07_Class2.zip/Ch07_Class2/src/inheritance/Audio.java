package inheritance;

public class Audio extends Volume {

}
