package inheritance;

public class Car2 extends Car {

	String color = "검정색";
	
}
