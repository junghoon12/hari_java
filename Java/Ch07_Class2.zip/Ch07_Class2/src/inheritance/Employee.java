package inheritance;

public class Employee extends Person {

	int salary;       // 급여
	
	void getEmployeeInfo() {
		
		System.out.println("주민번호 >>> " + juminNo);
		System.out.println("이   름 >>> " + name);
		System.out.println("나   이 >>> " + age);
		System.out.println("직   업 >>> " + job);
		System.out.println("급   여 >>> " + salary + " 만원");
		
	}  // getEmployeeInfo() 메서드 end
	
}
