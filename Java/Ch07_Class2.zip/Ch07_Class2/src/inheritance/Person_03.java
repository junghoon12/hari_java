package inheritance;

public class Person_03 {

	public static void main(String[] args) {
		
		Student student = 
				new Student("001101-3312347", "홍길동", "25", "대학생", "경제학과");
		
		student.getStudentInfo();
		
		System.out.println();
		
		// Student student2 = new Student();
		
		Employee employee = new Employee();
		
		employee.juminNo = "960505-2345678";
		
		employee.name = "홍길자";
		
		employee.age = "30";
		
		employee.job = "회사원";
		
		employee.salary = 450;
		
		
		employee.getEmployeeInfo();

		
	}

}
