package inheritance;

public class Person_03 {

	public static void main(String[] args) {
		
		// 기본 생성자가 없는 경우에는 error 발생.
		// Student student = new Student();
		
		Student student = new Student
				("001101-2273716", "홍길자", "27", "대학생", "영문학과");
		
		student.getStudentInfo();
		
		System.out.println();
		
		Employee employee = new Employee();
		
		employee.juminNo = "940517-1234567";
		
		employee.name = "홍길동";
		
		employee.age = "50";
		
		employee.job = "회사원";
		
		employee.salary = 5000;
		
		employee.getEmployeeInfo();
		
			
	}

}
