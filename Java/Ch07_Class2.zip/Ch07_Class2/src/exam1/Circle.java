package exam1;

public class Circle implements Shape {

	// 멤버변수
	int radius;             // 반지름 변수
	
	public Circle() {  }  // 기본 생성자
	
	public Circle(int radius) {
		
		this.radius = radius;
	
	}  // 인자 생성자
	
	
	public int getRadius() {
		return radius;
	}

	public void setRadius(int radius) {
		this.radius = radius;
	}

	@Override
	public double findArea() {
		
		// 원의 면적 = 3.14 * 반지름 * 반지름
		return 3.14 * radius * radius;
	
	}

}
