package exam1;

public class Permanent extends Employee{

	// 멤버변수
	// String name;     // 생략
	int pay;            // 기본 급여
	int bonus;          // 보너스
	
	public Permanent() { }  // 기본 생성자
	
	public Permanent(String name,
			int pay, int bonus) {
		
		this.name = name;
		this.pay = pay;
		this.bonus = bonus;
		
	}  // 인자 생성자

	// 부모 클래스의 추상메서드 재정의.
	@Override
	int getPays() {
		
		return pay + bonus;
	}
	

}
