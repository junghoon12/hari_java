package exam1;

public interface Shape {

	// 면적을 구하는 추상 메서드.
	double findArea();
	
}
