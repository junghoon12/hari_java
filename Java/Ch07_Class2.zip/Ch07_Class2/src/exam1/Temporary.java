package exam1;

public class Temporary extends Employee {

	// 멤버변수
	int time;                   // 작업 시간
	int pay;                    // 시간당 급여
	
	public Temporary() {  }  // 기본 생성자
	
	
	public int getTime() {
		return time;
	}
	
	public void setTime(int time) {
		this.time = time;
	}
	
	public int getPay() {
		return pay;
	}
	
	public void setPay(int pay) {
		this.pay = pay;
	}
	
	
	@Override
	int getPays() {
		
		// 급여 계산 : 작업시간 * 시간당 급여
		return time * pay;
	}

}
