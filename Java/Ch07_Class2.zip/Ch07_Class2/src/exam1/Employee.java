package exam1;

public abstract class Employee {   // 추상 클래스

	// 멤버변수
	String name;      // 이름

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}
	
	abstract int getPays();    // 추상 메서드
	
	
}
