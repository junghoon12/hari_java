package exam;

public class Temporary extends Employee {

	// 멤버변수
	// String name;
	int time;            // 작업 시간
	int pay;             // 시간당 급여
	
	public Temporary() { }  // 기본 생성자
	
	public Temporary(String name,
			int time, int pay) {
		
		this.name = name;
		this.time = time;
		this.pay = pay;
		
	}  // 인자 생성자

	
	public int getTime() {
		return time;
	}

	public void setTime(int time) {
		this.time = time;
	}

	public int getPay() {
		return pay;
	}

	public void setPay(int pay) {
		this.pay = pay;
	}
	
	
	// 부모 클래스에서 상속을 받은 메서드 재정의.
	@Override
	int getPays() {
		
		return time * pay;
	}
	
	
	
	
	
}
