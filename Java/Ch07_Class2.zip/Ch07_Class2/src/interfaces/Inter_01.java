package interfaces;

public class Inter_01 {

	public static void main(String[] args) {
		
		Sub sub = new Sub();
		
		/*
		 * interface로 클래스가 변경되는 순간
		 * 인터페이스 안에 있던 멤버변수는
		 * static final 키워드가 붙은 상수로 변한다.
		 * 그래서 상수 값을 변경하는 것은 불가능함.
		 */
		// sub.num = 273;  -- 에러 발생.
		
		sub.output1();  // 인터페이스 추상 메서드 재정의 호출.
		
		sub.output2();  // 인터페이스 추상 메서드 재정의 호출.

	}

}
