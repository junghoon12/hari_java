package overriding;

public class Animal {

	
	void sound() {
		
		System.out.println("소리를 냅니다~~~");
		
	}  // sound() 메서드 end
	
	
}
