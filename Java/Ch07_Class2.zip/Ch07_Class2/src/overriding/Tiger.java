package overriding;

public class Tiger extends Animal {

	@Override
	void sound() {

		System.out.println("어흥어흥~~~");
	
	}
	
}
