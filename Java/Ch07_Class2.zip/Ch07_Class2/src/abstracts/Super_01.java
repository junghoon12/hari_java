package abstracts;

public class Super_01 {

	public static void main(String[] args) {
		
		// 추상 클래스는 객체 생성 불가능.
		// Super super = new Super();
		
		Sub sub = new Sub();
		
		sub.num = 143;
		
		System.out.println("calc() 메서드 호출 >>> " + sub.calc());
		
		
		// 추상메서드 제정의 호출
		sub.output();

	}

}
