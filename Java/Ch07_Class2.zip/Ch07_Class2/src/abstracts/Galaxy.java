package abstracts;

public class Galaxy extends SmartPhone {

	// 부모 클래스에서 상속 받은 추상 메서드 - 재정의.
	@Override
	void spec() {
		
		company = "삼성"; name = "Galaxy S25";
		color = "화이트"; size = "23cm";
		weight = "300g"; price = "100만원";
		
		System.out.println
			("제조사 : "+ company + " / 단말기명 : " + name +
			" / 색상 : " +color+ " / 규격 : "+size+
			" / 무게 : " +weight+ " / 가격 : "+price);
		
	}

}
