package abstracts;

public class Employee extends Person {

	String sabun;
	int salary;
	
	
	@Override
	void getPersonInfo() {
		
		System.out.println("사원 사번 >>> " + sabun);
		System.out.println("사원 이름 >>> " + name);
		System.out.println("사원 연봉 >>> " + salary + " 만원");
		
	}  // getPersonInfo() 메서드 end

	
}



