package abstracts;

public class Person_02 {

	public static void main(String[] args) {
		
		Student student = new Student(
				"2024_001", "홍길동", "컴공과");
		
		Employee employee = new Employee();
		
		employee.name = "세종대왕";
		
		employee.sabun = "2024_0001";
		
		employee.salary = 5000;
		
		
		student.getPersonInfo();
		
		System.out.println();
		
		employee.getPersonInfo();
		

	}

}
