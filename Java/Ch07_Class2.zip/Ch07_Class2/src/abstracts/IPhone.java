package abstracts;

public class IPhone extends SmartPhone {

	// 부모 클래스에서 상속 받은 추상 메서드 - 재정의.
	@Override
	void spec() {
		
		company = "애플"; name = "IPhone 16";
		color = "화이트"; size = "15cm";
		weight = "200g"; price = "155만원";
		
		System.out.println
			("제조사 : "+ company + " / 단말기명 : " + name +
			" / 색상 : " +color+ " / 규격 : "+size+
			" / 무게 : " +weight+ " / 가격 : "+price);
		
	}

}
