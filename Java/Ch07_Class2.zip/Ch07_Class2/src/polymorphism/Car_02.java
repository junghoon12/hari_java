package polymorphism;

public class Car_02 {

	public static void main(String[] args) {
		
		Car car = new Car();
		
		car.tire = new HanKookTire();
		
		System.out.println("car.tire >>> " + car.tire);
		
		car.run();
		
		
		car.tire = new KumHoTire();
		
		System.out.println("car.tire >>> " + car.tire);
		
		car.run();
		
	}

}
