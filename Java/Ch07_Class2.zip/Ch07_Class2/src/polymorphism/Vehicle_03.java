package polymorphism;

public class Vehicle_03 {

	public static void main(String[] args) {
		
		Driver driver = new Driver();
		
		// Bus bus = new Bus();
		
		driver.drive(new Bus());
		
		System.out.println();
		
		Taxi taxi = new Taxi();
		
		driver.drive(taxi);
		
		System.out.println();
		
		Subway subway = new Subway();
		
		driver.drive(subway);
		
		

	}

}
