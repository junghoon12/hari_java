package polymorphism;

public class Animal1 {

	void sound() {
		
		System.out.println("소리를 냅니다.");
	}
}
