package polymorphism;

public interface Tire {

	void roll();
	
}
