package polymorphism;

public class Tiger implements Animal {

	@Override
	public void sound() {
		
		System.out.println("어흥어흥~~~");
		
	}

	
}
