package polymorphism;

public class Tiger extends Animal1 {

	@Override
	void sound() {
	
		System.out.println("어흥어흥~~~");
		
	}
}
