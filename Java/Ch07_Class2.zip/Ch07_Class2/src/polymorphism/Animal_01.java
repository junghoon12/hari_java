package polymorphism;

public class Animal_01 {

	public static void main(String[] args) {
		
		Cat cat = new Cat();
		
		cat.sound();
		
		System.out.println();
		
		// 다형성을 이용하여 객체 생성
		Animal animal = new Cat();  // 업 캐스팅
		
		animal.sound();
		
		// animal.prn();
		
		// Cat cat = new Animal();
		
		// Tiger tiger = (Tiger)new Animal1();  // 다운 캐스팅
		
		/*
		 * 다운캐스팅 : 조상타입의 참조변수를 자손타입의 참조변수로 변환하는 것.
		 *           반드시 형변환(casting)을 해 주어야 함.
		 * 업 캐스팅 : 자손타입의 참조변수를 조상타입의 참조변수로 변환하는 것.
		 *           형변환(casting)을 안 해 주어도 됨.
		 */
		// tiger.sound();

	}

}
