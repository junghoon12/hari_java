package polymorphism;

public class Animal_01 {

	public static void main(String[] args) {
		
		// 일반적으로 객체 생성 방법
		// Cat cat = new Cat();
		// Tiger tiger = new Tiger();
		// cat.sound(); tiger.sound();
		
		// 다형성을 이용하여 객체 생성.
		Animal cat = new Cat();
		Animal tiger = new Tiger();
		
		cat.sound(); tiger.sound();
		// cat.output();  // 자식에서 만든 메서드에는 접근 불가함.

	}

}
