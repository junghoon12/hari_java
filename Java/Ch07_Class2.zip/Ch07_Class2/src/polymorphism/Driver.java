package polymorphism;

public class Driver {

	// 매개변수의 다형성
	// 매개변수는 구현된 객체가 들어 올 수 있도록
	// 인터페이스 타입으로 선언.
	void drive(Vehicle vehicle) {
		
		vehicle.run();
	}
	
}
