package polymorphism;

public class HanKookTire implements Tire {

	@Override
	public void roll() {
		
		System.out.println("한국타이어가 회전을 합니다.");
		
	}

}
