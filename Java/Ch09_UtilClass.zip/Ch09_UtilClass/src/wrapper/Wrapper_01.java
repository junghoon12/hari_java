package wrapper;

/*
 * wrapper class
 * - wrap : 감싸다, 포장하다
 * - 기본 자료형을 클래스 타입으로 포장해 놓은 클래스.
 * - 기본 자료형보다 객체로 저장하기 때문에 좀 더 다양한
 *   기능을 제공하기 위해서 사용함.
 * - 기본 타입의 값을 내부에 두고 포장하기 때문에
 *   포장(wrapper) 클래스라고 하기도 함.
 * - 기본 자료형 : byte, short, long, float, double,
 *               boolean, char, int
 * - 포장 클래스 : Byte, Short, Long, Float, Double,
 * 				 Boolean, Character, Integer
 * 
 * [wrapper class 사용 이유]
 * 1. 객체지향 프로그래밍과의 호환성
 *    ==> 자바는 객체지향 프로그램이기 때문에 객체를 
 *        사용하는 것이 중요. 하지만 기본 자료형 타입은
 *        객체가 아니라 원시적인 타입이므로 객체지향 
 *        프로그램과 호환하는 부분이 부족하기 때문에
 *        기본 데이터 타입을 객체로 감싸서 사용하는 것이 좋음.
 * 2. 컬렉션 프레임워크와의 사용
 *    ==> 컬렉션 프레임워크에서는 객체만을 자료형으로 
 *        다루기 때문에 wrapper class 가 필요함.
 * 3. null 처리
 *    ==> 기본 데이터 타입은 null 값을 가질 수 없지만
 *        wrapper class 는 가질 수 있음.
 * 4. 메서드 호출 및 인자 전달
 *    ==> 메서드 호출 시에 객체를 인자로 전달하는 일이 많기
 *        때문에 기본 데이터 타입을 메서드에 전달하기
 *        위해서는 wrapper class 를 사용해야 함.
 * 5. 형변환이 자유로와짐.
 */

public class Wrapper_01 {

	public static void main(String[] args) {
		
		// 기본 자료형은 단순하게 연산을 하기 위한
		// 용도로 사용이 됨.
		int su1 = 47, su2 = 134;
		
		System.out.println("더하기 >>> " + (su1 + su2));
		
		System.out.println();
		
		// wrapper class 사용 방법
		Integer in1 = su1;   // Boxing
		
		Integer in2 = su2;   // Boxing
		
		System.out.println("포장클래스 더하기 >>> " + (in1 + in2));
		
		System.out.println();
		
		// 형변환이 자유롭다는 특징이 있음.
		System.out.println(in1.doubleValue());  // 더블 자료형으로 형변환.
		
		// 숫자 -> 문자열
		// toString() : 숫자 -> 문자열
		// String.valueOf(숫자) : 숫자 -> 문자열
		System.out.println("문자열 >>> " + (in2.toString() + 34));
		
		System.out.println("문자열 >>> " + (String.valueOf(in1) + 34));
		
		// 문자열 -> 숫자
		// 조건) 숫자문자열이어야만 문자열을 숫자로 변환할 수 있음.
		String str = "1235";
		
		System.out.println(
			"문자열 -> 숫자 >>> " + (Integer.parseInt(str) + 148));
		
		
 
	}

}
