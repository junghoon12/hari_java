package exam;

import java.util.HashMap;
import java.util.Map;

// 구현 클래스

public class ProductSearchData {

	// 상품명과 상품정보가 저장될 Map 자료 구조 선언.
	Map<String, String> map;
	
	public ProductSearchData() {
	
		map = new HashMap<String, String>();
		
		// 데이터들을 map 에 저장을 하자.
		// map에 저장 시 상품명은 키로 저장, 상품정보는 값(value)로 저장.
		map.put("세탁기", "드럼 세탁기 최신형");
		map.put("냉장고", "지펠 냉장고 최신형");
		map.put("TV", "HDTV 150인치 최신형 모델");
		
	}  // 기본 생성자
	
	
	String search(String productName) {
		
		// String productInfo = null;    // 상품에 대한 정보가 저장될 변수
		
		if(map.containsKey(productName)) {
			
			return map.get(productName);
			
		}else {
			
			return null;
		}
		
	}  // search() 메서드 end
	
	
	
	
	
	
	
}
