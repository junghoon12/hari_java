package collection;

import java.util.Stack;

/*
 * Stack 클래스(자료구조)
 * - Vector 클래스의 자식 클래스.
 * - 후입선출(LIFO : Last In First Out) 구조
 */
public class Stack_07 {

	public static void main(String[] args) {
		
		// Stack 컬렉션 객체 생성.
		Stack<Coin> coins = new Stack<Coin>();
		
		// 1. push() : stack에 데이터를 넣는 메서드.
		coins.push(new Coin(1000));
		coins.push(new Coin(500));
		coins.push(new Coin(100));
		coins.push(new Coin(10));
		
		
		// 2. peek() : stack에 저장된 데이터를 가져오는 메서드.
		//             stack의 맨 위(마지막에 저장된 데이터)에
		//             저장된 데이터를 가져오는 메서드.
		//             가져온 후 데이터를 stack에서 제거하지 않는 메서드.
		System.out.println("stack peek() >>> " + coins.peek().getCoin());
		
		System.out.println();
		
		while(!coins.isEmpty()) {
			
			/*
			 * pop() : stack에 저장된 데이터를 가져오는 메서드.
			 *         stack의 맨 위(마지막에 저장된 데이터)에
			 *         저장된 데이터를 가져오는 메서드.
			 *         가져온 후 데이터를 stack에서 제거하는 메서드.
			 */
			
			System.out.println("stack pop() >>> " + coins.pop().getCoin());
		}
		

	}

}
