package collection;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

import model.Student;

/*
 * [문제] List_05 클래스처럼 model 패키지에
 *       Student 객체를 만들고, List_06
 *       클래스의 main() 메서드에서 키보드로
 *       학생 수를 입력을 받고, 입력 받은 학생 
 *       수 만 큼의 정보를 입력받아서 ArrayList
 *       에 저장 후 화면에 출력해 보세요
 *       (학생 정보 : 학번, 이름, 학과, 연락처)
 */
public class List_06 {

	public static void main(String[] args) {
		
		Scanner sc = new Scanner(System.in);
		
		List<Student> list = new ArrayList<Student>();
		
		System.out.print("학생 수를 입력하세요. : ");
		
		int studentCount = sc.nextInt();
		
		// 1. 키보드로 입력받은 학생 수 만큼의 학생 정보를
		//    ArrayList에 저장을 하자.
		for(int i=1; i<=studentCount; i++) {
			
			System.out.println
				(i + " 번째 학생의 학번, 이름, 학과, 연락처를 입력하세요.....");
			
			Student student = new Student();
			
			// 키보드로 입력받은 학번을 setter() 메서드를 이용하여 멤버변수에 저장.
			student.setHakbun(sc.next());
			student.setName(sc.next());
			student.setMajor(sc.next());
			student.setPhone(sc.next());
			
			list.add(student);
			
			System.out.println(":::::::::::::::::::::::::::::");
			
		}
		
		System.out.println();
		
		// 2. ArrayList에 저장되어 있는 Student 객체에 접근하여
		//    학생 개개인의 정보를 화면에 출력해 보자.
		for(int i=0; i<studentCount; i++) {
			
			Student dto = list.get(i);
			
			System.out.println(dto.getHakbun()+"\t"+dto.getName()+"\t"+
					dto.getMajor()+"\t"+dto.getPhone());
			
			System.out.println("=================================");
		}
		
		sc.close();

	}

}
