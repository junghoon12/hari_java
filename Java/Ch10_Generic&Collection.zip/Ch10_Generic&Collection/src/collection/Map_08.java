package collection;

import java.util.HashMap;
import java.util.Map;
import java.util.Scanner;
import java.util.Set;

/*
 * 3. Map 컬렉션 프레임워크의 특징
 *    - key, value 를 한 쌍으로 해서 데이터를 저장하고
 *      검색하는 기능을 제공함.
 *    - key 는 중복 불가, value 는 중복 가능.
 *    - Map 인터페이스의 자식 클래스를 이용하여 구현
 *      ==> HashMap(O), HashTable(O),
 *          Properties(가끔), TreeMap(X)
 */

public class Map_08 {

	public static void main(String[] args) {
		
		// Map 인터페이스의 자식 클래스를 이용하여 객체 생성.
		Map<String, Integer> map = 
						new HashMap<String, Integer>();
		
		// 1. put(key, value) : map에 데이터를 저장하는 메서드.
		//    ==> 이름을 키로 저장, 점수를 value(값)으로 저장.
		map.put("홍길동", 88);
		map.put("세종대왕", 100);
		map.put("유관순", 93);
		map.put("이순신", 80);
		map.put("신사임당", 76);
		
		// 2. get(key) : map 에 저장된 데이터를 가져오는 메서드.
		//               get(key) 메서드를 호출을 하면 인자(key)에
		//               해당하는 value 값을 반환해 주는 메서드.
		System.out.println("세종대왕 점수 >>> " + map.get("세종대왕") + "점");
		
		System.out.println();
		
		// map 에 저장된 학생의 점수 전체를 출력해 보자.
		// keySet() : map 데이터 중에서 key만 뽑아서
		//            Set 객체로 반환시키는 메서드.
		for(String str : map.keySet()) {
			
			System.out.println(str + " 학생의 점수 >>> " + map.get(str) + "점");
		}
		
		// 검색을 한 번 해 보자.
		Scanner sc = new Scanner(System.in);
		
		System.out.print("검색할 위인의 이름을 입력하세요. : ");
		
		String searchName = sc.next();
		
		
		if(map.containsKey(searchName)) {
			
			System.out.println
				(searchName + " 위인의 점수 >>> " + map.get(searchName) + "점");
		}else {
			System.out.println("검색한 위인이 없습니다.~~~");
		}
		
		sc.close();
		

	}

}
