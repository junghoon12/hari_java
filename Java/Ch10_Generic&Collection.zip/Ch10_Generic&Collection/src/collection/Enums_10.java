package collection;

import java.util.HashMap;
import java.util.Map;

/*
 * Enums
 * - 프로그램을 개발할 때 특정 값들을 나열하면서 
 *   사용해야 하는 경우가 있음. 예를 든다면 요일을
 *   나열하거나 계절을 나열해야 하는 경우가 있을 수
 *   있음.
 * - 이런 경우는 주로 int 형의 상수로 지정하여 사용함.
 * 
 *   예)
 *   	public static final int MONDAY = 0;
 *   	public static final int THUSDAY = 1;
 *   	.....
 *   	public static final int SUNDAY = 6;
 *   
 * - 이렇게 사용하는 경우에는 많은 단점들이 발생함.
 *   데이터형이 int 형으로 정해지게 되여 확장성이 떨어짐.
 * - 또한 상수명이 중복될 위험도 있으며, 나열된 값들이
 *   순서가 뒤바뀌거나 새로운 상수 값이 추가되어야 하는
 *   경우에는 반드시 재컴파일이 발생하게 되어 유지보수가
 *   어려워짐. 
 * - 이러한 단점을 보완한 것이 enum 을 시용하는 방법임.
 * 
 *   형식)
 *   		[접근제한] enum 이름 { 값1, 값2.... 값n }
 */

public class Enums_10 {

	public enum Season { SPRING, SUMMER, FALL, WINTER }
	
	public static void main(String[] args) {
		
		Map<Season, String> map = new HashMap<Season, String>();
		
		// HashMap을 생성하고, key 값을 Season 객체 enum을 사용하자.
		map.put(Season.SPRING, "봄");
		map.put(Season.SUMMER, "여름");
		map.put(Season.FALL, "가을");
		map.put(Season.WINTER, "겨울");
		
		System.out.println(map.get(Season.SUMMER));
		
		

	}

}
