package collection;

import java.util.HashMap;
import java.util.Map;
import java.util.Scanner;

public class Map_09 {

	public static void main(String[] args) {
		
		Scanner sc = new Scanner(System.in);
		
		Map<String, Student> map = 
						new HashMap<String, Student>();
		
		System.out.print("학생 수를 입력하세요. : ");
		
		int studentCount = sc.nextInt();
		
		for(int i=1; i<=studentCount; i++) {
			
			System.out.println
				(i +" 번째 학생의 이름과 학번, 학과, 연락처를 입력하세요.....");
			
			map.put(sc.next(), new Student(sc.next(), sc.next(), sc.next()));
		}
		
		
		// 검색을 진행해 보자.
		while(true) {
			
			System.out.print("검색할 이름을 입력하세요. : ");
			
			String name = sc.next();
			
			if(name.equals("bye")) {
				break;
			}
			
			Student student = map.get(name);
			
			if(student == null) {
				
				System.out.println(name + " 은 없는 학생입니다.");
				
			}else {
				
				System.out.println("학 번 : "+student.getHakbun()+" / 학 과 : "+
						 student.getMajor() + " / 연락처 : "+student.getPhone());
				
				System.out.println();
				
			}
			
		}  // while 문 end
			
		System.out.println("수고 많이 하셨습니다.");
		
		sc.close();

	}

}
