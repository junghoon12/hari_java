package collection;

public class Student {

	// 멤버변수
	private String hakbun;
	private String major;
	private String phone;
	
	public Student() { }  // 기본 생성자
	
	public Student(String hakbun,
			String major, String phone) {
		
		this.hakbun = hakbun;
		this.major = major;
		this.phone = phone;
		
	}  // 인자 생성자

	
	public String getHakbun() {
		return hakbun;
	}

	public void setHakbun(String hakbun) {
		this.hakbun = hakbun;
	}

	public String getMajor() {
		return major;
	}

	public void setMajor(String major) {
		this.major = major;
	}

	public String getPhone() {
		return phone;
	}

	public void setPhone(String phone) {
		this.phone = phone;
	}
	
	
	
}
