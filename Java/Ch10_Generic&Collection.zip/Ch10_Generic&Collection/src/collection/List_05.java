package collection;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

import model.Member;

public class List_05 {

	public static void main(String[] args) {
		
		Scanner sc = new Scanner(System.in);
		
		System.out.print("회원 수를 입력하세요. : ");
		
		int memberCount = sc.nextInt();
		
		// 이 리스트에는 Member 타입의 객체만 저장할 수 있다는 의미임.
		List<Member> list = new ArrayList<Member>();
		
		sc.nextLine();
		
		// 1. 키보드로 회원 수만큼 반복하여 회원 정보를 키보드로 
		//    입력을 받아서 ArrayList에 저장을 하자.
		for(int i = 0; i < memberCount; i++) {
			
			System.out.println
				((i+1) + " 번째 회원의 아이디, 비밀번호, 이름, 나이, 연락처, 주소를 입력하세요...");
			
			Member member = new Member(sc.nextLine(), sc.nextLine(), sc.nextLine(), 
								sc.nextLine(), sc.nextLine(), sc.nextLine());
			
			list.add(member);
			
		}
		
		
		// 2. 회원 정보를 ArrayList에서 가져와서 화면에 출력해 보자.
		for(int i = 0; i < memberCount; i++) {
			
			Member addr = list.get(i);
			
			System.out.println(addr.getId()+"\t"+addr.getPwd()+"\t"+addr.getName()
				+"\t"+addr.getAge()+"\t"+addr.getPhone()+"\t"+addr.getAddr());
			
			System.out.println("::::::::::::::::::::::::::::::::::::::::::::::::::::");
		}
		
		sc.close();
		
		
		
	}

}
