package model;

public class Student {

	// 멤버변수
	private String hakbun;
	private String name;
	private String major;
	private String phone;
	
	public Student() { }  // 기본 생성자
	
	public Student(String hakbun, String name,
			String major, String phone) {
		
		this.hakbun = hakbun;
		this.name = name;
		this.major = major;
		this.phone = phone;
		
	}  // 인자 생성자

	
	public String getHakbun() {
		return hakbun;
	}

	public void setHakbun(String hakbun) {
		this.hakbun = hakbun;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getMajor() {
		return major;
	}

	public void setMajor(String major) {
		this.major = major;
	}

	public String getPhone() {
		return phone;
	}

	public void setPhone(String phone) {
		this.phone = phone;
	}
	
	
	
}
