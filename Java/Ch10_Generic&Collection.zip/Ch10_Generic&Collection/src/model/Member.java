package model;

public class Member {

	// 멤버변수
	private String id;
	private String pwd;
	private String name;
	private String age;
	private String phone;
	
	public Member() { }  // 기본 생성자

	public Member(String id, String pwd,
			String name, String age, String phone) {
		
		this.id = id;
		this.pwd = pwd;
		this.name = name;
		this.age = age;
		this.phone = phone;
		
	}  // 인자 생성자

	
	public void setId(String id) {
		this.id = id;
	}

	public void setPwd(String pwd) {
		this.pwd = pwd;
	}

	public void setName(String name) {
		this.name = name;
	}

	public void setAge(String age) {
		this.age = age;
	}

	public void setPhone(String phone) {
		this.phone = phone;
	}

	public String getId() {
		return id;
	}

	public String getPwd() {
		return pwd;
	}

	public String getName() {
		return name;
	}

	public String getAge() {
		return age;
	}

	public String getPhone() {
		return phone;
	}
	
	
	
	
}
