package generic;

public class Goods_01 {

	public static void main(String[] args) {
		
		Goods1 goods1 = new Goods1();
		
		// Goods1 객체에는 Apple 객체 타입만 입력이 가능.
		// Apple apple = new Apple();
		
		goods1.setApple(new Apple());
		
		Apple apple = goods1.getApple();
		
		apple.output();
		
		System.out.println();
		
		
		Goods2 goods2 = new Goods2();
		
		goods2.setPencil(new Pencil());
		
		Pencil pencil = goods2.getPencil();
		
		pencil.output();
		
	}

}
