package generic;

public class Generic_03 {

	public static void main(String[] args) {
		
		// String 타입의 클래스 객체 생성.
		Generic<String> st = new Generic<String>();
		
		String[] str = {"홍길동", "이순신", "유관순"};
		
		String var = "김연아";
		
		st.setStr(str);
		
		st.setVar(var);
		
		st.output();
		
		System.out.println();
		
		// Integer 타입의 클래스 객체 생성.
		Generic<Integer> it = new Generic<Integer>();
		
		Integer[] iarr = {10, 20, 30};
		
		Integer ivar = 500;
		
		it.setStr(iarr);
		
		it.setVar(ivar);
		
		it.output();
		
	}

}
