package generic;

public class IntegerType {

	Integer[] arr;
	Integer ivar;
	
	void setArr(Integer[] arr) {
		
		this.arr = arr;
	}
	
	void setVar(Integer ivar) {
		
		this.ivar = ivar;
	}
	
	
	void output() {
		
		for(Integer k : arr) {
			
			System.out.println("iarr 배열 요소 >>> " + k);
		}
		
		System.out.println("ivar >>> " + ivar);
	}
	
	
}
