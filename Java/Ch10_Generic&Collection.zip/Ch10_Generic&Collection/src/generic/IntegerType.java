package generic;

public class IntegerType {

	Integer[] iarr;
	Integer ivar;    // 237
	
	void setArr(Integer[] iarr) {
		
		this.iarr = iarr;
	}
	
	void setVar(Integer ivar) {
		
		this.ivar = ivar;
	}
	
	void output() {
		
		for(Integer i : iarr) {
			
			System.out.println("iarr 배열 요소 >>> " + i);
		}
		
		System.out.println("ivar >>> " + ivar);
	}
	
}



