package com.spring.data;



import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.client.RestTemplate;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.ObjectMapper;


@Controller
public class HomeController {
	
	private static final Logger logger = LoggerFactory.getLogger(HomeController.class);
	
	
	@RequestMapping(value = "/", method = RequestMethod.GET)
	public String home() {
			
		return "home";
	}
	
	@RequestMapping(value = "/crawl.go", method = RequestMethod.GET,
			produces = "application/json; charset=UTF-8")
	public String crawlData(@RequestParam("key") String key, Model model) throws JsonMappingException, JsonProcessingException {
		
		String client_id = "4fTJyLSUQiLTaVMhl1ck";
		String client_secret = "ShpSMm0uPQ";
		
		String apiUrl = "https://openapi.naver.com/v1/search/shop.json?query=" + key;
		
		/*
		 * - HTTP 요청을 할 때 보내는 데이터(body)를 설명해 주는
		 *   헤더(header)도 만들어서 같이 보내주어야 할 때 사용하는 클래스임.
		 * - Spring Framework에서 제공해 주는 HttpHeaders 클래스는
		 *   Header를 만들어 줌.
		 * - add() 메서드를 이용하여 Header에 들어갈 내용을 추가해 주면 됨.
		 */
		HttpHeaders headers = new HttpHeaders();
		headers.add("X-Naver-Client-Id", client_id);
		headers.add("X-Naver-Client-Secret", client_secret);
		
		// 요청하기 위해서는 헤더(header)와 데이터(body)를 합치는 작업이 필요함.
		// Spring Framework에서 제공해 주는 HttpEntity 클래스가 
		// Header와 Body를 합쳐주는 클래스임.
		HttpEntity<String> entity = new HttpEntity<String>("", headers);
		
		/* - RestTemplate 클래스를 사용하여 API 요청을 보내고 응답을 받게 됨.
		 * - 보낼 때는 exchange() 메서드를 이용하면 됨.
		 * - exchange() 메서드에 들어갈 인자.
		 *   * 첫번째 인자 : url 경로
		 *   * 두번째 인자 : 메서드 방식(GET or POST)
		 *   * 세번째 인자 : 통신할 데이터(HttpEntity 클래스)
		 *   * 네번째 인자 : 반환 타입(반환클래스.class)
		*/
		ResponseEntity<String> response = 
				new RestTemplate().exchange(apiUrl, HttpMethod.GET, entity, String.class);
		
		/*
		 * ObjectMapper 객체
		 * - JSON 응답 데이터를 Response 객체로 변환 작업을 해야 함.
		 * - JSON 컨텐츠를 Java 객체로 deserialization(역직렬화) 하거나
		 *   Java 객체를 JSON으로 serialization(직렬화) 할 때 사용하는
		 *   Jackson 라이브러리의 클래스임.
		 * - JSON 파일을 Java 객체로 deserialization(역직렬화) 하기 위해서는
		 *   ObjectMapper 객체의 readValue() 메서드를 이용하면 됨.
		 * - readValue() 메서드의 인자
		 *   * 첫번째 인자 : JSON 데이터(데이터.getBody())
		 *   * 두번째 인자 : 반환 클래스 타입(반환 클래스.class) 
		 */
		
		ObjectMapper mapper = new ObjectMapper();
		Response responseData = mapper.readValue(response.getBody(), Response.class);
		
		// model에 responseData를 바인디이시켜서 view page로 이동.
		model.addAttribute("response", responseData);
		
		return "crawl_list";
	}
	
}




