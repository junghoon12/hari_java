package com.spring.data;

import java.util.List;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import lombok.Data;

/*
 * @JsonIgnoreProperties(ignoreUnknown = true)
 * - 개발을 진행하다 보면 메세지를 받거나, 외부 API 응답을 받아올 때
 *   객체가 String 형태로 변환되어 해당 형태를 다시 객체로 만들 필요가 있음.
 *   만약, 이 때 받아오는 필드들이 100개라고 할 때, 내가 여기서는 단 5개의
 *   데이터만 관심이 있는 경우가 종종 있을 수 있음.
 * - 해당 애노테이션은 JSON 프로퍼티의 직렬화 / 역직렬화를 수행할 때 사용되고
 *   프로퍼티의 처리를 무시하는데 사용이 됨.
 * - 해당 애노테이션의 ignoreUnknown 속성의 기본값은 false임.
 *   즉, 모든 프로퍼티를 무시하지 않고 기재하도록 정의되어 있음.
 * - 만약 ignoreUnknown 필드의 값을 true로 설정해 주면 예외나 경고 없이
 *   모든 프로퍼티를 무시해도 되어 내가 관심이 있는 데이터만 사용할 수 있음.
 *   즉, true 값을 주면 JSON 파싱 시 없는 필드는 무시해도 된다는 애노테이션.
 */


@Data
@JsonIgnoreProperties(ignoreUnknown = true)
public class Response {

	private List<Item> items;
}
