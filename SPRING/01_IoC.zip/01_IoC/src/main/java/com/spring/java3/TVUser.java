package com.spring.java3;

import org.springframework.context.support.AbstractApplicationContext;
import org.springframework.context.support.GenericXmlApplicationContext;

public class TVUser {

	public static void main(String[] args) {
		
		// 현재 코드의 개념이 IoC 개념임.
		// 스프링 컨테이너를 생성을 하자.
		GenericXmlApplicationContext container =
				new GenericXmlApplicationContext("applicationContext.xml");
		
		
		// 컨테이너로부터 객체를 검색(Lookup)한다.
		TV tv = (TV)container.getBean("tv");
		
		tv.turnOn();       // 전원을 켜는 메서드 호출
		
		tv.soundUp();      // 볼륨을 올리는 메서드 호출
		
		tv.soundDown();    // 볼륨을 내리는 메서드 호출
		
		tv.turnOff();      // 전원을 끄는 메서드 호출

	}

}
