package com.spring.java2;

public class TVUser {

	public static void main(String[] args) {
		
		TV tv = new LgTV();
		
		tv.turnOn();       // 전원을 켜는 메서드 호출
		
		tv.soundUp();      // 볼륨을 올리는 메서드 호출
		
		tv.soundDown();    // 볼륨을 내리는 메서드 호출
		
		tv.turnOff();      // 전원을 끄는 메서드 호출

	}

}
