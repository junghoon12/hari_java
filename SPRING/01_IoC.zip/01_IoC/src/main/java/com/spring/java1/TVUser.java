package com.spring.java1;

public class TVUser {

	public static void main(String[] args) {
		
		SamsungTV tv = new SamsungTV();
		
		tv.turnOn();       // 전원을 켜는 메서드 호출
		
		tv.soundUp();      // 볼륨을 올리는 메서드 호출
		
		tv.soundDown();    // 볼륨을 내리는 메서드 호출
		
		tv.turnOff();      // 전원을 끄는 메서드 호출

	}

}
