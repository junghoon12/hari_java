package com.spring.java3;

public interface TV {

	void turnOn();

	void turnOff();

	void soundUp();

	void soundDown();

}