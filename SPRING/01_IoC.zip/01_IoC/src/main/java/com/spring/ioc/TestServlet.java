package com.spring.ioc;

/*
 * POJO(Plain Old Java Object : 평범한 옛날 자바 객체)
 * - 클래스를 작성하는데 특별한 규칙이나 제약이 없다.
 * - 일반적으로 부모가 없거나 부모 클래스를 마음대로 변경할 수 있다.
 * - 메모리 사용량도 적다. 
 */


public class TestServlet {
	
	protected void 내맘대로() {
		
		System.out.println("--> 내맘대로() 메서드 호출");
	}

}
