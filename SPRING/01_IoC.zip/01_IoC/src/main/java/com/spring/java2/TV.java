package com.spring.java2;

public interface TV {

	void turnOn();

	void turnOff();

	void soundUp();

	void soundDown();

}