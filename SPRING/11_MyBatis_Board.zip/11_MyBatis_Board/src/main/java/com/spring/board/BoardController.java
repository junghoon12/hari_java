package com.spring.board;

import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;

import com.spring.model.BoardDAO;
import com.spring.model.BoardVO;
import com.spring.model.PageVO;

@Controller
public class BoardController {

	@Autowired
	private BoardDAO dao;
	
	// 한 페이지당 보여질 게시물의 수
	private final int rowsize = 3;
	
	// DB 상의 전체 게시물의 수
	private int totalRecord = 0;
	
	@RequestMapping("board_list.go")
	public String list(HttpServletRequest request,
					Model model) {
		
		int page;     // 현재 페이지 변수
		
		// 페이징 처리 작업
		if(request.getParameter("page") != null) {
			page = Integer.parseInt(request.getParameter("page"));
		}else {
			// 처음으로 "게시물 전체 목록" 글자를 클릭한 경우
			page = 1;
		}
		
		// DB 상의 전체 게시물의 수를 확인하는 메서드 호출
		totalRecord = this.dao.getListCount();
		
		PageVO vo = new PageVO(page, rowsize, totalRecord);
		
		// 현재 페이지에 해당하는 게시물을 가져오는 메서드 호출.
		List<BoardVO> boardList = this.dao.getBoardList(vo);
		
		model.addAttribute("List", boardList)
		     .addAttribute("Paging", vo);
		
		return "board_list";
		
	}
	
}
