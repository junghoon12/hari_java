package com.spring.board;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.spring.model.BoardDAO;
import com.spring.model.BoardVO;
import com.spring.model.PageVO;

@Controller
public class BoardController {

	@Autowired
	private BoardDAO dao;
	
	// 한 페이지당 보여질 게시물의 수
	private final int rowsize = 3;
	
	// DB 상의 전체 게시물의 수
	private int totalRecord = 0;
	
	@RequestMapping("board_list.go")
	public String list(HttpServletRequest request,
					Model model) {
		
		int page;     // 현재 페이지 변수
		
		// 페이징 처리 작업
		if(request.getParameter("page") != null) {
			page = Integer.parseInt(request.getParameter("page"));
		}else {
			// 처음으로 "게시물 전체 목록" 글자를 클릭한 경우
			page = 1;
		}
		
		// DB 상의 전체 게시물의 수를 확인하는 메서드 호출
		totalRecord = this.dao.getListCount();
		
		PageVO vo = new PageVO(page, rowsize, totalRecord);
		
		// 현재 페이지에 해당하는 게시물을 가져오는 메서드 호출.
		List<BoardVO> boardList = this.dao.getBoardList(vo);
		
		model.addAttribute("List", boardList)
		     .addAttribute("Paging", vo);
		
		return "board_list";
		
	}
	
	
	@RequestMapping("board_write.go")
	public String write() {
		
		return "board_write";
	}
	
	
	@RequestMapping("board_write_ok.go")
	public void writeOk(BoardVO vo,
			HttpServletResponse response) throws IOException {

		int chk = this.dao.insertBoard(vo);
		
		response.setContentType("text/html; charset=UTF-8");
		
		PrintWriter out = response.getWriter();
		
		if(chk > 0) {
			out.println("<script>");
			out.println("alert('게시글 등록 성공!!!')");
			out.println("location.href='board_list.go'");
			out.println("</script>");
		}else {
			out.println("<script>");
			out.println("alert('게시글 등록 실패~~~')");
			out.println("history.back()");
			out.println("</script>");
		}
	}
	
	
	@RequestMapping("board_content.go")
	public String cont(@RequestParam("no") int no,
			@RequestParam("page") int nowPage, Model model) {
		
		// 조회 수를 증가 시켜주는 메서드 호출
		this.dao.readCount(no);
		
		// 게시글 번호에 해당하는 게시글의 상세 내역을
		// 조회하는 메서드 호출
		BoardVO vo = this.dao.boardContent(no);
		
		model.addAttribute("Content", vo)
			 .addAttribute("Paging", nowPage);
		
		return "board_content";
	}
	
	
	@RequestMapping("board_modify.go")
	public String modify(@RequestParam("no") int no,
			@RequestParam("page") int nowPage, Model model) {
		
		// 게시글 번호에 해당하는 게시글의 상세 내역을
		// 조회하는 메서드 호출
		BoardVO vo = this.dao.boardContent(no);
		
		model.addAttribute("Modify", vo)
			 .addAttribute("Page", nowPage);
		
		return "board_modify";
	}
	
	
	@RequestMapping("board_modify_ok.go")
	public void modifyOk(BoardVO vo,
			@RequestParam("db_pwd") String db_pwd,
			@RequestParam("page") int nowPage,
			HttpServletResponse response) throws IOException {
		
		response.setContentType("text/html; charset=UTF-8");
		
		PrintWriter out = response.getWriter();
		
		if(vo.getBoard_pwd().equals(db_pwd)) {
			
			int chk = this.dao.updateBoard(vo);
			
			if(chk > 0) {
				out.println("<script>");
				out.println("alert('게시글 수정 성공!!!')");
				out.println("location.href='board_content.go?no="+vo.getBoard_no()+"&page="+nowPage+"'");
				out.println("</script>");
			}else {
				out.println("<script>");
				out.println("alert('게시글 수정 실패~~~')");
				out.println("history.back()");
				out.println("</script>");
			}
		}else {
			// 비밀번호가 틀린 경우
			out.println("<script>");
			out.println("alert('비밀번호가 틀립니다. 확인해 주세요~~~')");
			out.println("history.back()");
			out.println("</script>");
		}
		
	}
	
	
	@RequestMapping("board_delete.go")
	public String delete(@RequestParam("no") int no,
			@RequestParam("page") int nowPage, Model model) {
		
		BoardVO vo = this.dao.boardContent(no);
		
		model.addAttribute("Delete", vo)
			 .addAttribute("Page", nowPage);
		
		return "board_delete";
	}
	
	
	@RequestMapping("board_delete_ok.go")
	public void deleteOk(BoardVO vo,
			@RequestParam("db_pwd") String db_pwd,
			@RequestParam("page") int nowPage,
			HttpServletResponse response) throws IOException {
		
		response.setContentType("text/html; charset=UTF-8");
		
		PrintWriter out = response.getWriter();
		
		if(db_pwd.equals(vo.getBoard_pwd())) {
			
			int res = this.dao.deleteBoard(vo.getBoard_no());
			
			if(res > 0) {
				
				this.dao.updateSequence(vo.getBoard_no());
				
				out.println("<script>");
				out.println("alert('게시글 삭제 성공!!!')");
				out.println("location.href='board_list.go?page="+nowPage+"'");
				out.println("</script>");
				
			}else {
				out.println("<script>");
				out.println("alert('게시글 삭제 실패~~~')");
				out.println("history.back()");
				out.println("</script>");
			}
		}else {
			// 비밀번호가 틀린 경우
			out.println("<script>");
			out.println("alert('비밀번호가 틀립니다. 확인 요망~~~')");
			out.println("history.back()");
			out.println("</script>");
		}
		
	}
	
	
	@RequestMapping("board_search.go")
	public String search(@RequestParam("field") String field,
			@RequestParam("keyword") String keyword, 
			HttpServletRequest request, Model model) {
		
		// 검색 결과를 페이징 처리 작업
		int page;             // 현재 페이지 변수
		
		if(request.getParameter("page") != null) {
			page = Integer.parseInt(request.getParameter("page"));
		}else {
			// "검색" 버튼을 클릭한 경우 - 검색 요청을 한 경우
			page = 1;
		}
		
		// 검색 분류(field)와 검색어(keyword)에 해당하는
		// 게시글의 수를 DB에서 확인하는 작업.
		Map<String, String> map = 
						new HashMap<String, String>();
		
		map.put("Field", field);
		map.put("Keyword", keyword);
		
		totalRecord = this.dao.searchBoardCount(map);
		
		PageVO pVo = 
			new PageVO(page, rowsize, totalRecord, field, keyword);
		
		// 검색 시 한 페이지당 보여질 게시물의 수만큼
		// 검색한 게시물을 List로 가져오는 메서드 호출.
		List<BoardVO> searchList = this.dao.searchBoardList(pVo);
		
		model.addAttribute("SearchPageList", searchList)
			 .addAttribute("Paging", pVo);
		
		return "board_search_list";	
		
	}
	
	
	@RequestMapping("board_search_cont.go")
	public String searchCont(Model model,
			@RequestParam("no") int no,
			@RequestParam("page") int nowPage,
			@RequestParam("field") String field,
			@RequestParam("keyword") String keyword) {
		
		// 조회 수 증가시켜 주는 메서드 호출.
		this.dao.readCount(no);
		
		// 게시글 번호에 해당하는 게시글을 조회하는 메서드 호출.
		BoardVO searchCont = this.dao.boardContent(no);
		
		model.addAttribute("sCont", searchCont)
			 .addAttribute("Page", nowPage)
			 .addAttribute("Field", field)
			 .addAttribute("Keyword", keyword);
		
		return "board_search_cont";
		
	}
	
	
}
