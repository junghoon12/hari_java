package com.spring.model;

import java.util.List;
import java.util.Map;

import org.mybatis.spring.SqlSessionTemplate;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

@Repository
public class BoardDAOImpl implements BoardDAO {

	
	@Autowired
	private SqlSessionTemplate sqlSession;
	
	
	
	@Override
	public int getListCount() {
		
		return this.sqlSession.selectOne("cnt");
	}

	@Override
	public List<BoardVO> getBoardList(PageVO vo) {
		
		return this.sqlSession.selectList("list", vo);
	}

	@Override
	public int insertBoard(BoardVO vo) {
		
		return this.sqlSession.insert("add", vo);
	}

	@Override
	public void readCount(int no) {
		
		this.sqlSession.update("read", no);
		
	}

	@Override
	public BoardVO boardContent(int no) {
		
		return this.sqlSession.selectOne("cont", no);
	}

	@Override
	public int updateBoard(BoardVO vo) {
		
		return this.sqlSession.update("modify", vo);
	}

	@Override
	public int deleteBoard(int no) {
		
		return this.sqlSession.delete("del", no);
	}

	@Override
	public void updateSequence(int no) {
		
		this.sqlSession.update("seq", no);
	}

	@Override
	public int searchBoardCount(Map<String, String> map) {
		
		return this.sqlSession.selectOne("count", map);
	}

	@Override
	public List<BoardVO> searchBoardList(PageVO vo) {
		
		return this.sqlSession.selectList("search", vo);
	}

}
