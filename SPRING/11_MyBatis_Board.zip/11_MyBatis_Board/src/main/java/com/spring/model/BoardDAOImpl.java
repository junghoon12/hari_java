package com.spring.model;

import java.util.List;
import java.util.Map;

import org.mybatis.spring.SqlSessionTemplate;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

@Repository
public class BoardDAOImpl implements BoardDAO {

	
	@Autowired
	private SqlSessionTemplate sqlSession;
	
	
	
	@Override
	public int getListCount() {
		
		return this.sqlSession.selectOne("cnt");
	}

	@Override
	public List<BoardVO> getBoardList(PageVO vo) {
		
		return this.sqlSession.selectList("list", vo);
	}

	@Override
	public int insertBoard(BoardVO vo) {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public void readCount(int no) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public BoardVO boardContent(int no) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public int updateBoard(BoardVO vo) {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public int deleteBoard(int no) {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public void updateSequence(int no) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public int searchBoardCount(Map<String, String> map) {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public List<BoardVO> searchBoardList(PageVO vo) {
		// TODO Auto-generated method stub
		return null;
	}

}
