package com.spring.mvc03;

import lombok.Data;

@Data
public class Member {
	
	private String id;
	private String name;
	private String pwd;
	private int age;
	private String phone;
	private String email;
	private String addr;

}
