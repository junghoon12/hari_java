package com.spring.jdbc01;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;

import javax.inject.Inject;
import javax.servlet.http.HttpServletResponse;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.spring.model.Member;
import com.spring.model.MemberDAO;

@Controller
public class MemberController {

	@Inject
	private MemberDAO dao;
	
	@RequestMapping("/member_list.go")
	public String list(Model model) {
		
		List<Member> list = this.dao.getMemberList();
		
		model.addAttribute("memberList", list);
		
		return "/member/member_list";
	}
	
	
	@RequestMapping("member_insert.go")
	public String in() {
		
		return "/member/member_insert";
	}
	
	
	@RequestMapping("member_insert_ok.go")
	public void ok(Member dto,
			HttpServletResponse response) throws IOException {
		
		int check = this.dao.insertMember(dto);
		
		response.setContentType("text/html; charset=UTF-8");
		
		PrintWriter out = response.getWriter();
		
		if(check > 0) {
			out.println("<script>");
			out.println("alert('회원 등록 성공!!!')");
			out.println("location.href='member_list.go'");
			out.println("</script>");
		}else {
			out.println("<script>");
			out.println("alert('회원 등록 실패~~~')");
			out.println("history.back()");
			out.println("</script>");
		}
		
	}
	
	
	@RequestMapping("member_content.go")
	public String cont(@RequestParam("num") int no, Model model) {
		
		// 회원의 상세 정보를 조회하는 메서드 호출
		Member cont = this.dao.getMember(no);
		
		model.addAttribute("Content", cont);
		
		return "/member/member_content";
		
	}
	
	
	@RequestMapping("member_modify.go")
	public String modify(@RequestParam("num") int no, Model model) {
		
		Member cont = this.dao.getMember(no);
		
		model.addAttribute("Modify", cont);
		
		return "/member/member_modify";
		
	}
	
	
	@RequestMapping("member_modify_ok.go")
	public void ok2(Member dto,
				HttpServletResponse response) throws IOException {
	
		int check = this.dao.updateMember(dto);
		
		response.setContentType("text/html; charset=UTF-8");
		
		PrintWriter out = response.getWriter();
		
		if(check > 0) {
			out.println("<script>");
			out.println("alert('회원 수정 성공!!!')");
			out.println("location.href='member_content.go?num="+dto.getNum()+"'");
			out.println("</script>");
		}else if(check == -1) {
			out.println("<script>");
			out.println("alert('비밀번호가 틀립니다. 확인해 주세요.~~~')");
			out.println("history.back()");
			out.println("</script>");
		}else {
			out.println("<script>");
			out.println("alert('회원 수정 실패~~~')");
			out.println("history.back()");
			out.println("</script>");
		}
		
	}
	
	
	@RequestMapping("member_delete.go")
	public void delete(@RequestParam("num") int no,
				HttpServletResponse response) throws IOException {
		
		int check = this.dao.deleteMember(no);
		
		response.setContentType("text/html; charset=UTF-8");
		
		PrintWriter out = response.getWriter();
		
		if(check > 0) {
			
			// 삭제 시 회원번호 재작업 하는 메서드 호출
			this.dao.updateSequence(no);
			
			out.println("<script>");
			out.println("alert('회원 삭제 성공!!!')");
			out.println("location.href='member_list.go'");
			out.println("</script>");
		}else {
			out.println("<script>");
			out.println("alert('회원 삭제 실패~~~')");
			out.println("history.back()");
			out.println("</script>");
		}
	}
	
	
	
	
	
}







