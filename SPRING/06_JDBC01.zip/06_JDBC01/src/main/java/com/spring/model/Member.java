package com.spring.model;

import lombok.Data;

@Data
public class Member {

	private int num;
	private String memid;
	private String memname;
	private String pwd;
	private int age;
	private int mileage;
	private String job;
	private String addr;
	private String regdate;
	
}
