package com.spring.injection;

public interface TV {

	void turnOn();

	void turnOff();

	void soundUp();

	void soundDown();

}