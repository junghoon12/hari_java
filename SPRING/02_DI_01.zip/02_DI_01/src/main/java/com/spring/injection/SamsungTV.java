package com.spring.injection;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

/*
 * IoC(Inversion Of Control : 제어의 역전 - 역제어 반대말 순제어)
 * - 제어 : 객체(Object) 에 대한 제어를 말함.
 * - 제어 : Object에서 제어는 두 가지로 나누임.
 *         - 객체에 대한 생성(new 키워드)
 *         - 객체와 객체 간의 의존 관계
 */

@Component("tv")
public class SamsungTV implements TV {

	@Autowired    // Type Injection
	// Speaker speaker = new Sonyspeaker(); 
	// Speaker speaker = new Applespeaker(); 
	private Speaker speaker;
	private int price;
	
	
	public SamsungTV() {
		
		System.out.println("==> SamsungTV(1) 생성");
	}  // 기본 생성자
	
	
	public SamsungTV(Speaker speaker) {
		System.out.println("==> SamsungTV(2) 생성");
		this.speaker = speaker;
	}  // 인자 생성자

	
	public SamsungTV(Speaker speaker, int price) {
		System.out.println("==> SamsungTV(3) 생성");
		this.speaker = speaker;
		this.price = price;
	}  // 인자 생성자
	
	
	public void setSpeaker(Speaker speaker) {
		System.out.println("---> setSpeaker() 메서드 호출");
		this.speaker = speaker;
	}


	public void setPrice(int price) {
		System.out.println("---> setPrice() 메서드 호출");
		this.price = price;
	}


	@Override
	public void turnOn() {
		System.out.println("SamsungTV --> 전원 켜기 " + price);
	}
	
	@Override
	public void turnOff() {
		System.out.println("SamsungTV --> 전원 끄기");
	}
	
	@Override
	public void soundUp() {
		// System.out.println("SamsungTV --> 소리 올리기");
		speaker.volumeUp();
	}
	
	@Override
	public void soundDown() {
		// System.out.println("SamsungTV --> 소리 내리기");
		speaker.volumeDown();
	}
}
