package com.spring.collection;

import java.util.List;
import java.util.Map;
import java.util.Set;

import org.springframework.context.support.GenericXmlApplicationContext;

public class CollectionUser {

	public static void main(String[] args) {
		
		// 스프링 컨테이너를 구동을 하자.
		GenericXmlApplicationContext container =
				new GenericXmlApplicationContext("applicationContext.xml");
		
		// 컨테이너로부터 사용할 객체를 lookup 하자.
		CollectionBean bean = (CollectionBean)container.getBean("collection");
		
		Map<String, Integer> addressList = bean.getAddressList();
		
		for(String str : addressList.keySet()) {
			
			System.out.println(str + " 점수 : " + addressList.get(str));
		}
		
		System.out.println();
		
		// 컨테이너를 종료해 주자.
		container.close();

	}

}
