package com.spring.collection;

import java.util.Map;
import java.util.Set;

public class CollectionBean {

	
	private Map<String, Integer> addressList;

	
	public Map<String, Integer> getAddressList() {
		return addressList;
	}

	
	public void setAddressList(Map<String, Integer> addressList) {
		this.addressList = addressList;
	}
	
	
}
