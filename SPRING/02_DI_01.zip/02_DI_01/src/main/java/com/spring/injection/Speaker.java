package com.spring.injection;

public interface Speaker {

	void volumeUp();

	void volumeDown();

}