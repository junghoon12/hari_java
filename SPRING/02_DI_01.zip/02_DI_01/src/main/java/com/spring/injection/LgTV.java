package com.spring.injection;

/*
 * IoC(Inversion Of Control : 제어의 역전 - 역제어 반대말 순제어)
 * - 제어 : 객체(Object) 에 대한 제어를 말함.
 * - 제어 : Object에서 제어는 두 가지로 나누임.
 *         - 객체에 대한 생성(new 키워드)
 *         - 객체와 객체 간의 의존 관계
 */

public class LgTV implements TV {

	public LgTV() {
		
		System.out.println("==> LgTV 생성");
	}  // 기본 생성자
	
	public void turnOn() {
		System.out.println("LgTV --> 전원 켜기");
	}
	
	public void turnOff() {
		System.out.println("LgTV --> 전원 끄기");
	}
	
	public void soundUp() {
		System.out.println("LgTV --> 소리 올리기");
	}
	
	public void soundDown() {
		System.out.println("LgTV --> 소리 내리기");
	}
}
