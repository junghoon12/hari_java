package com.spring.injection;

import org.springframework.context.support.GenericXmlApplicationContext;

/*
 * 스프링 컨테이너
 * - 컨테이너를 이용해서 애플리케이션 운영에 필요한 객체 생성을 
 *   스프링 컨테이너를 통해서 생성하는 것을 역제어(IoC) 라고 함.
 *   스프링 컨테이너는 classpath 상에 xml 파일을 로딩해서
 *   xml을 기반으로 xml 파일에 등록된 클래스의 객체를 메모리에
 *   띄우고, 클라이언트는 컨테이너로부터 id가 tv이면서 동시에
 *   tv 타입의 객체를 컨테이너로부터 lookup 검색을 통해서 얻어낸
 *   후에 lookup된 객체의 메서드를 이용해서 원하는 로직을 실행하는
 *   것을 말함. 이것이 스프링의 IoC 개념임.
 * - 그래서 컨테이너를 내가 만드는 것이 아니라 스프링이 제공하는
 *   컨테이너를 이용하면 xml 만 수정하면 되기 때문에 유지보수
 *   과정에서 자바 소스를 아무 것도 건드리지 않고 실행되는 객체를
 *   변경할 수 있음.
 */

public class TVUser {

	public static void main(String[] args) {
		
		// 현재 코드의 개념이 IoC 개념임.
		// 스프링 컨테이너를 생성을 하자.
		GenericXmlApplicationContext container =
				new GenericXmlApplicationContext("applicationContext.xml");
		
		
		// 컨테이너로부터 객체를 검색(Lookup)한다.
		TV tv = (TV)container.getBean("tv");
		
		tv.turnOn();       // 전원을 켜는 메서드 호출
		
		tv.soundUp();      // 볼륨을 올리는 메서드 호출
		
		tv.soundDown();    // 볼륨을 내리는 메서드 호출
		
		tv.turnOff();      // 전원을 끄는 메서드 호출
		
		// 컨테이너를 종료를 하면 컨테이너가 관리하는 모든 객체가 사라짐.
		container.close();

	}

}
