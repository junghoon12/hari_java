package com.nonspring.goott3;

public class MessageEN implements Message {

	@Override
	public void printMsg() {
		
		System.out.println("Hello, Spring");
		
	}

	
}
