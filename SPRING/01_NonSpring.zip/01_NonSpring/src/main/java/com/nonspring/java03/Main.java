package com.nonspring.java03;

public class Main {

	public static void main(String[] args) {
		
		// 1. 인자 생성자를 이용하여 객체를 주입.
		MessageImpl impl = 
				new MessageImpl(new MessageKr());
		
		impl.msg();
		
		// 2. setter() 메서드를 이용하여 주입.
		MessageImpl impl2 = new MessageImpl();
		
		impl2.setMessage(new MessageEn());
		
		impl2.msg();
		

	}

}
