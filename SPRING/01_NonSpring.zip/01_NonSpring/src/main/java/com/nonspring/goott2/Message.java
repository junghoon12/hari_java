package com.nonspring.goott2;

public interface Message {

	void printMsg();   // 추상 메서드
	
}
