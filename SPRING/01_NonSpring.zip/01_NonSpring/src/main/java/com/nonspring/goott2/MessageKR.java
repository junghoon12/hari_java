package com.nonspring.goott2;

public class MessageKR implements Message {

	@Override
	public void printMsg() {
		
		System.out.println("방가방가~~ 스프링!!!");
		
	}

	
}
