package com.nonspring.goott;

public class MessageEN {

	void printMsg() {
		
		System.out.println("Hello, Spring!!!");
	}
	
}
