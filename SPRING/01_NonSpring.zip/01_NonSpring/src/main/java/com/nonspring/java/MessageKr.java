package com.nonspring.java;

public class MessageKr {

	void printMsg() {
		
		System.out.println("안녕하세요!!!");
		
	}
}
