package com.nonspring.java;

public class MessageEn {

	void printMsg() {
		
		System.out.println("Hello");
	}
}
