package com.nonspring.java03;

public class MessageEn implements Message {

	@Override
	public void printMsg() {
		
		System.out.println("Hello!!!");
		
	}

}
