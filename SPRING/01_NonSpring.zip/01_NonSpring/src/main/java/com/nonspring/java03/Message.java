package com.nonspring.java03;

public interface Message {

	void printMsg();   // 추상 메서드
	
}
