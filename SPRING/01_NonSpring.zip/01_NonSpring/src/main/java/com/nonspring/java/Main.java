package com.nonspring.java;

public class Main {

	public static void main(String[] args) {
		
		// 영문으로 인사말을 출력하고 싶은 경우
		// MessageEn english = new MessageEn();
		
		// english.printMsg();
		
		// 한글로 인사말을 출력하는 내용으로 수정
		MessageKr korean = new MessageKr();
		
		korean.printMsg();

	}

}
