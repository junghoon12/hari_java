package com.nonspring.goott;

public class MessageKR {

	void printMsg() {
		
		System.out.println("방가방가~~ 스프링!!!");
	}
}
