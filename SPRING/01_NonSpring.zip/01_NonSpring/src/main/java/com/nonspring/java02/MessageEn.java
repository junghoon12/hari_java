package com.nonspring.java02;

public class MessageEn implements Message {

	@Override
	public void printMsg() {
		
		System.out.println("Hello!!!");
		
	}

}
