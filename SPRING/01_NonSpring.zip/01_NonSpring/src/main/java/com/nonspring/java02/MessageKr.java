package com.nonspring.java02;

public class MessageKr implements Message {

	@Override
	public void printMsg() {
		
		System.out.println("안녕하세요!!!");
		
	}

}
