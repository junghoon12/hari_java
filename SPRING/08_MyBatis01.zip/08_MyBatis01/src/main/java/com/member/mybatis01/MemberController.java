package com.member.mybatis01;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;

import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.member.model.Member;
import com.member.model.MemberDAO;

@Controller
public class MemberController {

	@Autowired
	private MemberDAO dao;
	
	@RequestMapping("member_list.go")
	public String list(Model model) {
		
		List<Member> list = this.dao.getMemberList();
		
		model.addAttribute("memberList", list);
		
		return "/member/member_list";
		
	}

	
	@RequestMapping("member_insert.go")
	public String insert() {
		
		return "/member/member_insert";
	}


	@RequestMapping("member_insert_ok.go")
	public void insertOk(Member dto,
			HttpServletResponse response) throws IOException {
		
		int check = this.dao.insertMember(dto);
		
		response.setContentType("text/html; charset=UTF-8");
		
		PrintWriter out = response.getWriter();
		
		if(check > 0) {
			out.println("<script>");
			out.println("alert('회원 등록 성공!!!')");
			out.println("location.href='member_list.go'");
			out.println("</script>");
		}else {
			out.println("<script>");
			out.println("alert('회원 등록 실패~~~')");
			out.println("history.back()");
			out.println("</script>");
		}
		
	}
	
	
	@RequestMapping("member_content.go")
	public String content(@RequestParam("num") int no,
						Model model) {
		
		Member dto = this.dao.getMember(no);
		
		model.addAttribute("Content", dto);
		
		return "/member/member_content";
		
	}


}










