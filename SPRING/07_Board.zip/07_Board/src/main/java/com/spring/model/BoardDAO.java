package com.spring.model;

import java.util.List;

public interface BoardDAO {

	List<Board> getBoardList();
	
	int insertBoard(Board dto);
	
	Board boardCont(int no);
	
	void readCount(int no);
	
	int updateBoard(Board dto);
	
	int deleteBoard(int no);
	
	void updateSeq(int no);
	
	List<Board> searchBoardList(
				String field, String keyword);
	
	
}
