package com.spring.di01;

import org.springframework.context.support.GenericXmlApplicationContext;

public class Main {

	public static void main(String[] args) {
		
		GenericXmlApplicationContext container =
				new GenericXmlApplicationContext("getsum.xml");
		
		GetSum getSum = (GetSum)container.getBean("sum");

		getSum.hap();
		
		container.close();
		
	}

}
