package com.spring.di05;

public class HyundaiCar implements Car {

	@Override
	public void drive() {
		
		System.out.println("현대자동차 GV80을 운전합니다.~~~");

	}

}
