package com.spring.di05;

public class SamsungCar implements Car {

	@Override
	public void drive() {
		
		System.out.println("르노삼성자동차 SM7을 운전합니다.~~~");

	}

}
