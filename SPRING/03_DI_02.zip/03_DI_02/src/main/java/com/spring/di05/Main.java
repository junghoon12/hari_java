package com.spring.di05;

import org.springframework.context.support.GenericXmlApplicationContext;

public class Main {

	public static void main(String[] args) {
		
		GenericXmlApplicationContext container = 
				new GenericXmlApplicationContext("car.xml");
		
		CarImpl car = (CarImpl)container.getBean("car");
		
		car.move();
		
		container.close();
		
	}

}
