package com.spring.di05;

public class KiaCar implements Car {

	@Override
	public void drive() {
		
		System.out.println("기아자동차 카니발을 운전합니다.~~~");

	}

}
