package com.spring.di02;

public class MessageEn implements Message {

	@Override
	public void printMsg() {
		
		System.out.println("Hello!!!");
		
	}

	
	
}
