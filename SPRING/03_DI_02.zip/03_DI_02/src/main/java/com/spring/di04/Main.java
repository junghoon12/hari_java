package com.spring.di04;

import org.springframework.context.support.GenericXmlApplicationContext;

public class Main {

	public static void main(String[] args) {
		
		GenericXmlApplicationContext container = 
				new GenericXmlApplicationContext("person.xml");
		
		PersonInfo person = (PersonInfo)container.getBean("info");

		person.getPersonInfo();
		
		container.close();
		
	}

}
