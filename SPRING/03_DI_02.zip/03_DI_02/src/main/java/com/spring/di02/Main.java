package com.spring.di02;

import org.springframework.context.support.GenericXmlApplicationContext;

public class Main {

	public static void main(String[] args) {
		
		GenericXmlApplicationContext container =
				new GenericXmlApplicationContext("message.xml");
		
		MessageImpl msg = (MessageImpl)container.getBean("msg");
		
		msg.msg();
		
		container.close();

	}

}
