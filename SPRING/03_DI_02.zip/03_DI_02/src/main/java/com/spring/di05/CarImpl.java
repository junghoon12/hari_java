package com.spring.di05;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class CarImpl {

	private Car car;
	
	// 비지니스 로직
	public void move() {
		
		this.car.drive();
		
	}
	
}
