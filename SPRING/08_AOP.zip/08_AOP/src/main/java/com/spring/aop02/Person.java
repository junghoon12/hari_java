package com.spring.aop02;

public interface Person {

	
	public void doSomething();

}
