package com.mybatis.board;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;

import javax.inject.Inject;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.mybatis.model.Board;
import com.mybatis.model.BoardDAO;
import com.mybatis.model.Page;

@Controller
public class BoardController {

	@Inject
	private BoardDAO dao;
	
	// 한 페이지당 보여질 게시물의 수
	private final int rowsize = 3;
	
	// DB 상의 전체 게시물의 수
	private int totalRecord = 0;
	
	
	@RequestMapping("board_list.go")
	public String list(HttpServletRequest request, 
						Model model) {
		
		int page;     // 현재 페이지 변수
		
		// 페이징 처리 작업
		if(request.getParameter("page") != null) {
			page = Integer.parseInt(request.getParameter("page"));
		}else {
			// 처음으로 "게시물 전체 목록" 태그를 클릭한 경우
			page = 1;
		}
		
		// DB 상의 전체 게시물의 수를 확인하는 메서드 호출.
		totalRecord = this.dao.getListCount();
		
		Page pdto = new Page(page, rowsize, totalRecord);
		
		// 현재 페이지에 해당하는 게시물을 가져오는 메서드 호출.
		List<Board> list = this.dao.getBoardList(pdto);
		
		model.addAttribute("List", list)
			 .addAttribute("Paging", pdto);
		
		return "board_list";
		
	}
	
	
	@RequestMapping("board_write.go")
	public String write() {
		
		return "board_write";
	}
	
	
	@RequestMapping("board_write_ok.go")
	public void writeOk(Board dto,
				HttpServletResponse response) throws IOException {
		
		int res = this.dao.insertBoard(dto);
		
		response.setContentType("text/html; charset=UTF-8");
		
		PrintWriter out = response.getWriter();
		
		if(res > 0) {
			out.println("<script>");
			out.println("alert('게시글 등록 성공!!!')");
			out.println("location.href='board_list.go'");
			out.println("</script>");
		}else {
			out.println("<script>");
			out.println("alert('게시글 등록 실패~~~')");
			out.println("history.back()");
			out.println("</script>");
		}
		
	}
	
	
	@RequestMapping("board_content.go")
	public String cont(@RequestParam("no") int no,
					@RequestParam("page") int nowPage,
					Model model) {
		
		// 조회 수를 증가시켜 주는 메서드 호출
		this.dao.readCount(no);
		
		// 게시글 번호에 해당하는 상세 내역을 조회하는 메서드 호출
		Board cont = this.dao.boardContent(no);
		
		model.addAttribute("Content", cont)
			 .addAttribute("Page", nowPage);
		
		return "board_content";
		
	}
	
	
	@RequestMapping("board_modify.go")
	public String modify(@RequestParam("no") int no,
			@RequestParam("page") int nowPage, Model model) {
		
		Board cont = this.dao.boardContent(no);
		
		model.addAttribute("Modify", cont)
		     .addAttribute("Page", nowPage);
		
		return "board_modify";
		
	}
	
	
	@RequestMapping("board_modify_ok.go")
	public void modifyOk(Board dto,
			@RequestParam("db_pwd") String db_pwd,
			@RequestParam("page") int nowPage,
			HttpServletResponse response) throws IOException {
		
		response.setContentType("text/html; charset=UTF-8");
		
		PrintWriter out = response.getWriter();
		
		if(db_pwd.equals(dto.getBoard_pwd())) {
			
			int res = this.dao.updateBoard(dto);
			
			if(res > 0) {
				out.println("<script>");
				out.println("alert('게시글 수정 성공!!!')");
				out.println("location.href='board_content.go?no="+dto.getBoard_no()+"&page="+nowPage+"'");
				out.println("</script>");
			}else {
				out.println("<script>");
				out.println("alert('게시글 수정 실패~~~')");
				out.println("history.back()");
				out.println("</script>");
			}
		}else {  // 비밀번호가 틀린 경우
			out.println("<script>");
			out.println("alert('비밀번호가 틀립니다. 확인해 주세여~~~')");
			out.println("history.back()");
			out.println("</script>");
		}
		
	}
	
	
	@RequestMapping("board_delete.go")
	public String delete(@RequestParam("no") int no,
			@RequestParam("page") int nowPage, Model model) {
		
		Board cont = this.dao.boardContent(no);
		
		model.addAttribute("Delete", cont)
		     .addAttribute("Page", nowPage);
		
		return "board_delete";
		
	}
	
	
	@RequestMapping("board_delete_ok.go")
	public void deleteOk(Board dto,
			@RequestParam("db_pwd") String db_pwd,
			@RequestParam("page") int nowPage,
			HttpServletResponse response) throws IOException {
		
		response.setContentType("text/html; charset=UTF-8");
		
		PrintWriter out = response.getWriter();
		
		if(db_pwd.equals(dto.getBoard_pwd())) {
			
			int res = this.dao.deleteBoard(dto.getBoard_no());
			
			if(res > 0) {
				
				this.dao.updateSequence(dto.getBoard_no());
				
				out.println("<script>");
				out.println("alert('게시글 삭제 성공!!!')");
				out.println("location.href='board_list.go?page="+nowPage+"'");
				out.println("</script>");
			}else {
				out.println("<script>");
				out.println("alert('게시글 삭제 실패~~~')");
				out.println("history.back()");
				out.println("</script>");
			}
		}else {  // 비밀번호가 틀린 경우
			out.println("<script>");
			out.println("alert('비밀번호가 틀립니다. 확인해 주세여~~~')");
			out.println("history.back()");
			out.println("</script>");
		}
		
	}
	
}







