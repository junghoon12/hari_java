package com.board.model;

import java.util.List;
import java.util.Map;

public interface BoardDAO {

	int getListCount();
	
	List<Board> getBoardList(Page dto);
	
	int insertBoard(Board dto);
	
	void readCount(int no);
	
	Board boardContent(int no);
	
	int updateBoard(Board dto);
	
	int deleteBoard(int no);
	
	void updateSequence(int no);
	
	int searchBoardCount(Map<String, String> map);
	
	List<Board> searchBoardList(Page dto);
	
}
