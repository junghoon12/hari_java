package com.board.model;

import java.util.List;
import java.util.Map;

import javax.inject.Inject;

import org.mybatis.spring.SqlSessionTemplate;
import org.springframework.stereotype.Repository;

@Repository
public class BoardDAOImpl implements BoardDAO {

	
	@Inject
	private SqlSessionTemplate sqlSession;
	
	
	@Override
	public int getListCount() {
		
		return this.sqlSession.selectOne("cnt");
	}

	@Override
	public List<Board> getBoardList(Page dto) {
		
		return this.sqlSession.selectList("list", dto);
	}

	@Override
	public int insertBoard(Board dto) {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public void readCount(int no) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public Board boardContent(int no) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public int updateBoard(Board dto) {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public int deleteBoard(int no) {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public void updateSequence(int no) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public int searchBoardCount(Map<String, String> map) {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public List<Board> searchBoardList(Page dto) {
		// TODO Auto-generated method stub
		return null;
	}

}
