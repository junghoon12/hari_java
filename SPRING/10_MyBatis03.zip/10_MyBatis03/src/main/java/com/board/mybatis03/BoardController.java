package com.board.mybatis03;

import java.util.List;

import javax.inject.Inject;
import javax.servlet.http.HttpServletRequest;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;

import com.board.model.Board;
import com.board.model.BoardDAO;
import com.board.model.Page;

@Controller
public class BoardController {

	@Inject
	private BoardDAO dao;
	
	// 한 페이지당 보여질 게시물의 수
	private final int rowsize = 3;
	
	// DB 상의 전체 게시물의 수
	private int totalRecord = 0;
	
	@RequestMapping("board_list.go")
	public String list(HttpServletRequest request,
							Model model) {
		
		// 페이징 처리 작업
		int page;    // 현재 페이지 변수
		
		if(request.getParameter("page") != null) {
			page = 
				Integer.parseInt(request.getParameter("page"));
		}else {
			// 처음으로 "게시물 전체 목록" 태그를 클릭한 경우
			page = 1;
		}
		
		// DB 상의 전체 게시물의 수를 확인하는 메서드 호출
		totalRecord = this.dao.getListCount();
		
		Page dto = new Page(page, rowsize, totalRecord);
		
		// 페이지에 해당하는 게시물을 가져오는 메서드 호출
		List<Board> list = this.dao.getBoardList(dto);
		
		model.addAttribute("List", list)
			 .addAttribute("Paging", dto);
		
		return "board_list";
		
	}
	
}










