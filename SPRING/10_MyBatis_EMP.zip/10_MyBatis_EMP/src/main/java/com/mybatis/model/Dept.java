package com.mybatis.model;

import lombok.Data;

@Data
public class Dept {

	private int deptno;
	private String dname;
	private String loc;
	
}
