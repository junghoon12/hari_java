package com.product.model;

import lombok.Data;

@Data
public class CategoryDTO {

	private int cnum;
	private String category_code;
	private String category_name;
	
}
