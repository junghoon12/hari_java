package com.product.model;

import java.util.List;

import org.mybatis.spring.SqlSessionTemplate;
import org.springframework.beans.factory.annotation.Autowired;

import org.springframework.stereotype.Repository;

@Repository
public class ProductDAOImpl implements ProductDAO {

	@Autowired
	private SqlSessionTemplate sqlSession;
	
	
	
	@Override
	public List<Product> getProductList() {

		return this.sqlSession.selectList("list");
	}

	@Override
	public int insertProduct(final Product dto) {
		
		return this.sqlSession.insert("add", dto);
	}

	@Override
	public Product getProductCont(int pnum) {
		
		return this.sqlSession.selectOne("cont", pnum);
	}

	
	@Override
	public int updateProduct(final Product dto) {
		
		return this.sqlSession.update("edit", dto);
	}

	@Override
	public int deleteProduct(final int pnum) {
		
		return this.sqlSession.delete("del", pnum);
	}

	@Override
	public void updateSeq(final int pnum) {
		
		this.sqlSession.update("seq", pnum);
	}

	@Override
	public List<CategoryDTO> getCategoryList() {
		
		return this.sqlSession.selectList("cart");
	}

	
	


}
