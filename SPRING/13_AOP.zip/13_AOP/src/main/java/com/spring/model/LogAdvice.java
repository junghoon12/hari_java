package com.spring.model;

public class LogAdvice {

	public void printLog() {
		
		System.out.println("[사전 처리] 비지니스 로직 수행 전 동작");
	
	}
	
}
