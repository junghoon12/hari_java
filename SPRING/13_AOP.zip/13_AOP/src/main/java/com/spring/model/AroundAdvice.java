package com.spring.model;

import org.aspectj.lang.ProceedingJoinPoint;

public class AroundAdvice {

	// around로 등록되는 Advice는 리턴타입과 매개변수가 고정이 되어야 함.
	// 반환타입은 Object 타입, 매개변수는 ProceedingjoinPoint 타입이어야 함.
	public Object aroundLog(ProceedingJoinPoint jp) throws Throwable {
		
		Object obj = null;
		
		long startTime = System.currentTimeMillis();
		
		System.out.println("===[Before Logic]===");
		
		// 이 시점에 클라이어트가 호출한 비지니스  메서드가 실행이 됨.
		obj = jp.proceed();
		
		long endTime = System.currentTimeMillis();
		
		// getSignature() : 호출되는 메서드에 대한 정보를 구해주는 메서드.
		String method = jp.getSignature().getName();
		
		System.out.println(method + "() 메서드에서 소요된 시간 >>> " + 
					(endTime - startTime) + "(ms)초");
		
		return obj;
	
	}
	
}
