package com.spring.model;

import lombok.Data;

@Data
public class BoardDTO {

	private int seq;
	private String title;
	private String writer;
	private String content;
	private String regdate;
	private int cnt;
	
}
