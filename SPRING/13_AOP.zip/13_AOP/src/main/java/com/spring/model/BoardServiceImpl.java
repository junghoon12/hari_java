package com.spring.model;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service("boardService")
public class BoardServiceImpl implements BoardService {

	@Autowired
	private BoardDAO dao;
	
	@Override
	public void insertBoard(BoardDTO dto) {
		// 사전 처리 작업이 로그 출력 또는 입력 값에 대한 확인 작업,
		// 보안 관련 작업 코드 등이 해당이 될 수 있음.
		// System.out.println("<사전 처리> 비지니스 로직 수행 전 동작");
		// LogAdvice log = new LogAdvice();
		// log.printLog();
		
		this.dao.insertBoard(dto);       // 비지니스 로직
		
	}

	@Override
	public List<BoardDTO> getBoardList() {
		// System.out.println("<사전 처리> 비지니스 로직 수행 전 동작");
		// LogAdvice log = new LogAdvice();
		// log.printLog();
		
		return this.dao.getBoardList();  // 비지니스 로직
	}

}
