package com.spring.di06;

public class KiaCar implements Car {

	@Override
	public void drive() {
		
		System.out.println("기아 자동차를 운전합니다.~~~");
		
	}

}
