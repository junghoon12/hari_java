package com.spring.di08;

import java.util.Map;
import java.util.Set;

import lombok.Data;

@Data
public class MapTest {

	private Map<Integer, String> map;
	
	// 비지니스 로직
	public void output() {
		
		// keySet() : Map 에 있는 키(값)를 전부 다 가져오는 메서드.
		Set<Integer> set = map.keySet();
		
		for(Integer k : set) {
			
			System.out.println(k + " >>> " + map.get(k));
			
		}
	}
	
}
