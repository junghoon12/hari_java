package com.spring.di02;

public interface Message {

	void printMsg();   // 추상 메서드
	
}
