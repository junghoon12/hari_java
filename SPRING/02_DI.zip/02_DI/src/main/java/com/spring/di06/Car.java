package com.spring.di06;

public interface Car {

	void drive();
	
}
