package com.spring.di07;

import org.springframework.context.support.AbstractApplicationContext;
import org.springframework.context.support.GenericXmlApplicationContext;

public class Main {

	public static void main(String[] args) {
		
		AbstractApplicationContext ctx = 
				new GenericXmlApplicationContext
							("classpath:baseball.xml",
							 "classpath:baseballTeam.xml");
		
		PlayerInfo player = (PlayerInfo)ctx.getBean("info");
		
		player.getPlayerInfo();
		
		System.out.println(":::::::::::::::::::::::::::::::::::");
		
		BaseballTeam team = (BaseballTeam)ctx.getBean("team");
		
		System.out.println("::: 국가대표 야구 선수단 :::");
		
		System.out.println("대표팀 감독 >>> " + team.getManager());
		System.out.println("대표팀 타격코치 >>> " + team.getBattingCoach());
		System.out.println("대표팀 투수코치 >>> " + team.getPitcherCoach());
		System.out.println("대표팀 타자 >>> " + team.getHitter());
		System.out.println("대표팀 투수 >>> " + team.getPitcher());
		
		ctx.close();

	}

}
