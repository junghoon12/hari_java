package com.spring.di03;

public interface DAO {

	void add();
	
}
