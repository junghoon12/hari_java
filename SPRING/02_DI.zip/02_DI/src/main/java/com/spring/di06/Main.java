package com.spring.di06;

import org.springframework.context.support.AbstractApplicationContext;
import org.springframework.context.support.GenericXmlApplicationContext;

public class Main {

	public static void main(String[] args) {
		
		AbstractApplicationContext ctx = 
				new GenericXmlApplicationContext
							("classpath:car.xml");
		
		CarImpl car = ctx.getBean("impl", CarImpl.class);
		
		car.move();
		
		ctx.close();

	}

}
