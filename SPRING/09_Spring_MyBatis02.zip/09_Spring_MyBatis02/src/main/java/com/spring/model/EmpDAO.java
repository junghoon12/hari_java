package com.spring.model;

import java.util.List;

public interface EmpDAO {

	// 전체 사원 목록을 조회하는 추상 메서드.
	List<EmpDTO> getEmpList();
	
	// 사원을 등록하는 추상 메서드.
	int insertEmp(EmpDTO dto);
	
	// 사원번호에 해당하는 사원의 정보를 조회하는 추상 메서드.
	EmpDTO getEmp(int no);
	
	// 사원의 정보를 수정하는 추상 메서드.
	int updateEmp(EmpDTO dto);
	
	// 특정 사원을 삭제하는 추상 메서드.
	int deleteEmp(int no);
	
	// 담당업무를 조회하는 추상 메서드.
	List<String> getJoblist();
	
	// 관리자를 조회하는 추상 메서드.
	List<EmpDTO> getMgrList();
	
	// 부서테이블의 전체 목록을 조회하는 추상 메서드.
	List<DeptDTO> getDeptList();
	
	
}




