package com.emp.model;

import java.util.List;

public interface EmpDAO {

	List<Emp> getEmpList();
	
	int insertEmp(Emp dto);
	
	Emp getEmp(int no);
	
	int updateEmp(Emp dto);
	
	int deleteEmp(int no);
	
	List<Dept> getDeptList();
	
	List<Emp> getMgrList();
	
	List<String> getJobList();
	
}
