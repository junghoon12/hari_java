package com.emp.mybatis02;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;

import javax.inject.Inject;
import javax.servlet.http.HttpServletResponse;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.emp.model.Dept;
import com.emp.model.Emp;
import com.emp.model.EmpDAO;

@Controller
public class EmpController {

	@Inject
	private EmpDAO dao;
	
	
	@RequestMapping("emp_list.go")
	public String list(Model model) {
		
		List<Emp> list = this.dao.getEmpList();
		
		model.addAttribute("empList", list);
		
		return "emp_list";
		
	}
	
	
	
	@RequestMapping("emp_insert.go")
	public String insert(Model model) {
		
		// 담당업무를 조회하는 메서드 호출
		List<String> jobList = this.dao.getJobList();
		
		// 관리자를 조회하는 메서드 호출
		List<Emp> mgrList = this.dao.getMgrList();
		
		// 부서번호를 조회하는 메서드 호출
		List<Dept> deptList = this.dao.getDeptList();
		
		model.addAttribute("JobList", jobList)
			 .addAttribute("MgrList", mgrList)
			 .addAttribute("DeptList", deptList);
		
		return "emp_insert";
		
	}
	
	
	@RequestMapping("emp_insert_ok.go")
	public void inertOk(Emp dto,
			HttpServletResponse response) throws IOException {
		
		int res = this.dao.insertEmp(dto);
		
		response.setContentType("text/html; charset=UTF-8");
		
		PrintWriter out = response.getWriter();
		
		if(res > 0) {
			out.println("<script>");
			out.println("alert('사원 등록 성공!!!')");
			out.println("location.href='emp_list.go'");
			out.println("</script>");
		}else {
			out.println("<script>");
			out.println("alert('사원 등록 실패~~~')");
			out.println("history.back()");
			out.println("</script>");
		}
			
	}
	
	
	@RequestMapping("emp_content.go")
	public String cont(@RequestParam("no") int no,
				Model model) {
		
		Emp cont = this.dao.getEmp(no);
		
		// 부서(dept) 테이블의 전체 리스트를 조회하는 메서드 호출
		List<Dept> deptList = this.dao.getDeptList();
		
		model.addAttribute("Cont", cont)
			 .addAttribute("DeptList", deptList);
		
		return "emp_content";
		
	}
	
	
	@RequestMapping("emp_modify.go")
	public String modify(@RequestParam("no") int no,
			Model model) {
		
		// 담당업무를 조회하는 메서드 호출
		List<String> jobList = this.dao.getJobList();
		
		// 관리자를 조회하는 메서드 호출
		List<Emp> mgrList = this.dao.getMgrList();
		
		// 부서번호를 조회하는 메서드 호출
		List<Dept> deptList = this.dao.getDeptList();
		
		Emp cont = this.dao.getEmp(no);
		
		model.addAttribute("JobList", jobList)
		 	 .addAttribute("MgrList", mgrList)
		 	 .addAttribute("DeptList", deptList)
		 	 .addAttribute("Modify", cont);
	
		return "emp_modify";
		
	}
	
	
	@RequestMapping("emp_modify_ok.go")
	public void updateOk(Emp dto,
			HttpServletResponse response) throws IOException {
		
		int res = this.dao.updateEmp(dto);
		
		response.setContentType("text/html; charset=UTF-8");
		
		PrintWriter out = response.getWriter();
		
		if(res > 0) {
			out.println("<script>");
			out.println("alert('사원 정보 수정 성공!!!')");
			out.println("location.href='emp_content.go?no="+dto.getEmpno()+"'");
			out.println("</script>");
		}else {
			out.println("<script>");
			out.println("alert('사원 정보 수정 실패~~~')");
			out.println("history.back()");
			out.println("</script>");
		}
	}
	
	
	@RequestMapping("emp_delete.go")
	public void delete(@RequestParam("no") int no,
			HttpServletResponse response) throws IOException {
		
		int res = this.dao.deleteEmp(no);
		
		response.setContentType("text/html; charset=UTF-8");
		
		PrintWriter out = response.getWriter();
		
		if(res > 0) {
			out.println("<script>");
			out.println("alert('사원 삭제 성공!!!')");
			out.println("location.href='emp_list.go'");
			out.println("</script>");
		}else {
			out.println("<script>");
			out.println("alert('사원 삭제 실패~~~')");
			out.println("history.back()");
			out.println("</script>");
		}
		
	}
	
	
}



