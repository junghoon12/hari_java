package com.spring.model;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.stereotype.Repository;

/*
 * Spring에서 일반적으로 DAO 클래스는
 * @Repository 애노테이션을 적용.
 */
@Repository
public class MemberDAOImpl implements MemberDAO {

	@Autowired
	private JdbcTemplate template;
	
	String sql = null;
	
	@Override
	public List<Member> getMemberList() {
		
		List<Member> list;
		
		sql = "select * from member10 order by num desc";
		
		return list = this.template.query(sql, new RowMapper<Member> () {

			@Override
			public Member mapRow(ResultSet rs, int rowNum) throws SQLException {
				
				Member member = new Member();
				
				member.setNum(rs.getInt("num"));
				member.setMemid(rs.getString("memid"));
				member.setMemname(rs.getString("memname"));
				member.setPwd(rs.getString("pwd"));
				member.setAge(rs.getInt("age"));
				member.setMileage(rs.getInt("mileage"));
				member.setJob(rs.getString("job"));
				member.setAddr(rs.getString("addr"));
				member.setRegdate(rs.getString("regdate"));
				
				return member;
			}
			
		});
	}

	@Override
	public int insertMember(Member dto) {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public Member getMember(int num) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public int updateMember(Member dto) {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public int deleteMember(int num) {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public void updateSequence(int num) {
		// TODO Auto-generated method stub
		
	}

}
