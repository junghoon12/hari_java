package com.spring.jdbc01;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;

import com.spring.model.Member;
import com.spring.model.MemberService;

@Controller
public class MemberController {

	@Autowired
	private MemberService service;
	
	@RequestMapping("member_list.go")
	public String list(Model model) {
		
		List<Member> list = this.service.list();
		
		model.addAttribute("memberList", list);
		
		return "member_list";	
	}
	
}
