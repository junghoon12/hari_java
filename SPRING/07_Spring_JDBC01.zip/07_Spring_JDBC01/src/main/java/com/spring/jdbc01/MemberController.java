package com.spring.jdbc01;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;

import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.spring.model.Member;
import com.spring.model.MemberService;

@Controller
public class MemberController {

	@Autowired
	private MemberService service;
	
	@RequestMapping("member_list.go")
	public String list(Model model) {
		
		List<Member> list = this.service.list();
		
		model.addAttribute("memberList", list);
		
		return "member_list";	
	}
	
	@RequestMapping("member_insert.go")
	public String insert() {
		
		return "member_insert";
	}
	
	@RequestMapping("member_insert_ok.go")
	public void insertOk(Member member,
			HttpServletResponse response) throws IOException {
		
		int chk = this.service.insert(member);
		
		response.setContentType("text/html; charset=UTF-8");
		
		PrintWriter out = response.getWriter();
		
		if(chk > 0) {
			out.println("<script>");
			out.println("alert('회원 등록 성공!!!')");
			out.println("location.href='member_list.go'");
			out.println("</script>");
		}else {
			out.println("<script>");
			out.println("alert('회원 등록 실패~~~')");
			out.println("history.back()");
			out.println("</script>");
		}
		
	}
	
	@RequestMapping("member_content.go")
	public String content(@RequestParam("num") int no,
						Model model) {
		
		// 회원의 상세 정보를 조회하는 메서드 호출
		Member cont = this.service.member(no);
		
		model.addAttribute("Content", cont);
		
		return "member_content";
		
	}
	
	@RequestMapping("member_modify.go")
	public String modify(@RequestParam("num") int no,
					Model model) {
		
		// 회원의 상세 정보를 조회하는 메서드 호출
		Member cont = this.service.member(no);
		
		model.addAttribute("Modify", cont);
		
		return "member_modify";
		
	}
	
	@RequestMapping("member_modify_ok.go")
	public void modifyOk(Member member,
			@RequestParam("db_pwd") String db_pwd,
			HttpServletResponse response) throws IOException {
		
		response.setContentType("text/html; charset=UTF-8");
		
		PrintWriter out = response.getWriter();
		
		if(db_pwd.equals(member.getPwd())) {
			
			int chk = this.service.update(member);
			
			if(chk > 0) {
				out.println("<script>");
				out.println("alert('회원 정보 수정 성공!!!')");
				out.println("location.href='member_content.go?num="+member.getNum()+"'");
				out.println("</script>");
			}else {
				out.println("<script>");
				out.println("alert('회원 정보 수정 실패~~~')");
				out.println("history.back()");
				out.println("</script>");
			}
		}else {
			out.println("<script>");
			out.println("alert('비밀번호가 틀립니다. 확인해 주세요~~~')");
			out.println("history.back()");
			out.println("</script>");
		}
		
	}
	
	@RequestMapping("member_delete.go")
	public String delete(@RequestParam("num") int no,
					Model model) {
		
		Member cont = this.service.member(no);
		
		model.addAttribute("Delete", cont);
		
		return "member_delete";
		
	}
	
	@RequestMapping("member_delete_ok.go")
	public void deleteOk(@RequestParam("pwd") String pwd,
			@RequestParam("no") int no,
			@RequestParam("db_pwd") String db_pwd,
			HttpServletResponse response) throws IOException {
		
		response.setContentType("text/html; charset=UTF-8");
		
		PrintWriter out = response.getWriter();
		
		if(pwd.equals(db_pwd)) {
			
			int chk = this.service.delete(no);
			
			if(chk > 0) {
				// 삭제 시 회원번호 재작업하는 메서드 호출.
				this.service.sequene(no);
				
				out.println("<script>");
				out.println("alert('회원 삭제 성공!!!')");
				out.println("location.href='member_list.go'");
				out.println("</script>");
				
			}else {
				out.println("<script>");
				out.println("alert('회원 삭제 실패~~~')");
				out.println("history.back()");
				out.println("</script>");
			}
			
		}else {
			out.println("<script>");
			out.println("alert('비밀번호가 틀립니다. 확인해 주세요~~~')");
			out.println("history.back()");
			out.println("</script>");
		}
		
	}
	
	
}
