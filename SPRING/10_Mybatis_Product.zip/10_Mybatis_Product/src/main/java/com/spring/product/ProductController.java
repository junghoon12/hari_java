package com.spring.product;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;

import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.spring.model.CategoryDTO;
import com.spring.model.ProductDAO;
import com.spring.model.ProductDTO;

@Controller
public class ProductController {

	@Autowired
	private ProductDAO dao;
	
	
	@RequestMapping("product_list.go")
	public String list(Model model) {
		
		List<ProductDTO> list = this.dao.getProductList();
		
		model.addAttribute("List", list);
		
		return "product_list";
		
	}
	
	@RequestMapping("product_insert.go")
	public String insert(Model model) {
		
		// 제품 카테고리 코드 목록을 조회하여 
		// 제품 등록 폼 페이지로 이동
		List<CategoryDTO> categoryList =
					this.dao.getCategoryList();
		
		model.addAttribute("CategoryList", categoryList);
		
		return "product_insert";
	}
	
	@RequestMapping("product_insert_ok.go")
	public void insertOk(ProductDTO dto,
			HttpServletResponse response) throws IOException {
		
		int chk = this.dao.insertProduct(dto);
		
		response.setContentType("text/html; charset=UTF-8");
		
		PrintWriter out = response.getWriter();
		
		if(chk > 0) {
			out.println("<script>");
			out.println("alert('제픔 등록 성공!!!')");
			out.println("location.href='product_list.go'");
			out.println("</script>");
		}else {
			out.println("<script>");
			out.println("alert('제픔 등록 실패~~~')");
			out.println("histpry.back()");
			out.println("</script>");
		}
	}
	
	
	@RequestMapping("product_content.go")
	public String cont(@RequestParam("pnum") int pnum,
						Model model) {
		
		ProductDTO cont = this.dao.getProduct(pnum);
		
		model.addAttribute("Cont", cont);
		
		return "product_content";
		
	}
	
	
	@RequestMapping("product_modify.go")
	public String modify(@RequestParam("pnum") int pnum,
						Model model) {
		
		ProductDTO dto = this.dao.getProduct(pnum);
		
		model.addAttribute("Modify", dto);
		
		return "product_modify";
	}
	
	
	@RequestMapping("product_modify_ok.go")
	public void modifyOk(ProductDTO dto,
			HttpServletResponse response) throws IOException {
		
		int chk = this.dao.updateProduct(dto);
		
		response.setContentType("text/html; charset=UTF-8");
		
		PrintWriter out = response.getWriter();
		
		if(chk > 0) {
			out.println("<script>");
			out.println("alert('제품 정보 수정 성공!!!')");
			out.println("location.href='product_content.go?pnum="+dto.getPnum()+"'");
			out.println("</script>");
		}else {
			out.println("<script>");
			out.println("alert('제품 정보 수정 실패~~~')");
			out.println("history.back()");
			out.println("</script>");
		}
		
	}
	
	
	@RequestMapping("product_delete.go")
	public void delete(@RequestParam("pnum") int pnum,
			HttpServletResponse response) throws IOException {
		
		int chk = this.dao.deleteProduct(pnum);
		
		response.setContentType("text/html; charset=UTF-8");
		
		PrintWriter out = response.getWriter();
		
		if(chk > 0) {
			// 삭제된 제품번호보다 큰 번호에 대해서
			// 번호 재 작업을 해 주는 메서드 호출.
			this.dao.updateSequence(pnum);
			
			out.println("<script>");
			out.println("alert('제품 삭제 성공!!!')");
			out.println("location.href='product_list.go'");
			out.println("</script>");
		}else {
			out.println("<script>");
			out.println("alert('제픔 삭제 실패~~~')");
			out.println("history.back()");
			out.println("</script>");
		}
		
		
	}
	
	
	
	
	
	
	
	
	
}
