package com.spring.model;

import java.util.List;

public interface ProductDAO {

	// 제품 전체 목록을 조회하는 추상 메서드.
	List<ProductDTO> getProductList();
	
	// 제품을 추가하는 추상 메서드.
	int insertProduct(ProductDTO dto);
	
	// 제품의 상세 정보를 조회하는 추상 메서드.
	ProductDTO getProduct(int pnum);
	
	// 제품을 수정하는 추상 메서드.
	int updateProduct(ProductDTO dto);
	
	// 제품을 삭제하는 추상 메서드.
	int deleteProduct(int pnum);
	
	// 제품 번호를 재작업 하는 추상 메서드.
	void updateSequence(int pnum);
	
	// 전체 카테고리 코드 목록을 조회하는 추상 메서드.
	List<CategoryDTO> getCategoryList();
	
}
