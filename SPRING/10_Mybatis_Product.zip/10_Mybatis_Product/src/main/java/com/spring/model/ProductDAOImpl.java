package com.spring.model;

import java.util.List;

import org.mybatis.spring.SqlSessionTemplate;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

@Repository
public class ProductDAOImpl implements ProductDAO {

	@Autowired
	private SqlSessionTemplate sqlSession;
	
	
	
	@Override
	public List<ProductDTO> getProductList() {
		
		return this.sqlSession.selectList("list");
	}

	@Override
	public int insertProduct(ProductDTO dto) {
		
		return this.sqlSession.insert("add", dto);
	}

	@Override
	public ProductDTO getProduct(int pnum) {
		
		return this.sqlSession.selectOne("cont", pnum);
	}

	@Override
	public int updateProduct(ProductDTO dto) {
		
		return this.sqlSession.update("edit", dto);
		
	}

	@Override
	public int deleteProduct(int pnum) {
		
		return this.sqlSession.delete("del", pnum);
	}

	@Override
	public void updateSequence(int pnum) {
		
		this.sqlSession.update("seq", pnum);
		
	}

	@Override
	public List<CategoryDTO> getCategoryList() {
		
		return this.sqlSession.selectList("category");
	}

}
