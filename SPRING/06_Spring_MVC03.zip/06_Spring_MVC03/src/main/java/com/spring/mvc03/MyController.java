package com.spring.mvc03;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
public class MyController {

	@RequestMapping("join")
	public String abc() {
		
		return "join";
	}
	
	@RequestMapping("join_ok")
	public String join(Member member, Model model) {
		
		model.addAttribute("Member", member);
		
		return "joinInfo";
	}
	
}
