package test;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.Calendar;

public class Server_Test {

	public static void main(String[] args) {
		// 오류
		int port = 8888;
		ServerSocket serverSocket = null;
		byte[] bytes = null;
		
		try {
			serverSocket = new ServerSocket(port);
			Socket clientSocket = serverSocket.accept();
			
			// 첫번째 원인
			// InputStream in = new InputStream();
			// OutputStream out = new OutputStream();
			
			// 첫번째 조치내용
			InputStream in = clientSocket.getInputStream();
			OutputStream out = clientSocket.getOutputStream();
			
			bytes = new byte[100];
			
			// 첫번째 데이터를 서버에서 클라이언트로 전송.
			String msg = "[서버 연결 성공]";
			bytes = msg.getBytes("UTF-8");
			
			out.write(bytes);
			
			Calendar cal = Calendar.getInstance();
			int hour = cal.get(Calendar.HOUR_OF_DAY);
			int minute = cal.get(Calendar.MINUTE);
			int second = cal.get(Calendar.SECOND);
			
			// 두번째 데이터를 서버에서 클라이언트로 전송.
			String now = 
				"[현재 시간] : "+hour+":"+minute+":"+second;
			bytes = now.getBytes("UTF-8");
			
			out.write(bytes);
			
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} finally {
			try {
				serverSocket.close();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}

	}

}
