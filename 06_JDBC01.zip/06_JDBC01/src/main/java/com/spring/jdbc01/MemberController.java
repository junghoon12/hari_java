package com.spring.jdbc01;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;

import javax.inject.Inject;
import javax.servlet.http.HttpServletResponse;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.spring.model.MemberDAO;
import com.spring.model.MemberDTO;

@Controller
public class MemberController {

	@Inject
	private MemberDAO dao;
	
	@RequestMapping("/member_list.go")
	public String list(Model model) {
		
		List<MemberDTO> list =
					this.dao.getMemberList();
		
		model.addAttribute("memberList", list);
		
		return "member_list";
		
	}
	
	@RequestMapping("member_insert.go")
	public String insert() {
		
		return "member_insert";
	}
	
	@RequestMapping("member_insert_ok.go")
	public void insertOk(MemberDTO dto,
			HttpServletResponse response) throws IOException {
		
		int check = this.dao.insertMember(dto);
		
		response.setContentType("text/html; charset=UTF-8");
		
		PrintWriter out = response.getWriter();
		
		if(check > 0) {
			out.println("<script>");
			out.println("alert('회원 등록 성공!!!')");
			out.println("location.href='member_list.go'");
			out.println("</script>");
		}else {
			out.println("<script>");
			out.println("alert('회원 등록 실패~~~')");
			out.println("history.back()");
			out.println("</script>");
		}
		
	}
	
	
	@RequestMapping("member_content.go")
	public String content(@RequestParam("num") int no,
			Model model) {
		
		// 회원의 상세 정보를 조회하는 메서드 호출
		MemberDTO dto = this.dao.getMember(no);
		
		model.addAttribute("Content", dto);
		
		return "member_content";
		
	}
	
	
	
}
