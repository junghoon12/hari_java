package com.member.model;

import java.util.List;

import org.mybatis.spring.SqlSessionTemplate;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

// Spring에서 일반적으로 DAO 클래스에는
// @Repository 애노테이션 적용.
@Repository
public class MemberDAOImpl implements MemberDAO {

	@Autowired
	private SqlSessionTemplate sqlSession;
	
	
	@Override
	public List<MemberDTO> getMemberList() {
		
		return this.sqlSession.selectList("all");
	}

	@Override
	public int insertMember(MemberDTO dto) {
		
		return this.sqlSession.insert("add", dto);
	}

	@Override
	public MemberDTO getMember(int num) {
		
		return this.sqlSession.selectOne("cont", num);
	}

	@Override
	public int updateMember(MemberDTO dto) {
		
		return this.sqlSession.update("edit", dto);
	}

	@Override
	public int deleteMember(int no) {
		
		return this.sqlSession.delete("del", no);
	}

	@Override
	public void updateSequence(int num) {
		
		this.sqlSession.update("seq", num);
		
	}

	
}
