package com.member.mybatis01;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;

import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.member.model.MemberDAO;
import com.member.model.MemberDTO;

@Controller
public class MemberController {

	@Autowired
	private MemberDAO dao;
	
	
	@RequestMapping("member_list.go")
	public String all(Model model) {
		
		List<MemberDTO> list = 
					this.dao.getMemberList();
		
		model.addAttribute("List", list);
		
		return "member_list";
	}
	
	
	@RequestMapping("member_insert.go")
	public String insert() {
		
		return "member_insert";
	}
	
	
	@RequestMapping("member_insert_ok.go")
	public void insertOk(MemberDTO dto,
			HttpServletResponse response) throws IOException {
		
		int check = this.dao.insertMember(dto);
		
		response.setContentType("text/html; charset=UTF-8");
		
		PrintWriter out = response.getWriter();
		
		if(check > 0) {
			out.println("<script>");
			out.println("alert('회원 등록 성공!!!')");
			out.println("location.href='member_list.go'");
			out.println("</script>");
		}else {
			out.println("<script>");
			out.println("alert('회원 등록 실패~~~')");
			out.println("history.back()");
			out.println("</script>");
		}
		
	}
	
	
	@RequestMapping("member_content.go")
	public String content(@RequestParam("num") int num,
						Model model) {
		
		MemberDTO dto = this.dao.getMember(num);
		
		model.addAttribute("Cont", dto);
		
		return "member_content";
		
	}
	
	
	@RequestMapping("member_modify.go")
	public String modify(@RequestParam("num") int no,
			Model model) {
		
		MemberDTO dto = this.dao.getMember(no);
		
		model.addAttribute("Modify", dto);
		
		return "member_modify";
	}
	
	
	@RequestMapping("member_modify_ok.go")
	public void modifyOk(MemberDTO dto,
		@RequestParam("db_pwd") String db_pwd,
		HttpServletResponse response) throws IOException {
		
		response.setContentType("text/html; charset=UTF-8");
		
		PrintWriter out = response.getWriter();
		
		if(db_pwd.equals(dto.getPwd())) {
			
			int check = this.dao.updateMember(dto);
			
			if(check > 0) {
				out.println("<script>");
				out.println("alert('회원 수정 성공!!!')");
				out.println("location.href='member_content.go?num="+dto.getNum()+"'");
				out.println("</script>");
			}else {
				out.println("<script>");
				out.println("alert('회원 수정 실패~~~')");
				out.println("history.back()");
				out.println("</script>");
			}
		}else {  // 비밀번호가 틀린 경우
			out.println("<script>");
			out.println("alert('비밀번호가 틀려유~~ 확인해 주세유~~~')");
			out.println("history.back()");
			out.println("</script>");
		}
		
	}
	
	
	@RequestMapping("member_delete.go")
	public void delete(@RequestParam("num") int no,
			HttpServletResponse response) throws IOException {
		
		int check = this.dao.deleteMember(no);
		
		response.setContentType("text/html; charset=UTF-8");
		
		PrintWriter out = response.getWriter();
		
		if(check > 0) {
			
			this.dao.updateSequence(no);
			
			out.println("<script>");
			out.println("alert('회원 삭제 성공!!!')");
			out.println("location.href='member_list.go'");
			out.println("</script>");
		}else {
			out.println("<script>");
			out.println("alert('회원 삭제 실패~~~')");
			out.println("history.back()");
			out.println("</script>");
		}
		
	}
	
	
	
	
	
	
}
