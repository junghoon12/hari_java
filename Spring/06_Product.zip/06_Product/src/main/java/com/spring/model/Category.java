package com.spring.model;

import lombok.Data;

@Data
public class Category {

	private int cnum;
	private String category_code;
	private String category_name;
	
}
