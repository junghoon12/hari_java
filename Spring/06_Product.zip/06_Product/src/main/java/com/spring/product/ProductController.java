package com.spring.product;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;

import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.spring.model.Category;
import com.spring.model.Product;
import com.spring.model.ProductDAO;

@Controller
public class ProductController {

	@Autowired
	private ProductDAO dao;
	
	
	@RequestMapping("product_list.go")
	public String list(Model model) {
		
		// 제품 전체 리스트를 조회하는 메서드 호출.
		List<Product> list = this.dao.getProductList();
		
		model.addAttribute("ProductList", list);
	
		
		return "product_list";
		
	}
	
	
	@RequestMapping("product_insert.go")
	public String insert(Model model) {
		
		// 제품 카테고리 코드 목록을 조회하는 메서드 호출.
		List<Category> categoryList = this.dao.getCategoryList();
		
		// 제품 카테고리 코드 목록을 제품 등록 폼 페이지로 이동.
		model.addAttribute("CategoryList", categoryList);
		
		return "product_insert";
		
	}
	
	
	@RequestMapping("product_insert_ok.go")
	public String insertOk(Product dto) {
		
		// 제품을 등록하는 메서드 호출.
		int chk = this.dao.insertProduct(dto);
		
		return "redirect:product_list.go";
	}
	
	
	@RequestMapping("product_content.go")
	public String cont(@RequestParam("pnum") int pnum,
							Model model) {
		
		// 제품번호에 해당하는 제품의 상세정보를 조회하는 메서드 호출.
		Product content = this.dao.getProduct(pnum);
		
		model.addAttribute("Cont", content);
		
		
		return "product_content";
		
	}
	
	
	@RequestMapping("product_modify.go")
	public String modify(@RequestParam("pnum") int pnum,
			Model model) {

		// 제품번호에 해당하는 제품의 상세정보를 조회하는 메서드 호출.
		Product content = this.dao.getProduct(pnum);
		
		model.addAttribute("Modify", content);
		
		
		return "product_modify";
	
	}
	
	
	@RequestMapping("product_modify_ok.go")
	public String modifyOk(Product dto) {
		
		// 제품번호에 해당하는 제품을 수정하는 메서드 호출.
		int chk = this.dao.updateProduct(dto);
		
		return "redirect:product_content.go?pnum="+dto.getPnum();
		
	}
	
	@RequestMapping("product_delete.go")
	public void delete(@RequestParam("pnum") int pnum,
			HttpServletResponse response) throws IOException {
		
		// 제품번호에 해당하는 제품을 삭제하는 메서드 호출.
		int chk = this.dao.deleteProduct(pnum);
		
		response.setContentType("text/html; charset=UTF-8");
		
		PrintWriter out = response.getWriter();
		
		if(chk > 0) {
			
			// 제품 삭제 시 삭제된 제품번호보다 큰 번호에 대해서
			// 다시 번호를 재작업 해 주는 메서드 호출.
			this.dao.updateSequence(pnum);
			
			out.println("<script>");
			out.println("alert('제품 삭제 성공!!!')");
			out.println("location.href='product_list.go'");
			out.println("</script>");
		}else {
			out.println("<script>");
			out.println("alert('제품 삭제 실패~~~')");
			out.println("history.back()");
			out.println("</script>");
		}
	}
	
}
