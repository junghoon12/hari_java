package com.spring.product;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;

import com.spring.model.Product;
import com.spring.model.ProductDAO;

@Controller
public class ProductController {

	@Autowired
	private ProductDAO dao;
	
	
	@RequestMapping("product_list.go")
	public String list(Model model) {
		
		// 제품 전체 리스트를 조회하는 메서드 호출.
		List<Product> list = this.dao.getProductList();
		
		model.addAttribute("ProductList", list);
	
		
		return "product_list";
		
	}
}
