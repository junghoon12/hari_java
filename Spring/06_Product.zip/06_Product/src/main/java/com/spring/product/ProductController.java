package com.spring.product;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;

import com.spring.model.ProductDAO;

@Controller
public class ProductController {

	@Autowired
	private ProductDAO dao;
	
	
}
