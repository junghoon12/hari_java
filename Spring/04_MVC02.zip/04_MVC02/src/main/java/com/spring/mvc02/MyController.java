package com.spring.mvc02;

import javax.servlet.http.HttpServletRequest;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

@Controller
public class MyController {

	@RequestMapping("input")
	public String input() {
		
		return "insertForm";
	}
	
	
	@RequestMapping("input_ok")
	public String abc(HttpServletRequest request,
			Model model) {
		
		String user_name = request.getParameter("name").trim();
		
		String user_age = request.getParameter("age").trim();
		
		String user_phone = request.getParameter("phone").trim();
		
		model.addAttribute("NAME", user_name)
			 .addAttribute("AGE", user_age)
			 .addAttribute("PHONE", user_phone);
		
		return "result";
		
	}
	
	
	@RequestMapping("login")
	public String login() {
		
		return "login_form";
	}
	
	
	@RequestMapping("login_ok")
	public String ok(
			@RequestParam("user_id") String id,
			@RequestParam("user_pwd") String pwd,
			Model model) {
		
		model.addAttribute("Id", id)
			 .addAttribute("Pwd", pwd);
		
		return "login_result";
	}
	
	
}
