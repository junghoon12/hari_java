package com.product.model;

import java.util.List;

import org.mybatis.spring.SqlSessionTemplate;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

@Repository
public class ProductDAOImpl implements ProductDAO {

	@Autowired
	private SqlSessionTemplate sqlSession;
	

	
	public List<Product> getProductList() {
		
		return this.sqlSession.selectList("list");
	}

	@Override
	public int insertProduct(Product dto) {
		
		return this.sqlSession.insert("add", dto);
	}

	@Override
	public Product getProduct(int pnum) {
		
		return this.sqlSession.selectOne("cont", pnum);
	}

	@Override
	public int updateProduct(Product dto) {
		
		return this.sqlSession.update("edit", dto);
	}

	@Override
	public int deleteProduct(int pnum) {
		
		return this.sqlSession.delete("del", pnum);
	}

	@Override
	public void updateSequence(int pnum) {
		
		this.sqlSession.update("seq", pnum);

	}

	@Override
	public List<Category> getCategoryList() {
		
		return this.sqlSession.selectList("category");
	}

}
