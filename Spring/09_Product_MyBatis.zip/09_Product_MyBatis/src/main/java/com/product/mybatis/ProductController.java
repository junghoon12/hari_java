package com.product.mybatis;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.product.model.Category;
import com.product.model.Product;
import com.product.model.ProductDAO;

@Controller
public class ProductController {

	@Autowired
	private ProductDAO dao;
	
	
	
	@RequestMapping("/")
	public String home() {
		
		return "main";
	}
	
	
	@RequestMapping("product_list.go")
	public String list(Model model) {
		
		// 제품 전체 리스트를 조회하는 메서드 호출.
		List<Product> list = this.dao.getProductList();
		
		model.addAttribute("ProductList", list);
		
		
		return "product_list";
		
	}
	
	
	@RequestMapping("product_insert.go")
	public String insert(Model model) {
		
		// 카테고리 코드 전체 목록을 조회하는 메서드 호출.
		List<Category> categoryList = this.dao.getCategoryList();
		
		model.addAttribute("CategoryList", categoryList);
		
		
		return "product_insert";
	}
	
	@RequestMapping("product_insert_ok.go")
	public String insertOk(Product dto) {
		
		int chk = this.dao.insertProduct(dto);
		
		return "redirect:product_list.go";
	}
	
	
	@RequestMapping("product_content.go")
	public String cont(@RequestParam("pnum") int pnum,
						Model model) {
		
		// 제품번호에 해당하는 제품의 상세정보를 조회하는 메서드 호출
		Product content = this.dao.getProduct(pnum);
		
		model.addAttribute("Cont", content);
		
		return "product_content";
	}
	
	@RequestMapping("product_modify.go")
	public String modify(@RequestParam("pnum") int pnum,
						Model model) {
		
		// 제품번호에 해당하는 제품의 상세정보를 조회하는 메서드 호출
		Product content = this.dao.getProduct(pnum);
		
		model.addAttribute("Cont", content);
		
		return "product_modify";
	}
	
	
	@RequestMapping("product_modify_ok.go")
	public String modifyOk(Product dto) {
		
		int chk = this.dao.updateProduct(dto);
		
		return "redirect:product_content.go?pnum="+dto.getPnum();
	}
	
	
	@RequestMapping("product_delete.go")
	public String delete(@RequestParam("pnum") int pnum) {
		
		int chk = this.dao.deleteProduct(pnum);
		
		if(chk > 0) {
			
			this.dao.updateSequence(pnum);
		}
		
		return "redirect:product_list.go";
	}
	
}
