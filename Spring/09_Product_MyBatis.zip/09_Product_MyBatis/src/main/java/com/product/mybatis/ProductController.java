package com.product.mybatis;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

import com.product.model.ProductDAO;

@Controller
public class ProductController {

	@Autowired
	private ProductDAO dao;
	
	
	
	@RequestMapping("/")
	public String home() {
		
		return "main";
	}
	
	
	
	
	
	
	
	
	
	
	
}
