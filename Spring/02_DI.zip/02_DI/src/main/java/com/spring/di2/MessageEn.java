package com.spring.di2;

public class MessageEn implements Message {

	@Override
	public void printMsg() {
		
		System.out.println("Hello, Spring!!!");

	}

}
