package com.spring.di;

import org.springframework.context.support.GenericXmlApplicationContext;

public class TVUser {

	public static void main(String[] args) {
		
		// 컨테이너를 생성을 하자.
		// BeanContainer container = new BeanContainer();
		
		// 스프링 컨테이너를 생성을 하자.
		GenericXmlApplicationContext container = 
				new GenericXmlApplicationContext("speaker.xml");
		
		
		// 컨테이너로부터 객체를 검색(lookup)을 하자.
		TV tv = (TV)container.getBean("tv");
		
		tv.powerOn();
		
		tv.volumeUp();
		
		tv.volumeDown();
		
		tv.powerOff();

	}

}
