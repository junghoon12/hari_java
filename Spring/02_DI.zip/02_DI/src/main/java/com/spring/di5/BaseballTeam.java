package com.spring.di5;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class BaseballTeam {

	private String manager;
	private String pitchingCoach;
	private String hittingCoach;
	private String hitter;
	private String pitcher;
	
}
