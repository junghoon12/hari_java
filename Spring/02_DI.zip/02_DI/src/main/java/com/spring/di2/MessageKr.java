package com.spring.di2;

public class MessageKr implements Message {

	@Override
	public void printMsg() {
		
		System.out.println("방가방가, 스프링!!!");

	}

}
