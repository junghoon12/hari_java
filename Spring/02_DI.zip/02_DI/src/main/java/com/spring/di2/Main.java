package com.spring.di2;

import org.springframework.context.support.GenericXmlApplicationContext;

public class Main {

	public static void main(String[] args) {
		
		// 스프링 컨테이너 객체 생성.
		GenericXmlApplicationContext container = 
				new GenericXmlApplicationContext("hello.xml");
		
		// 스프링 컨테이너를 이용하여 빈을 가져오면 됨.
		MessageImpl message = (MessageImpl)container.getBean("msg");
		
		message.msg();
		
		
		container.close();

	}

}
