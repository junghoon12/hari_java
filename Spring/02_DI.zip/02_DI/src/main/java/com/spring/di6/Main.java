package com.spring.di6;

import org.springframework.context.support.GenericXmlApplicationContext;

public class Main {

	public static void main(String[] args) {
		
		GenericXmlApplicationContext container = 
				new GenericXmlApplicationContext("map.xml");
		
		MapTest map = container.getBean("test", MapTest.class);
		
		map.output();
		
		
		container.close();

	}

}
