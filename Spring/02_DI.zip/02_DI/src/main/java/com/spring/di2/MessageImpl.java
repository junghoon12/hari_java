package com.spring.di2;


import lombok.Data;

@Data
public class MessageImpl {

	private Message message;
	
	
	// 비지니스 로직
	public void msg() {
		
		message.printMsg();
	}
	
}
