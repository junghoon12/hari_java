package com.spring.di2;

public interface Message {

	void printMsg();      // 추상 메서드
}
