package com.spring.aop2;

public interface Person {

	public void doSomething();
	
}
