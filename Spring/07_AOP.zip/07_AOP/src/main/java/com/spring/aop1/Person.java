package com.spring.aop1;

public interface Person {

	public void doSomething();
	
}
