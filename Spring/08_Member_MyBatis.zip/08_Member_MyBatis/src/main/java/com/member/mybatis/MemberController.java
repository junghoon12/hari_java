package com.member.mybatis;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;

import com.member.model.Member;
import com.member.model.MemberDAO;

@Controller
public class MemberController {

	@Autowired
	private MemberDAO dao;
	
	
	@RequestMapping("/")
	public String main() {
		
		return "main";
	}
	
	
	@RequestMapping("member_list.go")
	public String list(Model model) {
		
		// 회원 전체 목록 조회하는 메서드 호출.
		List<Member> list = this.dao.getMemberList();
		
		model.addAttribute("List", list);
		
		return "member_list";
	}
	
	
	
	
	
	
	
	
}
