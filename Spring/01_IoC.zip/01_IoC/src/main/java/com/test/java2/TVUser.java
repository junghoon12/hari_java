package com.test.java2;

public class TVUser {

	public static void main(String[] args) {
		
		// LgTV tv = new LgTV();
		
		// tv.turnOn();         // 전원을 켜는 메서드 호출.
		
		// tv.volumeUp();       // 볼륨을 올리는 메서드 호출.
		
		// tv.volumeDown();     // 볼륨을 내리는 메서드 호출.
		
		// tv.turnOff();        // 전원을 끄는 메서드 호출.
		
		TV tv = new LgTV();
		
		tv.turnOn();
		
		tv.volumeUp();
		
		tv.volumeDown();
		
		tv.turnOff();

	}

}
