package com.test.java2;

public interface TV {

	void turnOn();

	void turnOff();

	void volumeUp();

	void volumeDown();

}