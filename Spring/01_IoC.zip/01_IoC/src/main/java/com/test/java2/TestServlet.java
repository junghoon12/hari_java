package com.test.java2;

public class TestServlet {

	protected void 내맘대로() {
		
		System.out.println("메시지 출력");
		
	}
	
}
