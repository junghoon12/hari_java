package com.test.java3;

public interface TV {

	void turnOn();

	void turnOff();

	void volumeUp();

	void volumeDown();

}