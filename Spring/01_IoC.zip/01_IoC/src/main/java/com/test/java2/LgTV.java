package com.test.java2;

public class LgTV implements TV {

	public LgTV() {
		
		System.out.println("===> LgTV 생성");
	
	}  // 기본 생성자
	
	public void turnOn() {
		
		System.out.println("LgTV ---> 전원 켜기");
	}
	
	public void turnOff() {
		
		System.out.println("LgTV ---> 전원 끄기");
	}
	
	public void volumeUp() {
		
		System.out.println("LgTV ---> 소리 올리기");
	}
	
	
	public void volumeDown() {
		
		System.out.println("LgTV ---> 소리 내리기");
	}
	
	
}
