package com.spring.member;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;

import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.spring.model.Member;
import com.spring.model.MemberDAO;

@Controller
public class MemberController {

	@Autowired
	private MemberDAO dao;
	
	@RequestMapping("member_list.go")
	public String list(Model model) {
		
		List<Member> memberList = this.dao.getMemberList();
		
		model.addAttribute("MemberList", memberList);
		
		return "member_list";
	}
	
	
	@RequestMapping("member_insert.go")
	public String insert() {
		
		return "member_insert";
	}
	
	
	@RequestMapping("member_insert_ok.go")
	public void insertOk(Member dto,
			HttpServletResponse response) throws IOException {
		
		int chk = this.dao.insertMember(dto);
		
		response.setContentType("text/html; charset=UTF-8");
		
		PrintWriter out = response.getWriter();
		
		if(chk > 0) {
			out.println("<script>");
			out.println("alert('회원 등록 성공!!!')");
			out.println("location.href='member_list.go'");
			out.println("</script>");
		}else {
			out.println("<script>");
			out.println("alert('회원 등록 실패~~~')");
			out.println("history.back()");
			out.println("</script>");
		}
		
	}
	
	
	@RequestMapping("member_content.go")
	public String cont(@RequestParam("num") int no,
						Model model) {
		
		Member content = this.dao.getMember(no);
		
		model.addAttribute("Cont", content);
	
		
		return "member_content";
	}
	
	
	
	
	
	
	
}
