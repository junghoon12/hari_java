package com.spring.model;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.PreparedStatementSetter;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.stereotype.Repository;

// 스프링에서 일반적으로 DB와 연동하는 클래스는
// @Repository 라는 애노테이션을 붙여서 사용을 한다.
@Repository
public class MemberDAOImpl implements MemberDAO {

	@Autowired
	private JdbcTemplate template;
	
	String sql = null;
	
	
	@Override
	public List<Member> getMemberList() {
		
		sql = "select * from member order by memno desc";
		
		List<Member> list = this.template.query(sql, new RowMapper<Member>() {

			@Override
			public Member mapRow(ResultSet rs, int rowNum) throws SQLException {
				
				Member dto = new Member();
				
				dto.setMemno(rs.getInt("memno"));
    			dto.setMemid(rs.getString("memid"));
				dto.setMemname(rs.getString("memname"));
				dto.setMempwd(rs.getString("mempwd"));
				dto.setAge(rs.getInt("age"));
				dto.setMileage(rs.getInt("mileage"));
				dto.setJob(rs.getString("job"));
				dto.setAddr(rs.getString("addr"));
				dto.setRegdate(rs.getString("regdate"));
				
				return dto;
			}
		});
		
		return list;
	}
	
	
	

	@Override
	public int insertMember(final Member dto) {
		
		sql = "select count(memno) from member";
		
		final int count = this.template.queryForInt(sql);
		
		sql = "insert into member "
				+ " values(?, ?, ?, ?, ?, ?, ?, ?, sysdate)";
		
		return this.template.update(sql, new PreparedStatementSetter() {
			
			@Override
			public void setValues(PreparedStatement ps) throws SQLException {
				
				ps.setInt(1, count + 1);
				ps.setString(2, dto.getMemid());
				ps.setString(3, dto.getMemname());
				ps.setString(4, dto.getMempwd());
				ps.setInt(5, dto.getAge());
				ps.setInt(6, dto.getMileage());
				ps.setString(7, dto.getJob());
				ps.setString(8, dto.getAddr());
				
			}
		});
	}

	@Override
	public Member getMember(int memno) {
		
		sql = "select * from member where memno = ?";
		
		return this.template.queryForObject(sql, new RowMapper<Member>() {

			@Override
			public Member mapRow(ResultSet rs, int rowNum) throws SQLException {

				Member dto = new Member();
				
				dto.setMemno(rs.getInt("memno"));
    			dto.setMemid(rs.getString("memid"));
				dto.setMemname(rs.getString("memname"));
				dto.setMempwd(rs.getString("mempwd"));
				dto.setAge(rs.getInt("age"));
				dto.setMileage(rs.getInt("mileage"));
				dto.setJob(rs.getString("job"));
				dto.setAddr(rs.getString("addr"));
				dto.setRegdate(rs.getString("regdate"));
				
				return dto;
			}
			
		}, memno);
		
	}

	@Override
	public int updateMember(Member dto) {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public int deleteMember(int memno) {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public void updateSequence(int memno) {
		// TODO Auto-generated method stub

	}

}
