package khie;

public class Variable_02 {

	public static void main(String[] args) {
		
		// 1. 변수 선언
		// int num;
		
		// 2. 변수 초기화
		// num = 100;
		
		// 1 + 2 : 변수 선언 및 변수 초기화
		int num = 100;
		
		num = num + 150;
		
		// 3. 변수 출력
		System.out.println(num);

	}

}
