package khie;

public class Variable_03 {

	public static void main(String[] args) {
		
		int su1 = 63;
		int su2 = 19;
		
		System.out.println("su1 값은 " + su1 + " 입니다.");
		
		System.out.println("su2 값은 " + su2 + " 입니다.");
		
		System.out.println("두 수의 합은 " + (su1+su2) + " 입니다.");

	}

}
