package khie;

/*
 * 논리 자료형(boolean형)
 * - 참이나 거짓을 판별(처리)하는 자료형.
 * - true : 참인 값.
 * - false : 거짓인 값.
 * - boolean형의 기본 값은 false임.
 * - True / False(X) ==> 반드시 소문자로 작성해야 함.
 */

public class Variable_07 {

	public static void main(String[] args) {
		
		boolean test = true;
		
		System.out.println("test >>> " + test);
		
	}

}
