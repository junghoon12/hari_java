package com.board.model;

import java.util.List;
import java.util.Map;

public interface BoardDAO {

	int getListCount();
	
	List<BoardDTO> getBoardList(PageDTO dto);
	
	int insertBoard(BoardDTO dto);
	
	void readCount(int no);
	
	BoardDTO boardCont(int no);
	
	int updateBoard(BoardDTO dto);
	
	int deleteBoard(int no);
	
	void updateSequence(int no);
	
	int searchBoardCount(Map<String, String> map);
	
	List<BoardDTO> searchBoardList(PageDTO dto);
	
}
