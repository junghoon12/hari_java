package com.board.action;

import java.io.IOException;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.board.model.BoardDAO;
import com.board.model.BoardDTO;

public class BoardWriteOkAction implements Action {

	@Override
	public ActionForward execute(HttpServletRequest request, HttpServletResponse response) throws IOException {
		// 글쓰기 폼 페이지에서 넘어온 데이터들을
		// board 테이블에 저장하는 비지니스 로직.
		String board_writer = request.getParameter("writer").trim();
		String board_title = request.getParameter("title").trim();
		String board_cont = request.getParameter("cont").trim();
		String board_pwd = request.getParameter("pwd").trim();
		
		BoardDTO dto = new BoardDTO();
		
		dto.setBoard_writer(board_writer);
		dto.setBoard_title(board_title);
		dto.setBoard_cont(board_cont);
		dto.setBoard_pwd(board_pwd);
		
		BoardDAO dao = BoardDAO.getInstance();
			
		boolean chk = dao.boardInsert(dto);
		
		
		if(chk) {
			request.setAttribute("message", "게시글 추가 성공!!!");
			request.setAttribute("alertType", "success");
		}else {
			request.setAttribute("message", "게시글 추가 실패~~~");
			request.setAttribute("alertType", "fail");
		}
		
		ActionForward forward = new ActionForward();
		
		forward.setRedirect(false);
		
		forward.setPath("message/sweetalert_01.jsp");
		
		
		return forward;
		
	}

}
