package com.board.action;

import java.io.IOException;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.board.model.BoardDAO;
import com.board.model.BoardDTO;

public class BoardModifyAction implements Action {

	@Override
	public ActionForward execute(HttpServletRequest request, HttpServletResponse response) throws IOException {
		// get 방식으로 넘어온 게시글 번호에 해당하는 게시글의
		// 정보를 board 테이블에서 조회하여 해당 게시글의 내용을
		// 수정 폼 페이지(view page)로 이동시키는 비지니스 로직.
		int board_no = 
			Integer.parseInt(request.getParameter("no").trim());
		
		int nowPage = 
				Integer.parseInt(request.getParameter("page").trim());
		
		BoardDAO dao = BoardDAO.getInstance();
		
		BoardDTO modify = dao.getBoardContent(board_no);
		
		request.setAttribute("Modify", modify);
		request.setAttribute("Page", nowPage);
		
		ActionForward forward = new ActionForward();
		
		forward.setRedirect(false);
		
		forward.setPath("view/board_modify.jsp");
		
		return forward;
	
	}

}
