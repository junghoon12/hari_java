package inner;

public interface Inter {

	int sum(int n1, int n2);
	
	int minus(int n1, int n2);
	
}
