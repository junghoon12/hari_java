package exam;

public class Rectangle {

	// 멤버 변수
	int width;
	int height;
	
	public Rectangle() {  }   // 기본 생성자
	
	public Rectangle(int width, int height) {
		this.width = width;
		this.height = height;
		
	}   // 인자 생성자
	
	// 멤버 메서드
	// 사각형의 넓이를 구하는 메서드.
	void output1() {
		System.out.println
			("사각형의 넓이 >>> " + (width * height));
	}
	
	// 사각형의 둘레를 구하는 메서드.
	void output2() {
		System.out.println
			("사각형의 둘레 >>> " + ((width + height) * 2));
	}
	
	
}
