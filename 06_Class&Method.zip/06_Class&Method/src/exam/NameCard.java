package exam;

public class NameCard {

	// 멤버 변수
	String name;
	String phone;
	String addr;
	String position;
	
	public NameCard() {  }    // 기본 생성자
	
	public NameCard(String name, String phone,
			String addr, String position) {
		
		this.name = name;
		this.phone = phone;
		this.addr = addr;
		this.position = position;
		
	}    // 인자 생성자
	
	// 멤버 메서드
	void getInfo() {
		System.out.println("이 름 >>> " + name);
		System.out.println("전화번호 >>> " + phone);
		System.out.println("주 소 >>> " + addr);
		System.out.println("직 급 >>> " + position);
	}
	
}
