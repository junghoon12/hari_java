package com.dept.controller;

import java.io.IOException;
import java.util.ArrayList;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.dept.model.DeptDAO;
import com.dept.model.DeptDTO;


@WebServlet("/list")
public class ListServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
   
    public ListServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	
	protected void service(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// index.jsp 페이지에서 요청
		// 전체 부서 목록 이라는 글자를 클릭하면
		// DEPT 테이블에 있는 전체 부서 목록을 
		// 화면에 보여 주어야 함.  ==> 요청에 대해 응답
		
		// 1단계 : DB와 연결 작업 진행.
		DeptDAO dao = new DeptDAO();
		System.out.println("list dao >>> " + dao);
		
		// 2단계 : DB에서 DEPT 테이블의 전체 부서 목록을 조회.
		ArrayList<DeptDTO> list = dao.deptList();
		
		// 3단계 : 페이지 이동 작업 시 데이터를 같이 넘겨야 함.
		request.setAttribute("LIST", list);
		
		// 4단계 : 페이지 이동 작업 진행.
		RequestDispatcher rd =
			request.getRequestDispatcher("selectList.jsp");
		
		rd.forward(request, response);
		
	}

}
