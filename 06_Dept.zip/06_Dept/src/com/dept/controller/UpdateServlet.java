package com.dept.controller;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.dept.model.DeptDAO;
import com.dept.model.DeptDTO;


@WebServlet("/update")
public class UpdateServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    
    public UpdateServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	
	protected void service(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// get 방식으로 넘어온 부서번호를 가지고
		// DB에서 부서정보를 조회하는 비지니스 로직.
		int deptno = 
			Integer.parseInt(request.getParameter("no").trim());
		
		// 1단계 : DB에서 부서번호에 해당하는 부서의 정보를 조회하자.
		DeptDAO dao = new DeptDAO();
		System.out.println("update dao >>> " + dao);
		
		DeptDTO cont = dao.getDept(deptno);
		
		// 2단계 : 조회된 부서정보를 수정폼(jsp) 페이지로 이동시켜야 한다.
		request.setAttribute("content", cont);
		
		RequestDispatcher rd = 
			request.getRequestDispatcher("update.jsp");
		
		rd.forward(request, response);
	}

}
