package com.dept.controller;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.dept.model.DeptDAO;
import com.dept.model.DeptDTO;


@WebServlet("/updateOk")
public class UpdateOkServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    
    public UpdateOkServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	
	protected void service(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// 부서 수정 폼페이지에서 넘어온 정보들을
		// DB에서 수정하는 비지니스 로직.
		
		// 한글 인코딩 설정 작업
		request.setCharacterEncoding("UTF-8");
		response.setContentType("text/html; charset=UTF-8");
		
		// 1단계 : 부서 수정 폼 페이지에서 넘어온 정보들을 받아 주자.
		int deptNo =
			Integer.parseInt(request.getParameter("no").trim());
		
		String dname = request.getParameter("name").trim();
		
		String location = request.getParameter("loc").trim();
		
		
		// 2단계 : 부서 수정 정보를 DB에 전송할 DTO 객체에 
		//        정보를 저장해 주자.
		DeptDTO dto = new DeptDTO();
		
		dto.setDeptno(deptNo);
		dto.setDname(dname);
		dto.setLocation(location);
		
		// 3단계 : DTO(부서 정보가 수정된 데이터)를 DB에 전송하자.
		DeptDAO dao = new DeptDAO();
		
		int check = dao.updateDept(dto);
		
		PrintWriter out = response.getWriter();
		
		if(check > 0) {
			out.println("<script>");
			out.println("alert('부서 수정 성공!!!')");
			out.println("location.href='list'");
			out.println("</script>");
		}else {
			out.println("<script>");
			out.println("alert('부서 수정 실패~~~')");
			out.println("history.back()");
			out.println("</script>");
		}
		
		
	}

}
