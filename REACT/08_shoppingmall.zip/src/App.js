import './App.css';
import { Routes, Route } from 'react-router-dom';
import ProductAll from './page/ProductAll';
import Login from './page/Login';
import ProductDetail from './page/ProductDetail';

/*
   1. 전체 상품 페이지, 로그인 페이지, 상품 상세 정보 페이지 ==> 3 페이지
      ==> 페이지가 여러개 이면 react-router 를 설치해야 함.
   2. 네비게이션 바를 만들자.
   3. 전체 상품 페이지에서는 전체 상품을 보여 준다.
   4. 로그인 버튼을 누르면 로그인 페이지가 나온다.
   5. 상품 상세 정보 페이지를 눌렀으나, 로그인이 되어 있지 않았을 경우
      로그인 페이지가 먼제 나오게 한다.
   6. 로그인이 되었을 경우 상품 상세 정보 페이지를 볼 수 있다.
   7. 로그아웃 버튼을 클릭하면 로그아웃이 된다.
      로그아웃이 되면 상품 상세 정보 페이지를 볼 수 없다.
      다시 로그인 페이지가 보여야 한다.
   8. 로그인을 하면 로그아웃 글자가 보이고, 로그아웃을 하면 로그인
      글자가 보여야 한다.
   9. 상품을 검색할 수 있다.
*/

function App() {
  return (
    <div>
      <Routes>
        <Route path='/' element={<ProductAll />} />
        <Route path='/login' element={<Login />} />
        <Route path='/product/:id' element={<ProductDetail />} />
      </Routes>
    </div>
  );
}

export default App;
