import { FontAwesomeIcon } from '@fortawesome/react-fontawesome'
import { faUser } from '@fortawesome/free-regular-svg-icons'
import React from 'react'
import { faSearch } from '@fortawesome/free-solid-svg-icons';
import { useNavigate } from 'react-router-dom';

const Navbar = ({authen, setAuthen}) => {
  const menuList = ["여성", "남성", "신생아/유아", "아동", "Sale"];
  
  const navigate = useNavigate();
  
  const goToLogin = () => {
    // 로그인 페이지로 가야 함. useNavigate 사용해야 함.
    navigate("/login");
  }

  const search = (event) => {
    if(event.key === "Enter") {
      let keyword = event.target.value;
      console.log("keyword >>> ", keyword);
      // url을 바꾸어 준다.
      navigate(`/?q=${keyword}`);
    }
  }
  return (
    <div>
      <div className="login-button" onClick={goToLogin}>
        {authen ? (
          <div onClick={() => setAuthen(false)}>
            <FontAwesomeIcon icon={faUser} />
            <span style={{cursor : "pointer"}}>로그아웃</span>
          </div>
          ) : (
            <div onClick={() => navigate("/login")}>
            <FontAwesomeIcon icon={faUser} />
            <span style={{cursor : "pointer"}}>로그인</span>
          </div>
          )
        }
      </div>
      <div className="nav-section">
        <img className="image_size" src="https://upload.wikimedia.org/wikipedia/commons/thumb/5/53/H%26M-Logo.svg/2560px-H%26M-Logo.svg.png" alt="H&M" />
      </div>
      <div className="menu-area">
        <ul className="menu-list">
          {menuList.map(menu => <li>{menu}</li>)}
        </ul>
      
        <div className="search-box">
          <FontAwesomeIcon icon={faSearch} />
          <input type="text" placeholder="제품검색" 
              onKeyPress={(event) => search(event)} />
        </div>
      </div>
    </div>
    
  )
}

export default Navbar
