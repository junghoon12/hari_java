import React from 'react'
import { Button, Container, Form } from 'react-bootstrap'
import { useNavigate } from 'react-router-dom'

const Login = ({setAuthen}) => {
  const navigate = useNavigate();
  const loginUser = (event) => {
    /*
      a 태그나 submit 태그는 누르게 되면 href를 통해 페이지가 이동되거나,
      창이 새로고침을 통해 실행이 됨.
      preventDefault() 함수는 이러한 동작을 막아주는 역할을 하는 함수임.
      1. a 태그를 눌렀을 때도 href 링크로 이동하지 않게 할 경우
      2. form 태그 안에 submit 역할을 하는 버튼을 눌렀어도 새로 실행되지 
         않게 하고 싶은 경우
    */
    
    event.preventDefault();
    // 로그인 작업을 진행해 보아야 함. authen
    console.log("login user");
    setAuthen(true);  
    // 로그인이 성공한 경우 메인 페이지로 이동 
    // ==> useNavigate 함수 사용해야 함.
    navigate("/");  // 메인 페이지로 이동
  }
  return (
    <Container>
      <Form onSubmit={(event) => loginUser(event)}>
        <Form.Group className="mb-3" controlId="formBasicEmail">
        <Form.Label>Email address</Form.Label>
        <Form.Control type="email" placeholder="Enter email" />
        <Form.Text className="text-muted">
          We'll never share your email with anyone else.
        </Form.Text>
      </Form.Group>

      <Form.Group className="mb-3" controlId="formBasicPassword">
        <Form.Label>Password</Form.Label>
        <Form.Control type="password" placeholder="Password" />
      </Form.Group>
      <Form.Group className="mb-3" controlId="formBasicCheckbox">
        <Form.Check type="checkbox" label="Check me out" />
      </Form.Group>
      <Button variant="danger" type="submit">
        로그인
      </Button>
    </Form>
    </Container>
  )
}

export default Login
