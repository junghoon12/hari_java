import React, { useEffect, useState } from 'react'
import ProductCard from '../component/ProductCard';
import {  Container, Row, Col } from 'react-bootstrap';

/*
  react에서 API 호출은 useEffect 함수를 호출하면 됨.
  useEffect 함수는 리액트 컴포넌트가 랜더링 될 때마다 특정 작업을 실행할 수
  있도록 하는 함수임. useEffect는 component가 mount 되었을 때, component가
  unmount 되었을 때, component가 update 되었을 때 특정 작업을 처리할 수 있음.
  즉, 클래스형 컴포넌트에서 사용할 수 있었던 생명주기 메서드를 함수형 컴포넌트
  에서도 사용할 수 있게 됨.
  형식) useEffect(function, deps)
        - function : 실행하고자 하는 함수.
        - deps : 배열. function을 실행시킬 조건.
*/

const ProductAll = () => {
  const [productList, setProductList] = useState([]);
  const getProducts = async () => {
    let url = "http://localhost:5000/products";
    // url에 있는 데이터(json)를 받는 함수.
    let response = await fetch(url);
    // JSON 데이터를 javascript 객체로 변환해 주는 함수.
    let data = await response.json();

    console.log(data);
    
    setProductList(data);
  }
  useEffect(() => {
    getProducts();
  }, []);
  return (
    <div>
      <Container>
        <Row>
          {productList.map((menu) => (
            <Col md={3}>
              <ProductCard item={menu} />
            </Col>
          ))}
        </Row>
      </Container>
    </div>
  )
}

export default ProductAll
