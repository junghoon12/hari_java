import React from 'react'

const ProductAll = () => {
  return (
    <div>
      <h1>전체 상품 페이지!!!</h1>
    </div>
  )
}

export default ProductAll
