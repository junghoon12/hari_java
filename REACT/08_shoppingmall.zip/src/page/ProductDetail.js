import React from 'react'

const ProductDetail = () => {
  return (
    <div>
      <h1>상품 상세 페이지입니다.</h1>
    </div>
  )
}

export default ProductDetail
