import React, { useEffect, useState } from 'react'
import { Button, Col, Container, Dropdown, Row } from 'react-bootstrap';
import DropdownToggle from 'react-bootstrap/esm/DropdownToggle';
import { useParams } from 'react-router-dom';

const ProductDetail = () => {
  let {id} = useParams();
  let [product, setProduct] = useState(null);

  const getProductDetail = async () => {
    let url = `http://localhost:5000/products/${id}`;
    // url에 있는 데이터(json)를 받는 함수.
    let response = await fetch(url);
    // JSON 데이터를 javascript 객체로 변환해 주는 함수.
    let data = await response.json();
    console.log(data);
    setProduct(data);
  }

  useEffect(() => {
    // useEffect 함수는 두 개의 인자가 필요.
    // 첫번째 인자 : 콜백함수, 두번째 인자 : 배열
    getProductDetail();
  }, []);
  return (
    <Container>
      <Row>
        <Col className="product-img">
          <img src={product?.img} alt="제품이미지" />
        </Col>
        <Col>
          <div>{product?.title}</div>
          <div>￦ {product?.price}</div>
          <Dropdown className="drop-down">
            <Dropdown.Toggle variant="outline-dark" id="dropdown-basic">
              사이즈 선택
            </Dropdown.Toggle>

            <Dropdown.Menu>
              {product?.size.length > 0 &&
                  product.size.map((item) => (
                    <Dropdown.Item href="#/action-1">{item}</Dropdown.Item>
              ))}
            </Dropdown.Menu>
          </Dropdown>
          <br />
          <Button variant='dark' className='add-button'>추가</Button>
        </Col>
      </Row>
    </Container>
  )
}

export default ProductDetail
