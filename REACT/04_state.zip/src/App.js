import {useState} from "react";
import './App.css';

function App() {

  /*
    1. user(사용자)가 버튼을 클릭한다.
    2. 상단에 있는 값이 변해야 한다.
  */
  let counter = 0;
  const [counter2, setCounter2] = useState(0);
  const increase = () => {
    counter = counter + 1;
    setCounter2(counter2 + 1);
    console.log("counter >>> ", counter, "counter2 state는 ", counter2);
  }

  /*
    1. 사용자가 버튼을 클릭한다.
    2. counter + 1 해서 1이 됨.
    3. setState 함수 호출.
    4. consloe.log() 가 실행이 됨.
       변수값은 1로 보이고, state 값은 아직 increase() 함수가 끝나지 않았기
       때문에 그 전의 값이 보인다. 함수가 끝나야 setCounter2() 함수가 처리가
       됨. ==> 비동기식으로 처리가 됨.
    5. App 다시 리랜더링이 됨.
    6. let counter = 0 을 거치면서 counter 변수 값은 다시 0으로 초기화가 됨.
    7. state 값은 update가 되면서 다시 render 를 한다.
    8. 즉, 변수는 리랜더링이 될 때마다 값이 초기화가 된다.
       또한 state 값은 비동기적으로 처리가 됨.

  */

  return (
    <div>
      <div> {counter} </div>
      <div>state : {counter2}</div>
      <button onClick={increase}>클릭</button>
    </div>
  );
}

export default App;
