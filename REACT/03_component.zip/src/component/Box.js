import React from 'react'
// 컴포넌트를 만드는 단축 키 : rafce

const Box = (props) => {
  return (
    <div>
      <div className="box">
        BOX{props.num}
        <p>{props.name}</p>
      </div>
    </div>
  )
}

export default Box
