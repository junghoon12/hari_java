import './App.css';
import Box from './component/Box';

function App() {
  return (
    <div>
      <Box name="블랙핑크" num={1} />
      <Box name="BTS" num={2} />
      <Box name="여자친구" num={3} />
    </div>
  );
}

export default App;
