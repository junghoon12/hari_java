let initialState = {
    count : 0
}

// reducer는 함수임.
function reducer(state=initialState, action) {
    // state는 초기화가 필요함.
    console.log("action >>> ", action);
    if(action.type === "INCREMENT") {
        /*
          - store는 reducer가 return 한 값을 변경을 하게 됨.
          - reducer는 항상 return을 해 주어야 함.
          - ...state는 내가 모르는 여러가지 state들이 있을 수 있음.
          - 여기서 state가 여러 개이면 다른 state 값들은 그대로
            유지를 하되, count state만 변경하라는 의미.
          - store는 객체의 주소가 새로운 주소 값이 오는가 
            안 오는가만 따짐.
          - ...state(spread) 문법을 통하여 기존 객체 내용을 복사해
            새로운 객체를 만들어 store에 전달을 함.
        */
        return {...state, count : state.count + 1}

        

    }
    return {...state};
    
}

export default reducer;