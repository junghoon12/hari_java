import './App.css';
import { useDispatch, useSelector } from 'react-redux';

function App() {
  // const [count, setCount] = useState(0);
  const count = useSelector(state => state.count);
  const dispatch = useDispatch();
  const increase = () => {
    // setCount(count + 1);
    // action은 object임. 형식이 존재함.
    // 매개변수가 필요함
    // 반드시 type 키가 필요함, payload 라는 키가 있어야 함.
    // payload 키는 선택사항.
    // type에는 action의 이름이 들어가면 됨.
    dispatch({type : "INCREMENT"});
  }

  return (
    <div>
       <h1>{count}</h1>
       <button onClick={increase}>증가</button> 
    </div>
  );
}

export default App;
