import React, { Component } from 'react';
import BoxClass from "./component/BoxClass";

export default class AppClass extends Component {
  
  increase = () => {
    this.setState({
        counter2 : this.state.counter2 + 1,
        value : this.state.value + 1
    });
    console.log("increase function >>> ", this.state);
  }
   
  componentDidMount() {
    console.log("componentDidMount");
  }

  componentDidUpdate() {
    // 최신 업데이트된 state 값을 받아 볼수 있음.
    console.log("conponentDidUpdate >>> ", this.state);
  }
  
  constructor(props) {
    super(props)
    this.state = {
        counter2 : 0,
        num : 1,
        value : 0
    }
    console.log("constructor");
  };

  render() {
    
    console.log("render");

    // 수정 내용
    // Box.js 파일 추가.
    // 맨 마지막 줄 추가.
    return (
      <div>
        <div>state : {this.state.counter2} </div>
        <button onClick={this.increase}>클릭</button>
        {this.state.counter2 < 3 &&<BoxClass num={this.state.value} />}</div>
    )
  }
}
