import React, { Component } from 'react'
import Box from './Box';

export default class BoxClass extends Component {
  
    componentWillUnmount() {
        console.log("bye bye!!!");
    }

    render() {
    return (
      <div>
        <Box>{this.props.num}</Box>
      </div>
    )
  }
}
