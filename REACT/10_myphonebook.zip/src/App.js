import "./App.css";
import "bootstrap/dist/css/bootstrap.min.css";
import { Container, Row, Col } from "react-bootstrap";
import ContactList from "./component/ContactList";
import ContactForm from "./component/ContactForm";


function App() {
  return (
    <Container>
      <h1 className="title">연락처</h1>
      <Row>
        <Col className="border-column">
          <ContactForm />
        </Col>
        <Col>
          <ContactList />
        </Col>
      </Row>
    </Container>
  );
}

export default App;