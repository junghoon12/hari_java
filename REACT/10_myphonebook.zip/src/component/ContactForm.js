import React, { useState } from 'react'
import { Button, Form } from 'react-bootstrap'
import { useDispatch } from 'react-redux';


const ContactForm = () => {
  const [name, setName] = useState("");
  const [phone, setPhone] = useState("");
  const dispatch = useDispatch();

  const addContact = (event) => {
    // submit 버튼을 클릭할 때마다 새로고침이 발생되지 않게 하는
    // event 처리 작업
    event.preventDefault();
    dispatch({type : "ADD_CONTACT", 
              payload : {name : name, phone : phone}})

  }
  
  return (
    <div>
      <Form onSubmit={addContact}>
        <Form.Group className="mb-3" controlId="formName">
            <Form.Label>이 름</Form.Label>
            <Form.Control type="text" placeholder="이름을 입력해 주세요..."
                onChange={(event) => {setName(event.target.value);}} />
        </Form.Group>

        <Form.Group className="mb-3" controlId="formContact">
            <Form.Label>연락처</Form.Label>
            <Form.Control type="text" placeholder="전화번호를 입력하세요..."
                onChange={(event) => {setPhone(event.target.value);}} />
        </Form.Group>
        
        <Button variant="primary" type="submit">
            연락처 추가
        </Button>
      </Form>
    </div>
  )
}

export default ContactForm
