import React from 'react'
import { Button, Col, Form, Row } from 'react-bootstrap'

const SearchBox = () => {
  return (
    <div>
      <Form>
        <Row>
            <Col lg={9}>
                <Form.Control type="text" placeholder="검색할 이름을 입력하세요..." />
            </Col>
            <Col lg={3}>
                <Button variant="primary">검색</Button>
            </Col>
        </Row>
      </Form>
    </div>
  )
}

export default SearchBox
