import React from 'react'
import { Col, Row } from 'react-bootstrap'

const ContactItem = () => {
  return (
    <div>
      <Row>
        <Col lg={2}>
           <img width={50} src="https://upload.wikimedia.org/wikipedia/commons/b/bc/Unknown_person.jpg" alt="이미지"></img>    
        </Col>
        <Col lg={10}>
           <div>홍길동</div>
           <div>010-1111-1234</div>
        </Col>
      </Row>
    </div>
  )
}

export default ContactItem;
