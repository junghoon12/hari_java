import React from 'react'
import { Col, Row } from 'react-bootstrap'

const ContactItem = ({item}) => {
  return (
    <div className="contact-item">
      <Row>
        <Col lg={2}>
           <img className="profile" src="https://upload.wikimedia.org/wikipedia/commons/b/bc/Unknown_person.jpg" alt="이미지"></img>    
        </Col>
        <Col lg={10}>
           <div>{item.name}</div>
           <div>{item.phone}</div>
        </Col>
      </Row>
    </div>
  )
}

export default ContactItem;
