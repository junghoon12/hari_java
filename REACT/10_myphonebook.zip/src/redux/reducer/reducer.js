let initialState = {
    contact : [],
    keyword: "",
}


// reducer는 함수로 되어 있음.
const contactReducer = (state=initialState, action) => {
    switch(action.type) {
        case "ADD_CONTACT" : 
            state.contact.push({
                name: action.payload.name,
                phone : action.payload.phone
            })
            break;
        case "SEARCH_BY_USERNAME": // 케이스 새로 추가
            state.keyword = action.payload.keyword;
            break;
        
    }
    return {...state};
};


export default contactReducer;