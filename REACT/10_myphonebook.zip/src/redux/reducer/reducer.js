let initilaState = {
    contactList : []
}


// reducer는 함수로 되어 있음.
function reducer(state=initilaState, action) {
    // state는 초기화가 필요하다.
    switch(action.type) {
        case "ADD_CONTACT" : 
            return {
                ...state,
                contactList : [...state.contactList,
                    {name: action.payload.name, 
                     phone : action.payload.phone}]
            };
        default : return {...state};
    }
}

export default reducer;