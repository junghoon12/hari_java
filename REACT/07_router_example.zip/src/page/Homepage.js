import React from 'react'
import { Link } from 'react-router-dom'

const Homepage = () => {
  return (
    <div>
      <h1>메인 홈페이지입니다.!!!</h1>
      <Link to="/about">Go to About page</Link>
      <Link to="/products">제품 리스트</Link>
    </div>
  )
}

export default Homepage
