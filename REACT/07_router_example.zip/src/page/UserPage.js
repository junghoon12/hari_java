import React from 'react'

// 보호해 주어야 하는 페이지
const UserPage = () => {
  return (
    <div>
      <h1>User Page!!!</h1>
    </div>
  )
}

export default UserPage
