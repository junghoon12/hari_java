import React from 'react'

const Productpage = () => {
  return (
    <div>
      <h1>Show All Products!!!</h1>
    </div>
  )
}

export default Productpage
