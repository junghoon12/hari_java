import './App.css';
import Aboutpage from './page/Aboutpage';
import Homepage from './page/Homepage';
import { Routes, Route, Navigate } from 'react-router-dom';
import Productpage from './page/Productpage';
import ProductDetailPage from './page/ProductDetailPage';
import LoginPage from './page/LoginPage';
import { useState } from 'react';
import UserPage from './page/UserPage';

function App() {
  const [auth, setAuth] = useState(true);
  // 간단하게 컴포넌트를 만들어 보자.
  const PrivateRoute = () => {
    return auth === true ? <UserPage /> : <Navigate to="/login" />
  }
  return (
    <div>
       <Routes>
          <Route path="/" element={<Homepage />} />
          <Route path='/about' element={<Aboutpage />} />
          <Route path='/products' element={<Productpage />} />
          <Route path='/products/:id' element={<ProductDetailPage />} />
          <Route path='/login' element={<LoginPage />} />
          <Route path='/user' element={<PrivateRoute />} />
       </Routes>
    </div>
  );
}

export default App;
