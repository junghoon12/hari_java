/*
  index.html 페이지가 실행되고 난 후 화면에 실행되는 페이지.
  리액트 코드들 중에서 가장 먼저 실행되는 파일.
*/

import React from 'react';
import ReactDOM from 'react-dom/client';
import './index.css';
import App from './App';
import reportWebVitals from './reportWebVitals';

/*
아래 문장은 컴포넌트를 페이지에 랜더링하는 역할을 함.
createRoot 라는 이 함수의 인자에는 페이지에 랜더링할 내용을
JSX 형태의 문법으로 작성을 하면 됨.
그러면 createRoot() 함수 안에 있는 root 라는 id에 JSX
형태로 작성된 내용을 화면에 보여주게 됨.
*/
const root = ReactDOM.createRoot(document.getElementById('root'));
root.render(
  <React.StrictMode>
    <App />
  </React.StrictMode>
);

// If you want to start measuring performance in your app, pass a function
// to log results (for example: reportWebVitals(console.log))
// or send to an analytics endpoint. Learn more: https://bit.ly/CRA-vitals
reportWebVitals();
