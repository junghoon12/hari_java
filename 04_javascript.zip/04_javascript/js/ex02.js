/* 웹 문서의 요소 가져오는 작업 */
var title = document.querySelector("#title");

var user = document.querySelectorAll(".user")[0];

var userImage = document.querySelector("#profile img");

/* 가져온 요소에 변경 작업 진행 */
title.onclick = function() {
    title.innerText = "프로필";
    title.style.backgroundColor = "black";
    title.style.color = "white";
    title.style.border = "5px solid green";
}

user.onclick = function() {
    user.innerHTML = `이름 : <b>민들레</b>`;
}

userImage.onclick = function() {
    userImage.src = `../images/pf2.png`;
}
